﻿using EODomain.Models.LogTables;
using System.Security.Principal;
using EODomain.Models.Account;

namespace EOApplication.Contracts.Services
{
    public interface IWinAuthServices
    {
        Task<AuthenticationResponse> AuthenticateAsync(IIdentity identityUser, string ipAddress, string browser, int forcedLogin, string urlRequested);
        Task<GetLatestLoginSessionByUserStoredProcedureResponse> GetLatestLoginSessionBySessionAsync(string? sessionGuid,string urlRequested);
        Task<string> GenerateToken(User user, string ipAddress, string browser, int forcedLogin, GetDataForAuthenticationByUserIdStoredProcedureResponse userData);
        Task<string> CreateNewTokenGivenSessionGuid(string sessionGuid, User user, string ipAddress, string browser, int forcedLogin, GetDataForAuthenticationByUserIdStoredProcedureResponse userData);
        Task<GetLatestTokenDataBySessionStoredProcedureResponse> GetTokenSessionLoginDataByTokenAsync(string? tokenGuid, string urlRequested);
        bool ValidateRequestSource(string currentIp, RequestIpBrowserVersion source);
        Task<GetLatestLoginSessionByUserStoredProcedureResponse> GetLatestLoginSessionByUserAsync(int userId,string urlRequested);

    }
}
