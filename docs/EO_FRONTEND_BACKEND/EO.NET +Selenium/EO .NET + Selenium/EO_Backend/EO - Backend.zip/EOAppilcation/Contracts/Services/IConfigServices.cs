﻿using EODomain.Models.Config;
using EODomain.Models.Requests;

namespace EOApplication.Contracts.Services
{
    public interface IConfigServices
    {
        Task<Object> GetCaseHierarchyAsync();
        Task<dynamic> GetLandingCorporateAsync(string? caseIDList);
        Task<bool> LogoutUserAsync(int userId);
        Task<List<GetViewDataDictionaryByTableNameResponse>> GetViewDataDictionaryByTableNameAsync(GetViewDataDictionaryByTableNameRequest request);
        Task<List<GetCaseInfoByByCaseIdListResponse>> GetCaseInfoByCaseIdListAsync(CaseIdListRequest request);
        Task<dynamic> GetUomAsync();
        Task<object> GetLandingAffiliateScoreCardAsync(int affiliateID, string? upto = null);
        Task<dynamic> GetScreenNamesByAffiliateIDsAsync(GetUserStatisticsScreensRequest request);
        Task<int> GetAffiliateIDByCaseID(int caseID);
        Task<int> GetAffiliateIDByDerivedEquationId(int derivedEquationId);
        Task<int> GetAffiliateIDByVariableId(int variableId);
        Task<int> GetAffiliateIDByConstraintId(int constraintId);
        Task<int> GetAffiliateIDByModelTagId(int modelTagId);
        Task<int> GetAffiliateIDByObjectiveId(int objectiveId);
        Task<int> GetAffiliateIDByModelId(int modelId);
        Task<List<GetWalkthroughDataByPagekeyGrpResponse>> GetWalkthroughDataByPageKey(GetWalkthroughDataByPagekeyRequest request);
    }
}
