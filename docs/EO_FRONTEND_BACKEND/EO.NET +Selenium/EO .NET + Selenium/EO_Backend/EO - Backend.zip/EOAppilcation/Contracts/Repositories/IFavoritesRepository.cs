﻿using EODomain.Models;
using EODomain.Models.Favorites;

namespace EOApplication.Contracts.Repositories
{
    public interface IFavoritesRepository
    {
        
        Task<List<GetFavoriteByUserIDStoredProcedureResponse>> GetFavoriteByUserIDAsync(int userID);
        Task<List<PostAddFavoriteByUserIDStoredProcedureResponse>> PostAddFavoriteByUserIDAsync(PostAddFavoriteByUserIDRequest request);
        Task<List<PostDeleteFavoriteByFavIDStoredProcedureResponse>> PostDeleteFavoriteByFavIDAsync(PostDeleteFavoriteByFavIDRequest request);
        Task<FavTrendRequest> PostAddFavoriteTrendByUserIDAsync(int userID, PostFavTrendByUserID requestOne);
        Task<FavTrendRequest> PostDeleteFavoriteTrendByUserIDAsync(int userID, Guid FavID);
        Task<IEnumerable<dynamic>> GetFavoriteTrendByUserDAsync(int userID, Guid FavID);
        Task<IEnumerable<dynamic>> GetAllFavoriteTrendByFavIDAsync(int userID);
        
        // User Preference
        Task<int?> PostUserPreferencesAsync(int userID, string? key, string? parameter, string? data);
        Task<List<GetUserPreferencesStoredProcedureResponse>> GetUserPreferencesAsync(int userID, string? key, string? parameter);
        Task<bool> DeleteUserPreferencesAsync(string IDs);
    }
}
