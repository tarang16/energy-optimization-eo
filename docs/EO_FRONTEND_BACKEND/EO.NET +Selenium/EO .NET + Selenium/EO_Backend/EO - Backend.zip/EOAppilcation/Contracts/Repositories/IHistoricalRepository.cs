﻿using EODomain.Models.HistoricalData;
using EODomain.Models.Requests;

namespace EOApplication.Contracts.Repositories
{
    public interface IHistoricalRepository
    {
        Task<dynamic> GetCalenderDataAsync(int? caseID);
        Task<List<GetDataTimeStartEndStoredProcResponse>> GetTrendDataActualOptimumAsync(GetTrendDataActualOptimumRequest request);
        Task<dynamic> GetOpportunityTrendDataAsync(CaseIdListTimeRangeStringRequest request);
        Task<dynamic> GetDataModelSkipMonitoringCalendarDataAsync(CaseIdTimeRangeRequest request);
        Task<List<GetDataModelSkipStoredProcedureResponse>> GetDataModelSkipDataAsync(CaseIdTimeRangeDayDiffRequest request);
    }
}
