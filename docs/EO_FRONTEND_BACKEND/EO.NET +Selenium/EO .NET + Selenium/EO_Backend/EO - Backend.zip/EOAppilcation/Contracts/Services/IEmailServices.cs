﻿using EODomain.Models.Email;

namespace EOApplication.Contracts.Services
{
    public  interface IEmailServices
    {
        Task<EmailSentResponse> SendPerformanceEmailAsync(string urlRequested);
        Task<UpdateEmailListResponse> AddEmailListAsync(UpdateEmailListRequest request);
        Task<SendEmailNotificationInput> GetEmailAsync(GetEmailByIDRequest request);
        Task<List<SendEmailNotificationInput>> GetAllEmailAsync();
        Task<EmailSentResponse> SendWorkFlowEmailAsync(string urlRequested);
        Task<EmailSentResponse> SendWorkFlowEscalationEmailAsync(string urlRequested);
        Task<EmailSentResponse> SendAdminActivityEmailAsync(string urlRequested, string createdBy, string targetedUser, string type, string taskPerformed, string[] taskOn = null!, bool IsClaim = false);
    }
}
