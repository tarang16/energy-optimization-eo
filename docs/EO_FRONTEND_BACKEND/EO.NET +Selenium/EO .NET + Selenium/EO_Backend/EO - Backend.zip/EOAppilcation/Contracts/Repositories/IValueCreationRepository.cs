﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EODomain.Models.ValueCreation;

namespace EOApplication.Contracts.Repositories
{
    public interface IValueCreationRepository
    {
        Task<List<GetAllMasterValueCreationDataStoredProcedureResponse>> GetAllMasterValueCreationByCaseIDAsync(GetAllValueCreationByCaseIDRequest request);
        Task<int?> PostAddMasterValueCreationDataAsync(PostAddValueCreationDataRequestStoredProcedureRequest request);
        Task<List<GetValueCreationSpanDataStoredProcedureResponse?>> GetValueCreationSpanDataByCaseIdAsync(ValueCreationCalcTimeSeriesRequest request);
        Task<string?> PostAddValueCreationSpanDataAsync(PostAddValueCreationSpanDataStoredProcedureRequest request);
        Task<List<GetValueCreationSpanDataForCaseResponse>> GetValueCreationSpanCalcAsync(ValueCreationCalcTimeSeriesRequest request);
        Task<bool> PostDeleteValueCreationSpanDataByIdAsync(DeleteRequestUsingGuid request);
        Task<List<GetAllAddTrnValueCreationCaseInfoDataResponse>> GetAllMasterValueCreationCaseInfoAsync(GetAllValueCreationByCaseIDRequest request);
        Task<List<GetVCByCaseIDListResponse>> GetVCByCaseIDListAsync(GetVCByCaseIDListRequest request);
        Task<List<GetVCSpanAlertResponse?>> GetVCspanAlertAsync(GetVCSpanAlertRequest request);
    }
}
