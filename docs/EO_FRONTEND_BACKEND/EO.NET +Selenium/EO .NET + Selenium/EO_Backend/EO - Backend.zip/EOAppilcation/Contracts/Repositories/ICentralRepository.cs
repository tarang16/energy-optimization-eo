﻿namespace EOApplication.Contracts.Repositories
{
    public interface ICentralRepository
    {
        Task<T> ExecuteQueryAsync<T>(string query, object parameters);
        Task<List<T>> ExecuteQueryListAsync<T>(string query, object parameters);

    }
}
