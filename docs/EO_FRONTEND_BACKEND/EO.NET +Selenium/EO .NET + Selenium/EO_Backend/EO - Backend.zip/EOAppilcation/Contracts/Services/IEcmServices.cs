﻿using EODomain.Common;
using EODomain.Models.ECM;
using Microsoft.AspNetCore.Http;
using System.Runtime;

namespace EOApplication.Contracts.Services
{
    public interface IEcmServices
    {
        Task<GetEcmAuthTokenResponse> GetEcmAuthTokenAsync();
        Task<DownloadFromEcmResponse> DownloadFromEcmAsync(DownloadFromEcmRequest request);
        Task<UploadToEcmResponse> UploadToEcmAsync(IFormFile file, int userID);
        Task<int?> GetEcmNodeIdByCaseIdAsync(int caseId);
        Task<Response<List<EcmFileInfo>>> GetEcmFilesByNodeIdAsyc(string nodeId);
        EcmSettings GetWorkflowEcmSettings();
        Task<List<GetWalkthroughDataByPagekeyGrpEcmResponse>> GetWalkthroughDataFurnaceByFileListTutID(GetWalkthroughDataByFurnaceEcmRequest request);
    }
}
