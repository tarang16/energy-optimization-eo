﻿using EODomain.Models.EnergyManagement;
using EODomain.Models.Requests;


namespace EOApplication.Contracts.Services
{
    public interface IEnergyManagementServices
    {        
        Task<dynamic> GetPlantAffiliatesAsync(GetPlantAffiliatesRequest request);
        Task<dynamic> GetCwCostPerUnitTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetAirWaterSteamValuesAsync(GetAirWaterSteamValuesRequest request);
        Task<dynamic> GetOverallSignificanceEnergyAsync(GetOverallSignificanceEnergyRequest request);
        Task<dynamic> GetEnergyCostIndexEnergyGapMonthlyIndexAsync(GetEnergyCostIndexEnergyGapMonthlyIndexRequest request);
        Task<dynamic> GetCWEnergyCostTrendAsync(GetCWEnergyCostTrendRequest request);
        Task<dynamic> GetCWFlowRateTrendAsync(GetCWFlowRateTrendRequest request);
        Task<dynamic> GetSpecificEnergyCategoryEquipmentAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetAirTrendAsync(GetAirTrendRequest request);
        Task<dynamic> GetTopSixTilesAsync(GetOverallSignificanceEnergyRequest request);
        Task<dynamic> GetSpecificEnergyCategoryAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetTopTileReconciledDataAsync(GetReconciledEnergyRequest request);
        Task<dynamic> GetPlantEnergyEciAirWaterSteamAsync(GetPlantEnergyEciAirWaterSteamRequest request);

        Task<dynamic> GetEquipmentDesignCapacity(GetEquipmentDesignCapacityRequest request);
        Task<dynamic> GetEnpiDailyTrendAsync(GetEnpiDailyTrendRequest request);
        Task<dynamic> GetCwLoadHeatRejectionTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetEciTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetSteamTrendAsync(GetSteamTrendRequest request);
        Task<dynamic> GetTopTilePlantsDataAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetEnergyConsumedSpecificEnergyAsync(AffiliatePlantEquipmentAndCategoryTimeRangeRequest request);
        Task<dynamic> GetEmEnergyGapAsync(AffiliatePlantTimeRangeRequest request);
        Task<dynamic> GetEquipmentListAsync(AffiliateEquipmentCategoryPlantNameListRequest request);
        Task<dynamic> GetSpecificEnergyCategoryEquipmentTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
    }
}
