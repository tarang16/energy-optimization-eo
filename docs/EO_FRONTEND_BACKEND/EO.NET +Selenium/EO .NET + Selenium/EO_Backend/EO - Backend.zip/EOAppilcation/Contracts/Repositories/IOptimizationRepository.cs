﻿using EODomain.Models.Network;
using EODomain.Models.Optimization;
using EODomain.Models.Requests;

namespace EOApplication.Contracts.Repositories
{
    public interface IOptimizationRepository
    {
        Task<List<GetDemandInputsStoredProcedureResponse>> GetDemandInputsAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetAssetAvailabilityAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetPlantLoadAsync(CaseIdDateTimeRequest request);
        Task<List<dynamic>> GetOutputMappingAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetOptimizationPriceInputAsync(CaseIdInputRequest request);
        Task<List<GetWhatIfPlantParametersResponse>> GetWhatIfPlantParametersAsync(GetWhatIfPlantParametersRequest request);
        Task<WhatIfDemandCalculationResponse> WhatIfDemandCalculationAsync(WhatIfDemandCalculationRMRequest request);
        Task<WhatIfOutputResponse> WhatIfOutputAsync(WhatIfOutputRMRequest request);
    }
}
