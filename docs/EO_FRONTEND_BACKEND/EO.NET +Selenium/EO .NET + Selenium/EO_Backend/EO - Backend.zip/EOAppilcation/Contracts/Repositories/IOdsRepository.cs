﻿
using EODomain.Common;
using EODomain.Models.Ods;


namespace EOApplication.Contracts.Repositories
{
    public interface IOdsRepository
    {
        Task<List<GetPeOdsDetailsByOdsIdListTimeStoredProcResponse>> GetOdsOveriewByCaseIdTimeAsync(OdsCaseIdDateTimeRequest request);
        Task<List<GetOdsKpiTagByCaseIDStoredProcedureResponse>> GetOdsKpiTagByCaseIDAsync(int caseID);
        Task<List<GetOdsDataByCaseIDListTimeRangeReqIDResponse>> GetOdsDataByCaseIDListTimeRangeReqIDAsync(string caseIDList, string? sTime , string? eTime);
        Task<GetOdsAlertStatisticsByCaseIDListResponse> GetOdsAlertStatisticsByCaseIDList(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsForRoleResponse>> GetOdsAlertStatisticsForRole(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsPendingAlertsResponse>> GetOdsAlertStatisticsPendingAlerts(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsOverdueAlertsResponse>> GetOdsAlertStatisticsOverDueAlerts(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsInProgressAlertsResponse>> GetOdsAlertStatisticsInProgressAlerts(OdsCaseIdListRequest request);
        Task<GetOdsClosedAlertStatisticsByCaseIDListResponse> GetOdsClosedAlertStatisticsByCaseIDList(string caseIDList, DateTime month);
        Task<List<GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsResponse>> GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsAsync(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsByCaseIdListAndStateStoredProcedureResponse>> GetOdsAlertStatisticsByCaseIdListAndStateAsync(GetOdsAlertStatisticsByCaseIdListAndStateRequest request);
        Task<List<GetOdsTrendDataByRequestIdAndTimeRangeStoredProcedureResponse>> GetOdsTrendDataByRequestIdAndTimeRangeAsync(RequestIdTimeStringRangeRequest request);
        Task<dynamic> GetOdsAlertStatisticsDownloadDataAsync(OdsStatisticsDownloadDataRequest model);
        Task<string> UpdatemutealertslogByCauseIdListAsync(UpdateMuteAlertsLogByCauseId request);
        Task<List<dynamic>> GetmutealertslogAsync(MuteAlertsLogRequest request);
        Task<List<GetPeOdsIdDetailsByCaseIdTimeStoredProcResponse>> GetPeOdsIdDetailsByCaseIdTimeAsync(OdsCaseIdDateTimeRequest request);
        Task<List<GetPeOdsDetailsByOdsIdListTimeStoredProcResponse>> GetPeOdsDetailsByOdsIdListTimeAsync(OdsDetailsByOdsIdListTimeRequest request);
        Task<string> UpdatePeOdsAlertDetailsAsync(UpdatePeOdsAlertDetails request);
        Task<List<dynamic>> GetOdsAlertStatisticsDownloadDataComments(OdsCaseIdListRequest request);
    }
}
