﻿using EODomain.Models.Account.Workflow;
using EODomain.Models.LogTables;
using EODomain.Models.RequestModels;
using EODomain.Models.Requests;
using EODomain.Models.Workflow;
using Microsoft.AspNetCore.Http;
using System.Data;


namespace EOApplication.Contracts.Services
{
    public interface IWorkflowServices
    {
        Task<bool> AddMuteWorkflowNotificationsDataAsync(MuteWorkflowNotificationRequest request);
        Task<GetWorkflowMutedAlertByCauseIdStoredProcedureResponse> GetWorkflowMutedAlertByCauseIdAsync(CauseIdTimeInputRequest request);
        Task<List<GetOdsWorkflowActionLogsServiceLayerResponse>> GetOdsWorkflowActionLogsByRequestIdAsync(int requestId);
        Task<List<GetWorkflowAssignedAlertListByUserIdStoredProcedureResponse>> GetWorkflowAssignedListByUserID(string userIdList);
        Task<List<GetOdsActionSuggestionsStoredProcedureResponse>> GetOdsActionSuggestionsByRequestIdAsync(int requestId,bool connectionFlag);
        Task<List<GetOdsAssigneeListStoredProcedureResponse>> GetOdsAssigneeListByRequestIdAsync(int requestId, byte isReassignment);
        DataTable CreateDataTableToUpdateWFRequestStatus(List<int> requestIdList, int value = 0);
        Task<string> UpdateTemporaryStatusOfWorkflowRequestsAsync(DataTable dataTable);
        Task<GetOdsAssigneeStoredProcedureResponse> GetOdsAssigneeByRequestIdAsync(int requestID);
        Task<LogErrorLogs> GenerateErrorLogRequest(PostOdsWorkflowActionNameRequest request, List<int> failedRequests, HttpContext context);
        Task<GetWorkflowMetaDataAndDetails> GetOdsDataByRequestIdAsync(int requestId);
        Task<List<WorkflowConfigurations>> GetWorkflowConfigurationsAsync(GetWorkflowConfigurationsRequest request);
        Task<List<GetWorkflowHistoricalDataForAllUsersServiceLayerResponse>> GetWorkflowHistoricalDataAsync(int reqId);
        Task<List<GetWorkflowHistoricalDataForAllUsersServiceLayerResponse>> GetWorkflowHistoricalDataForAllUsersAsync(int reqId);
        Task<GetWorkflowPmDelegationInfoStoredProcedureResponse> GetWorkflowPmDelegationInfoAsync(EmployeeIdInputRequest request);
        Task<object> GetWorkflowPmDelegationInfoByEmployeeIdAsync(string employeeId);
        Task<PostOdsWorkflowActionsInParallelResponse> PostOdsWorkflowActionsInParallelAsync(PostOdsWorkflowActionNameRequest request);
        Task<bool> UpdateWorkflowConfigurationsAsync(List<WorkflowConfigurations> request, int updatedBy);
        Task<int> UpdateWorkflowPmDelegationInfoAsync(List<UpdateWorkflowPmDelegationInfoRequest> request);

        Task<List<string>> UpdateWorkflowConfigurations(UpdateWorkflowConfigurationsRequest rquest);
        Task<List<dynamic>> ODSCheckSendEmail(OdsCheckSendEmailRequest request);
        Task<List<dynamic>> OdsCheckAutoClosureByReqId(OdsCheckAutoClosureByReqIdRequest request);
        Task<dynamic> GetStartEoWorkflowAsync(GetStartEoWorkflowRequest request);

        Task<List<GetWFCumulativeLostOpportunityTrendDataByResponse>> GetWFCumulativeLostOpportunityTrendDataByRequest(GetWFCumulativeLostOpportunityTrendDataByRequest request);
        Task<dynamic> GetFailedInstancesApiRequestAsync(TerminateFailedInstancesApiRequestBody request);
        Task<List<GetTerminatedInstancesLogResponse>> GetTerminatedInstancesLog();
        Task<string> GetHandleCorruptedInstanceAsync(GetHandleCorruptedInstanceRequest request);
        Task<dynamic> TerminateFailedInstancesAsync(TerminateFailedInstancesApiRequestBody request);

        Task<List<GetWorkFlowHandlingReasonsRsponse>> GetWorkFlowHandlingReasons(GetWorkFlowHandlingReasonsRequest request);
    }
}
