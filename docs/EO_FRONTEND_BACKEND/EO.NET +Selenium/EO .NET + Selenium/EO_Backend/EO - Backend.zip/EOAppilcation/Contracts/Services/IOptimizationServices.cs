﻿using EODomain.Models.Network;
using EODomain.Models.Optimization;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Mvc;

namespace EOApplication.Contracts.Services
{
    public interface IOptimizationServices
    {
        Task<dynamic> GetDemandInputsAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetAssetAvailabilityAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetPlantLoadAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetOutputMappingAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetOptimizationPriceInputAsync(CaseIdInputRequest request);    
        Task<dynamic> GetWhatIfPlantParametersAsync(GetWhatIfPlantParametersRequest request);
        Task<dynamic> WhatIfDemandCalculationAsync(WhatIfDemandCalculationRequest request);
        Task<dynamic> WhatIfOutputAsync(WhatIfOutputRequest request);
    }
}
