﻿using EODomain.Models.CCP;

namespace EOApplication.Contracts.Services
{
    public interface ICcpServices
    {
        Task<GetCaseIDPageCountResponse> GetCcpDataAsync(GetCaseIDRequest request);
        Task<OdsInsightsResponse> AddOdsInsights(AddOdsInsightsRequest request);
        Task<OdsInsightsResponse> ResetOdsInsights(ResetOdsInsightsRequest request);
        Task<int> UpdateCCP(UpdateCcpRequest request);
        Task<GetTagDataForUpdateResponse> GetTagDataForUpdateAsync(GetTagDataForUpdateRequest request);
        // Case Details Related
        Task<List<GetCaseDetailsByCaseIDStoredProcedureResponse>> GetCaseDetailsByCaseIDAsync(int userID);
        Task<string> PostUpdateCaseDetailsAsync(UpdateCaseDetailsRequest request);
        Task<string> PostDeleteCaseDetailsAsync(DeleteCaseDetailsRequest request);
        Task<string> PostAddCaseDetailsAsync(InsertCaseDetailsRequest request);
        // CCP PI AF Related
        Task<UpdateTagsCcpAndPiAfResponse> UpdateTagDetailsInAfAndCcpTable(UpdateCcpAndPiAttributeValueRequest request);
        Task<dynamic> GetAffectedModelIdsByTagId(GetAffectedModelIdsByTagIdRequest request);
        Task<dynamic> GetCaseConfigurationPortalInfo();
        Task<dynamic> GetTagsDataForValidationAsync(GetTagsDataByCaseIDRequest request);
        Task<GetTagsDataByCaseIDPageCountResponse> GetEOTagsDataByCaseIDAsync(GetTagsDataByCaseIDRequest request);
        Task<string> AddTagAsync(AddTagRequest request);
        Task<string> UpdateTagAsync(UpdateTagRequest request);
        Task<List<dynamic>> GetBlocksAsync();
        Task<dynamic> GetModelNamesByCaseIdDataAsync(GetModelNamesByCaseIdDataRequest request);
        Task<string> DeleteTagDataAsync(DeleteTagDataRequest request);
        Task<dynamic> GetPipelineMacrosByCaseIdAsync(GetPipelineMacrosByCaseIdRequest request);
        Task<int> UpdatePipelineMacrosAsync(UpdatePipelineMacrosRequest request);
        Task<dynamic> GetMstPipelineMacrosAsync();
        Task<dynamic> GetSwitchConfigurationsAsync();
        Task<dynamic> GetTrnOdsSuggestionByCaseIdAsync(GetTrnOdsByCaseIDRequest request);
        Task<OdsInsightsResponse> AddTrnOdsSuggestionAsync(AddOdsInsightsRequest request);
        Task<List<GetTagDataForValidationStoredProcedureResponse>> GetTagDataForValidationAsync(int caseID);
    }
}
