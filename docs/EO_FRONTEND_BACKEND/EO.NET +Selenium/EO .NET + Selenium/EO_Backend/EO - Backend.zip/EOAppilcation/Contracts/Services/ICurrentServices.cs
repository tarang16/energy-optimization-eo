﻿using EODomain.Models.Current;
using EODomain.Models.Requests;

namespace EOApplication.Contracts.Services
{
    public interface ICurrentServices
    {
        Task<dynamic> GetKpiOutputAsync(int caseID, DateTime time);
        Task<dynamic> GetTimeActualDataAsync(int? caseID);
        Task<dynamic> GetSystemTopTileDataAsync(int caseID, DateTime time);
        Task<GetMonitoringDataStoredProcedurePaginatedResponse> GetMonitoringDataAsync(CaseIdDateTimeApiMonitoringRequest request);
        Task<dynamic> GetTreeDiagramByCaseIDAsync(GetTreeDiagramByCaseIDRequest request);
        Task<dynamic> GetOverviewTrendDataAsync(int? caseID);
        Task<dynamic> GetSeuOutputDataAsync(int caseID, DateTime time);
        Task<dynamic> GetSeecTrendDataAsync(CaseIdTimeRangeGroupByRequest request);
        Task<dynamic> GetEnegryDistributionAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetKevsOutputAsync(CaseIdDateTimeRequest request);
        Task<dynamic> GetMonitoringCategories(GetMonitoringCategoriesRequest request);
    }
}
