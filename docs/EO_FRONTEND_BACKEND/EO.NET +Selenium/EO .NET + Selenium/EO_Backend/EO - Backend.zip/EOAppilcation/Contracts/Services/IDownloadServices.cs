﻿using EODomain.Models.Config;
using EODomain.Models.Download;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOApplication.Contracts.Services
{
    public interface IDownloadServices
    {
        Task<List<GetDownloadTagListResponse>> GetDownloadTagListAsync(GetDownloadTagListRequest request);

        Task<GetDownloadDataResponse> GetDownloadDataAsync(DownloadDataRequest request);
        Task<GetDownloadCaseLevelDataResponse> GetCaseWiseDownloadDataAsync(DownloadCaseWiseDataRequest request);
    }
}
