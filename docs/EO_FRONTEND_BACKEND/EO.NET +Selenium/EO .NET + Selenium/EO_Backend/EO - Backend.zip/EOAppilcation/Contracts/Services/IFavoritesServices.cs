﻿using EODomain.Models;
using EODomain.Models.Favorites;

namespace EOApplication.Contracts.Services
{
    public interface IFavoritesServices
    {
        
        Task<FavTrendRequest> PostDeleteFavoriteTrendByFavIDAsync(int userID, Guid FavID);
        Task<List<PostFavTrendByUserID>> GetAllFavoriteTrendByFavIDAsync(int userID);
        Task<PostFavTrendByUserID> GetFavoriteTrendByFavIDAsync(int userID, Guid FavID);
        Task<FavTrendRequest> PostAddFavoriteTrendByUserIDAsync(int userID, PostFavTrendByUserID request);
        Task<List<PostDeleteFavoriteByFavIDStoredProcedureResponse>> PostDeleteFavoriteByFavIDAsync(PostDeleteFavoriteByFavIDRequest request);
        Task<List<PostAddFavoriteByUserIDStoredProcedureResponse>> PostAddFavoriteByUserIDAsync(PostAddFavoriteByUserIDRequest request);
        Task<List<GetFavoriteByUserIDStoredProcedureResponse>> GetFavoriteByUserIDAsync(int userID);
        
        // User Preferences
        Task<int?> PostUserPreferencesAsync(int userID, object request);
        Task<List<GetUserPreferencesServiceResponse>> GetUserPreferencesAsync(int userID, string key, string? parameter);
        Task<bool> DeleteUserPreferencesAsync(string IDs);
    }
}
