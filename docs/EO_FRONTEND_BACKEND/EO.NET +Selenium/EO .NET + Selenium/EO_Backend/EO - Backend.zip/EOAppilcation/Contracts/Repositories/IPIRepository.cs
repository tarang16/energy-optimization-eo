﻿using EODomain.Models.CCP;
using EODomain.Models.PI;

namespace EOApplication.Contracts.Repositories
{
    public interface IPIRepository
    {
        Task<string> GetPIDataAsync(string ID);
        Task<string> GetPIDataServerAsync();
        Task<string> GetPIPointDataAsync(string ID);
        Task<string> GetPIPointDataAsync(string URL, string encoded);
        Task<string> GetPIRecordedDataAsync(string ID);
        Task<string> GetPIRecordedDataAsync(string ID, int hrs);
        Task<String> GetCurrentRecordedByTagListAsync(string recordURL, string encoded);
        Task<GetValuesForStatusByCaseID> GetValuesForStatusByCaseID(string WebIDURLString, string encoded);

        // Tag Update Related
        Task<string> GetPiTagsByElementAndCategoryNameAsync(string element, string category);
        Task<string> GetChildAttributesForAttributeByWebIdAsync(string webID);
        Task<DynamicRequestExecutionResponse> DynamicRequestExecution(Dictionary<string, object> dynamicObject);
        Task<string> DynamicRequestExecutionWithStringResponse(Dictionary<string, object> dynamicObject);

        // To create static data table
        Task<GetAllPiTagsByCategoryResponse> GetAllPiTagsByCategoryAsync(string databaseWebId, string category, int maxCount, int startIndex);
        Task<DynamicRequestExecutionResponse> UpdateAttributeConstantValue(UpdatePiAfConstantsDataRequest request);
        Task<string> GetDatabaseWebId(string AssetServerName, string DatabaseName);
        
    }
}
