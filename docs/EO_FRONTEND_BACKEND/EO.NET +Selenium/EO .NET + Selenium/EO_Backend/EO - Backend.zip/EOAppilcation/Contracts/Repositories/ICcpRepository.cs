﻿using EODomain.Models.CCP;

namespace EOApplication.Contracts.Repositories
{
    public interface ICcpRepository
    {
        Task<GetCaseIDRepositoryResponse> GetCcpDataAsync(GetCaseIDRequest request);
        Task<OdsInsightsResponse> AddOdsInsights(AddOdsInsightsRequest request);
        Task<OdsInsightsResponse> ResetOdsInsights(ResetOdsInsightsRequest request);
        Task<int> UpdateCCP(UpdateCcpRequest request);
        Task<GetTagDataForUpdateResponse> GetTagDataForUpdateAsync(GetTagDataForUpdateRequest request);
        Task<List<string>> GetPipelineLocationsAsync(int? caseID);

        // Case Details Related
        Task<List<GetCaseDetailsByCaseIDStoredProcedureResponse>> GetCaseDetailsByCaseIDAsync(int userID);
        Task<string> PostUpdateCaseDetailsAsync(UpdateCaseDetailsRequest request);
        Task<string> PostDeleteCaseDetailsAsync(DeleteCaseDetailsRequest request);
        Task<string> PostAddCaseDetailsAsync(InsertCaseDetailsRequest request);


        // CCP PI AF Related
        Task<int> UpsertTagDetailsInCcpTable(UpdateCcpAndPiAttributeValueRequest request);

        Task<dynamic> GetAffectedModelIdsByTagId(GetAffectedModelIdsByTagIdRequest request);
        Task<dynamic> GetCaseConfigurationPortalInfo();
        Task<dynamic> GetCaseConfigurationPortalInfoJsonToDynamic();
        Task<dynamic> GetTagsDataForValidationAsync(GetTagsDataByCaseIDRequest request);
        Task<GetTagsDataByCaseIDPageCountResponse> GetEOTagsDataByCaseIDAsync(GetTagsDataByCaseIDRequest request);
        Task<List<dynamic>> GetBlocksAsync();
        Task<string> AddTagAsync(AddTagRequest request);
        Task<string> UpdateTagAsync(UpdateTagRequest request);
        Task<dynamic> GetModelNamesByCaseIdDataAsync(GetModelNamesByCaseIdDataRequest request);
        Task<string> DeleteTagDataAsync(DeleteTagDataRequest request);
        Task<dynamic> GetPipelineMacrosByCaseIdAsync(GetPipelineMacrosByCaseIdRequest request);
        Task<int> UpdatePipelineMacrosAsync(UpdatePipelineMacrosRequest request);
        Task<dynamic> GetMstPipelineMacrosAsync();
        Task<dynamic> GetSwitchConfigurationsAsync();
        Task<dynamic> GetTrnOdsSuggestionByCaseIdAsync(GetTrnOdsByCaseIDRequest request);
        Task<OdsInsightsResponse> AddTrnOdsSuggestionAsync(AddOdsInsightsRequest request);
        Task<List<GetTagDataForValidationStoredProcedureResponse>> GetTagDataForValidationAsync(int caseID);
    }
}
