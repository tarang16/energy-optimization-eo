﻿using EODomain.Models.CCP;
using EODomain.Models.PI;

namespace EOApplication.Contracts.Services
{
    public interface IPIServices
    {
        Task<string> GetWebIDForStatusByCaseID(string tag);
        String EnCoder(string userName, string password);
        Task<GetPiDataValidationResponse> GetPiTagValidatedAsync(PiDataValidationRequest request);

        // To create static data table
        Task<List<EODomain.Models.PI.Item>> GetAllPiTagsByCategoryAsync(string databaseWebId, string category, int maxCount, int totalItems);

        // To create pi hierarchy
        Task<object> GetPiTagsAndAttributesByElementNameAttributeName(PiElementsAndCategoryRequest piElementsAndCategoryRequest);

    }
}
