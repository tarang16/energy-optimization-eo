﻿using System.Data;
using EODomain.Models.Account;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using EODomain.Models.LogTables;
using EODomain.Models.Account.Workflow;

namespace EOApplication.Contracts.Repositories
{
    public interface IAccountRepository
    {

        Task<List<DeleteRoletoUserStoredProcedureResponse>> DeleteRoletoUserAsync(DeleteRoleForUserRequest request);
        Task<User> GetUserbyLoginIdAsync(string ID, string UrlRequested);
        Task<User> GetUserbyEmployeeIdAsync(int ID);
        Task<List<ClaimDto>> GetClaimsbyUserIdAsync(int ID,string urlRequested);
        Task<bool> AddRolestoUserAsync(int userID, string role, int createdBy);
        Task<List<GetUsersDetailsWithCountryTimeZone>> GetUserByIDNameEmailAsync(string keyword);
        Task<List<PostAddRoleToUsersStoredProcedureResponse>> PostAddRoleToUsersRequestAsync(PostAddRoleToUsersRequest request);
        Task<List<GetUsersByRoleStoredProcedureResponse>> GetUserDetailsAsync(string employeeIDList);
        Task<List<GetRoleDetailsStoredProcedureResponse>> GetRoleDetailsAsync(string role);
        Task<string> GetRolesbyUserIdAsync(int userID, HttpContext context);
        Task<string> GetValidRoleAsync(string role);
        Task<int> GetCaseIDCountFromCaseIDListAsync(string caseIDList);
        Task<int> GetUserCountFromEmployeeListAsync(string employeeIDList);
        Task<GetRolesRoleIdByUserIdStoredProcResponse> GetRolesRoleIDByUserIdAsync(int userID,HttpContext context);
        Task<GetLatestLoginSessionByUserStoredProcedureResponse> GetLatestLoginSessionByUserAsync(int userId,string urlRequested);
        Task LogoutAndEndSessionByUserIdAsync(int userId);
        Task EndUserSessionAsync(int userId);
        Task DeactivateUserTokensAsync(int userId);
        Task<Int32> AddUserToCustomUserTableAsync(AddUserToCustomUserTableRequest request);
        Task<GetLatestLoginSessionByUserStoredProcedureResponse> GetLatestLoginSessionBySessionAsync(string? sessionGuid,string urlRequested);
        Task<GetLatestTokenDataBySessionStoredProcedureResponse> GetTokenSessionLoginDataByTokenAsync(string? tokenGuid,string urlRequested);
        Task<List<GetUsersByRoleStoredProcedureResponse>> GetUsersByRoleAsync(string role);

        // Claims Related
        Task<bool> DeleteClaimFromUserAsync(string deleteIdList, int deleteBy);
        Task<int?> AddClaimsToUsersAsync(DataTable userClaims, int createdBy);
        Task<List<string>> GetValidClaimTypes(string urlRequested);

        // User Authentication Related Information
        Task<GetDataForAuthenticationByUserIdStoredProcedureResponse> GetDataForAuthenticationByUserIdAsync(int userID);

        // Adding user to a role related validation data
        Task<GetValidationDataForAddRoleToUsersStoredProcedureResponse> GetValidationDataForAddRoleToUsersAsync(PostAddRoleToUsersRequest request);

        // Custom Auth Middleware Authentication Data
        Task<GetTokenAuthorizationDataStoredProcedureResponse> GetTokenAuthorizationDataAsync(int userID, string? tokenGuid, HttpContext context);

        // User access and feature access
        Task<dynamic> GetUserFeatureAccessDataAsync(string employeeID);
        Task<dynamic> GetUserAccessDataAsync(string employeeID);

        Task<dynamic> GetUserDetailsWithAffiliateClaimAsync(AffiliateIdListClaimTypeRequest request);

        // Workflow Admin 
        Task<List<GetWorkFlowUsersByRolePlantAffiliateStoredProcedureResponse>> GetWorkflowUsersByRoleAffiliatePlant(string? role , int? affiliateId);
        Task<List<int>> AddWorkflowUsersAsync(string? userIdList, string? role, int? affiliateId, string? managerID,string? createdBy);
        Task<List<GetRolesRoleIdByUserIdStoredProcResponse>> GetValidWorkflowRoles();
        Task<List<GetWorkFlowUserRolesStoredProcedureResponse>> GetWorkflowUserRoles();
        Task<DeleteWorkflowUserStoredProcedureResponse> DeleteWorkflowUserAsync(string? userId, string? role, string? updatedBy);

        Task<bool> LogoutUserAsync(int userId);
        Task<GetRolesRoleIdByUserIdStoredProcResponse> GetUserRoleByIdAsync(int userID, HttpContext context);

        Task<List<DeleteRoletoUserStoredProcedureResponse>> DeleteUerRoleClaimsByUserID(DeleteUerRoleClaimsByUserID request);
    }
}
