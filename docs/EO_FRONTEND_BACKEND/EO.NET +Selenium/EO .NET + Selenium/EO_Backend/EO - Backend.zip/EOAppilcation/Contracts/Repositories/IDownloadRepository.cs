﻿using EODomain.Models.Config;
using EODomain.Models.Download;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOApplication.Contracts.Repositories
{
    public interface IDownloadRepository
    {

        Task<List<GetDownloadTagListResponse>> GetDownloadTagListAsync(GetDownloadTagListRequest request);
        Task<dynamic> GetDownloadDataAsync(DownloadDataRequest model);
        Task<dynamic> GetCaseWiseDownloadDataAsync(DownloadCaseWiseDataRequest request);
       
    }
}
