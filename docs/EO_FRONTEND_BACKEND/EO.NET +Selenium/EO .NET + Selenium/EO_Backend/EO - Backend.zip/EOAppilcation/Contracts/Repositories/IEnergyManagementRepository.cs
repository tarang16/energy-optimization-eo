﻿using Microsoft.AspNetCore.Http;
using EODomain.Models.Config;
using EODomain.Models.Requests;
using EODomain.Models.EnergyManagement;
using EODomain.Common;
using System.Threading.Tasks;


namespace EOApplication.Contracts.Repositories
{
    public interface IEnergyManagementRepository
    {
        Task<dynamic> GetEnpiDailyTrendAsync(GetEnpiDailyTrendRequest request);
        Task<dynamic> GetEquipmentDesignCapacity(GetEquipmentDesignCapacityRequest request);
        Task<dynamic> GetAirWaterSteamValuesAsync(GetAirWaterSteamValuesRequest request);
        Task<dynamic> GetOverallSignificanceEnergyAsync(GetOverallSignificanceEnergyRequest request);
        Task<dynamic> GetEnergyCostIndexEnergyGapMonthlyIndexAsync(GetEnergyCostIndexEnergyGapMonthlyIndexRequest request);
        Task<dynamic> GetCWEnergyCostTrendAsync(GetCWEnergyCostTrendRequest request);
        Task<dynamic> GetCWFlowRateTrendAsync(GetCWFlowRateTrendRequest request);
        Task<dynamic> GetSteamTrendAsync(GetSteamTrendRequest request);
        Task<dynamic> GetAirTrendAsync(GetAirTrendRequest request);

        // Data model binding required
        Task<GetTopSixTilesResponse> GetTopSixTilesAsync(GetOverallSignificanceEnergyRequest request);
        // Data model binding required
        Task<GetTopTileReconciledDataResponse> GetTopTileReconciledDataAsync(GetReconciledEnergyRequest request);

        Task<dynamic> GetPlantAffiliatesAsync(GetPlantAffiliatesRequest request);
        Task<dynamic> GetPlantEnergyEciAirWaterSteamAsync(GetPlantEnergyEciAirWaterSteamRequest request);

        Task<dynamic> GetCwCostPerUnitTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetCwLoadHeatRejectionTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetEciTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetSpecificEnergyCategoryAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetSpecificEnergyCategoryEquipmentAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetSpecificEnergyCategoryEquipmentTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetTopTilePlantsDataAsync(GetPlantEnergyEciAirWaterSteamRequest request);
        Task<dynamic> GetEnergyConsumedSpecificEnergyAsync(AffiliatePlantEquipmentAndCategoryTimeRangeRequest request);
        Task<dynamic> GetEmEnergyGapAsync(AffiliatePlantTimeRangeRequest request);
        Task<dynamic> GetKevStateUomAsync(string? category);
        Task<dynamic> GetEquipmentListAsync(AffiliateEquipmentCategoryPlantNameListRequest request);
    }
}
