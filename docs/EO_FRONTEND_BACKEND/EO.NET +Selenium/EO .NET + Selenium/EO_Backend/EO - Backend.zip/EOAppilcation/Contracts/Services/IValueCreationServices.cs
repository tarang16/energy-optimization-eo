﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EODomain.Models.ValueCreation;

namespace EOApplication.Contracts.Services
{
    public interface IValueCreationServices
    {
        Task<List<GetAllMasterValueCreationDataStoredProcedureResponse>> GetAllMasterValueCreationCaseIDAsync(GetAllValueCreationByCaseIDRequest request);
        Task<int?> PostAddMasterValueCreationDataAsync(PostAddValueCreationDataRequest request, int createdBy);
        Task<List<GetValueCreationSpanDataStoredProcedureResponse?>> GetValueCreationSpanDataByCaseIdAsync(ValueCreationCalcTimeSeriesRequest request);
        Task<string?> PostAddValueCreationSpanDataAsync(PostAddValueCreationSpanDataRequest request, int createdBy);
        Task<List<GetValueCreationSpanDataForCaseResponse>> GetValueCreationSpanCalcAsync(ValueCreationCalcTimeSeriesRequest request);
        Task<bool> PostDeleteValueCreationSpanDataByIdAsync(DeleteRequestUsingGuid request);
        Task<List<GetAllAddTrnValueCreationCaseInfoDataResponse>> GetAllMasterValueCreationCaseInfoAsync(GetAllValueCreationByCaseIDRequest request);
        Task<List<GetVCByCaseIDListGropedResponse?>> GetVCByCaseIDListAsync(GetVCByCaseIDListRequest request);
        Task<List<GetVCSpanAlertResponse?>> GetVCspanAlertAsync(GetVCSpanAlertRequest request);
    }
}
