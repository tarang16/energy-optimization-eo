﻿using EODomain.Common;
using EODomain.Models.Account.Workflow;


namespace EOApplication.Contracts.Repositories
{
    public interface IPeOdsWorkflowRepository
    {
        ///Task<Response<List<GetOdsWorkflowActionLogsServiceLayerResponse>>> GetPeOdsWorkflowActionLogsByRequestId(RequestIdEoRequest request, string environmentUrl, string rootUrl);
        Task<dynamic> GetPeOdsWorkflowActionLogsByRequestId(RequestIdEoRequest request, string environmentUrl, string rootUrl);
        Task<Response<GetWorkflowMetaDataAndDetails>> GetOdsDataByRequestId(RequestIdEoRequest request, string environmentUrl, string rootUrl);
        Task<Response<List<GetOdsActionSuggestionsStoredProcedureResponse>>> GetOdsActionSuggestionsByRequestId(RequestIdEoRequest request, string environmentUrl, string rootUrl);
        Task<Response<List<GetWorkflowHistoricalDataForAllUsersServiceLayerResponse>>> GetWorkflowHistoricalDataForAllUsersAsync(WorkflowCauseIDRequest request, string environmentUrl, string rootUrl);
    }
}
