﻿using EODomain.Models.Enums;
using EODomain.Models.LogTables;

namespace EOApplication.Contracts.Repositories
{
    public interface ILoggingRepository
    {
        Task<bool> AddAPIPerformanceLog(LogApiPerformanceLogs logAPIPerformanceLogs);
        Task<bool> AddActivityLogAsync(LogActivityTracker activityTracker);
        Task<bool> AddPerformanceLogsAsync(LogPerformanceLogs performanceLogs);
        Task<bool> AddErrorLogsAsync(LogErrorLogs logErrorLogs);
        Task<System.Guid> AddLoginLogAsync(AdmUserLoginInsert loginActivity);
        Task<System.Guid> AddSessionLogAsync(AdmUserSessionInsert sessionActivtity);
        Task<bool> AddUserActivityTrackerAsync(ActivityTracker activityTrackerRequest);
        Task<System.Guid> AddTokenLogAsync(AdmUserTokenInsert tokenActivity);
        Task<List<GetAuditLogResponse>> GetAuditLogAsync(GetAuditLogRequest request);
        Task<List<GetValidAuditLogTypesResponse>> GetValidAuditLogTypesAsync();
        Task<bool> PostAuditLogAsync(AddAuditLogRequest request, int createdBy);
        Task<string> GetDefaultValueAsync(GetDefaultValueRequest request);
    }
}
