﻿using EODomain.Models.Network;
using EODomain.Models.Requests;

namespace EOApplication.Contracts.Repositories
{
    public interface INetworkRepository
    {
        Task<dynamic> GetMstNetworkPagesAsync(GetMstNetworkPagesRequest request);
        Task<dynamic> GetTrnNetworkPagesAsync(GetTrnNetworkPagesRequest request);
        Task<dynamic> PostMstNetworkPagesAsync(PostMstNetworkPagesRequest request);
        Task<dynamic> PostTrnNetworkPagesAsync(PostTrnNetworkPagesRequest request);
        Task<dynamic> GetAllTagsByCaseIDAsync(CaseIdInputRequest request);
        Task<dynamic> GetAllTagDataByCaseIDAsync(CaseIdDateTimeRequest request);
    }
}
