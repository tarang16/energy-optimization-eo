﻿using EODomain.Models.CCP;
using EODomain.Models.CcpOptimizer;
using EODomain.Models.Requests;
using System.Data;

namespace EOApplication.Contracts.Repositories
{
    public interface ICcpOptimizerRepository
    {
        Task<List<dynamic>> GetOptimizerVariablesDataByCaseIdAsync(int caseID);
        Task<List<dynamic>> GetOptimizerObjectiveFunctionAsync(int caseID);
        Task<List<dynamic>> GetOptimizerConstraintsAsync(int caseID);
        Task<dynamic> UpdateOptimizerParameterAsync( AddOptimizerParameterRequest request);
        Task<List<dynamic>> GetOptimizerParameterByCaseIdAsync(int caseID);
        Task<dynamic> AddOptimizerVariableAsync(AddOptimizerVariableRequest request);
        Task<dynamic> AddOptimizerDerivedEquationAsync(AddOptimizerDerivedEquationRequest request);
        Task<dynamic> AddOptimizerConstraintAsync(AddOptimizerConstraintRequest request);
        Task<List<dynamic>> GetOptimizerDerivedEquationsAsync(int caseID);
        Task<string> PostDeleteOptimizerConstraintAsync(OptimizerConstraintIdRequest request);
        Task<string> PostDeleteOptimizerDerivedEquationAsync(OptimizerDerivedEquationIdRequest request);
        Task<string> PostDeleteOptimizerVariableAsync(OptimizerVariableIdRequest request);
        Task<List<dynamic>> GetOptimizerConstraintCategoryAsync();
        Task<string> PostDeleteOptimizerParameterAsync(OptimizerParameterIdRequest request);
        Task<dynamic> AddOptimizerObjectiveAsync(AddOptimizerObjectiveRequest request);
        Task<string> UpdateEquipmentAvailabilityAsync(UpdEquipAvaliabilityRequestData request);
        Task<List<dynamic>> GetConfigEquipmentAvailabilityAsync(int caseId);
        Task<string> UpdateOptimizationPriceInputAsync(UpdateOptimizationPriceInput request);
        Task<dynamic> GetSeuDetailsDataAsync(int CaseID);
        Task<dynamic> GetSubModelDataAsync(int CaseID);
        Task<dynamic> UpdateSeuDetailsDataAsync(UpdateSeuDetailsRequest request);
        Task<dynamic?> UpdateSubModelDataAsync(UpdateSubModelRequest request);
        Task<List<GetSubModelParameterSqlResponse>> GetSubModelParameterAsync(GetCaseIDRequest request);
        Task<dynamic?> UpdateSubModelParameterAsync(UpdateSubModelParameterRequest request);
    }
}
