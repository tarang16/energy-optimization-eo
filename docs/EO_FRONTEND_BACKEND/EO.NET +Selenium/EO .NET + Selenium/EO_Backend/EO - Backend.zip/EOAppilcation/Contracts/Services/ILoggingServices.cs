﻿using Microsoft.AspNetCore.Http;
using EODomain.Models.Enums;
using EODomain.Models.LogTables;

namespace EOApplication.Contracts.Services
{
    public interface ILoggingServices
    {
        Task<bool> AddAPIPerformanceLog(LogApiPerformanceLogs logAPIPerformanceLogs);
        Task<bool> AddPerformanceLogsAsync(UpsertLogPerformanceLogs performanceLogs, int userID, string sessionID,HttpContext context);
        Task<bool> AddActivityLogAsync(LogActivityTracker activityTracker);
        Task<System.Guid> AddLoginLogAsync(AdmUserLoginInsert loginActivity);
        Task<System.Guid> AddSessionLogAsync(AdmUserSessionInsert sessionActivtity);
        Task<bool> AddErrorLogAsync(LogErrorLogs logErrorLogs);
        Task<bool> AddUserActivityTrackerAsync(ActivityTrackerRequest activityTrackerRequest, int userID, string sessionID);
        Task<List<GetAuditLogResponse>> GetAuditLogAsync(GetAuditLogRequest request);
        Task<List<GetValidAuditLogTypesResponse>> GetValidAuditLogTypesAsync();
        Task<bool> PostAuditLogAsync(AddAuditLogRequest request, int createdBy);
        Task<string> GetDefaultValueAsync(GetDefaultValueRequest request);
    }
}
