﻿using EODomain.Models;
using EODomain.Models.AIHub;
using EODomain.Models.InfraJobServices;
using EODomain.Models.RequestModels;
using System.Data;

namespace EOApplication.Contracts.Repositories
{
    public interface IHealthInfraRepository
    {
        Task<List<GetAllAvailablePITimeTagResponse>> GetAllAvailablePITimeTag();
        Task<int?> LogInfraStatusAsync(DataTable infraStatus, int createdBy,string urlRequested);
        Task<int?> LogPiDataInfraAsync(DataTable piData, int createdBy,string urlRequested);
        Task<GetInfraStatusFrequencyResponse> GetInfraStatusFrequencyResponse(string service);
        Task<List<GetInfraMonitoringResponse>> GetInfraMonitoringConnectivityAsync(GetInfraMonitoringRequest request);
        Task<List<GetPIDataInfraMonitoringLagTrendResponse>> GetPIDataInfraMonitoringLagTrendAsync(GetPIDataInfraMonitoringLagTrendRequest request);
        Task<List<dynamic>> GetInfraMonitoringCaseWiseAsync(CaseIdListInputRequest request);
        Task<GetInfraMonitoringCaseWiseTrendResponse> GetInfraMonitoringCaseWiseTrendAsync(GetInfraMonitoringCaseWiseRequest request);
        Task<int?> UpdateMasterInfraMonitoring(string serviceUrl, string serviceType,string urlRequested);
        Task<TokenResponse> GetAIHubTokenAsync(int? timeOut);
        Task<GetHealthCheckQueryResponse> GetHealthCheckAsync(string token);
        Task<GetJobAgentsStateByQueueNameQueryResponse> GetJobAgentsStateByQueueNameAsync(string queueName, string token);
        Task<PiConnectionResponse> GetPiConnectionResponse();
        Task<string> GetWebIDForStatusByCaseID(string tag);
        Task<GetValuesForStatusByCaseID> GetValuesForStatusByCaseID(string WebIDURLString);
    }
}
