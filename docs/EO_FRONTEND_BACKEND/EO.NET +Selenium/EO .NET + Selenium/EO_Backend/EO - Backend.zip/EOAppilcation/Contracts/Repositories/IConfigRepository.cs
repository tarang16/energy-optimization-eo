﻿using Microsoft.AspNetCore.Http;
using EODomain.Models.Config;
using EODomain.Models.Requests;

namespace EOApplication.Contracts.Repositories
{
    public interface IConfigRepository
    {
        Task<List<GetCaseHierarchyResponse>> GetCaseHierarchyAsync();
        Task<List<GetLandingCorporateSPResponse>> GetLandingCorporateAsync(string? caseIDList);
        Task<List<GetLandingCorporateSPResponse>> GetLandingAffiliateAsync(string affiliate, string? plantIDList);
        Task<bool> LogoutUserAsync(int userId);
        Task<List<GetViewDataDictionaryByTableNameResponse>> GetViewDataDictionaryByTableNameAsync(GetViewDataDictionaryByTableNameRequest request);
        Task<List<GetCaseInfoByByCaseIdListResponse>> GetCaseInfoByCaseIdListAsync(CaseIdListRequest request);
        Task<dynamic> GetUomAsync();
        Task<List<GetLandingAffiliateSustainabilityCardResponse>> GetLandingAffiliateScoreCardAsync(int affiliateID, string upto);
        Task<dynamic> GetScreenNamesByAffiliateIDsAsync(GetUserStatisticsScreensRequest request);
        Task<int> GetAffiliateIDByCaseID(int caseID);
        Task<int> GetAffiliateIDByDerivedEquationId(int derivedEquationId);
        Task<int> GetAffiliateIDByVariableId(int variableId);
        Task<int> GetAffiliateIDByConstraintId(int constraintId);
        Task<int> GetAffiliateIDByModelTagId(int modelTagId);
        Task<int> GetAffiliateIDByObjectiveId(int objectiveId);
        Task<int> GetAffiliateIDByModelId(int modelId);
        Task<List<GetWalkthroughDataByPagekeyResponse>> GetWalkthroughDataByPageKey(GetWalkthroughDataByPagekeyRequest request);
    }
}
