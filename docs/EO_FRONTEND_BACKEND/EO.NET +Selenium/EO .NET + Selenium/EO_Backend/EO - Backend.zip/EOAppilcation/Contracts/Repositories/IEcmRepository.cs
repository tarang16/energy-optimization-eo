﻿using EODomain.Models.ECM;

namespace EOApplication.Contracts.Repositories
{
    public interface IEcmRepository
    {
        Task<int?> AddEcmUploadInfo(int attachmentID, string attachmentName, int createdBy);
        Task<GeEcmUploadInfoResponse> GeEcmUploadInfo(int attachmentID);
        Task<int?> GetEcmNodeIdByCaseId(int caseId);
        Task<List<GetWalkthroughDataByFurnacePagekeyEcmResponse>> GetdataByPageKey(GetWalkthroughDataByFurnaceEcmRequest request);
    }
}
