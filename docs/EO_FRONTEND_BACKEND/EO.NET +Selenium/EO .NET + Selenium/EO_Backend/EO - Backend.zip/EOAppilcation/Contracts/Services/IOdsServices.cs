﻿using EODomain.Models.Config;
using EODomain.Models.Ods;


namespace EOApplication.Contracts.Services
{
    public interface IOdsServices
    {
        Task<List<GetPeOdsDetailsByOdsIdListTimeStoredProcResponse>> GetOdsOveriewByCaseIdTimeAsync(OdsCaseIdDateTimeRequest request);
        Task<List<GetOdsDataForPlantByCaseIDListTimeRangeApiResponse>> GetOdsDataByCaseIDListAsync(string caseIDList, string? sTime, string? eTime);
        Task<List<GetOdsKpiTagByCaseIDStoredProcedureResponse>> GetOdsKpiTagByCaseIDAsync(int caseID);
        Task<List<GetOdsDataForPlantByCaseIDListTimeRangeApiResponse>> GetOdsDataForPlantByCaseIDListTimeRangeAsync(OdsCaseIdListTimeRangeStringRequest request);
        Task<GetOdsAlertStatisticsByCaseIDListResponse> GetOdsAlertStatisticsByCaseIDList(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsForRoleResponse>> GetOdsAlertStatisticsForRole(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsPendingAlertsResponse>> GetOdsAlertStatisticsPendingAlerts(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsOverdueAlertsResponse>> GetOdsAlertStatisticsOverDueAlerts(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsInProgressAlertsResponse>> GetOdsAlertStatisticsInProgressAlerts(OdsCaseIdListRequest request);
        Task<GetOdsClosedAlertStatisticsByCaseIDListResponse> GetOdsClosedAlertStatisticsByCaseIDList(string caseIDList, DateTime month);
        Task<List<GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsResponse>> GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsAsync(OdsCaseIdListRequest request);
        Task<List<GetOdsAlertStatisticsByCaseIdListAndStateStoredProcedureResponse>> GetOdsAlertStatisticsByCaseIdListAndStateAsync(GetOdsAlertStatisticsByCaseIdListAndStateRequest request);
        Task<List<OdsTimeSeries>> GetOdsTrendDataByRequestIdAndTimeRangeAsync(RequestIdTimeStringRangeRequest request);
        Task<GetDownloadDataResponse> GetOdsAlertStatisticsDownloadDataAsync(OdsStatisticsDownloadDataRequest request);
        Task<string> UpdatemutealertslogByCauseIdListAsync(UpdateMuteAlertsLogByCauseId request);
        Task<List<dynamic>> GetmutealertslogAsync(MuteAlertsLogRequest request);
        Task<string> UpdatePeOdsAlertDetailsAsync(UpdatePeOdsAlertDetails request);
        Task<List<dynamic>> GetOdsAlertStatisticsDownloadDataComments(OdsCaseIdListRequest request);
    }
}
