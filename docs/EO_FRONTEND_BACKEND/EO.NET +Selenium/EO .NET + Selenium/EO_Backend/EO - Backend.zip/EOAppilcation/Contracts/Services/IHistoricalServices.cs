﻿using EODomain.Models.HistoricalData;
using EODomain.Models.Requests;

namespace EOApplication.Contracts.Services
{
    public interface IHistoricalServices
    {
        Task<dynamic> GetCalenderDataAsync(int? caseID);
        Task<List<GetActualOptimumTrendDataResponse>> GetActualOptimumTrendDataAsync(GetTrendDataActualOptimumRequest request);
        Task<dynamic> GetOpportunityTrendDataAsync(CaseIdListTimeRangeStringRequest request);
        Task<dynamic> GetDataModelSkipMonitoringCalendarDataAsync(CaseIdTimeRangeRequest request);
        Task<GetDataModelSkipServiceLayerPaginatedResponse> GetDataModelSkipDataAsync(CaseIdTimeRangeDayDiffRequest request);
    }
}
