﻿
using EODomain.Models.Admin;
using EODomain.Models.LogTables;
using EODomain.Models.Search;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOApplication.Contracts.Repositories
{
    public interface IAdminRepository
    {
        Task<GetUserActivityStaticDataBySessionIDStoredProcedureResponse> GetUserActivityStaticDataBySessionIDAsync(string sessionID);
        Task<GetUserActivityDynamicDataBySessionIDRepositoryResponse> GetUserActivityDynamicDataBySessionIDAsync(string sessionID, int pageNumber , int pageSize);
        Task<bool> ModifyErrorStatusByErrorID(int errorID, string? status, string? assignedTo);
        Task<GetActivityTrackerLogsRepositoryLayerResponse> GetActivityTrackerLogsAsync(Dictionary<string, object> request, int pageNumber, int pageSize);
        Task<GetApiRequestLogsRepositoryLayerResponse> GetApiRequestLogsAsync(Dictionary<string, object> requestData, int pageNumberOne, int pageSizeOne);
        Task<GetPerformanceLogsRepositoryLayerResponse> GetPerformanceLogsAsync(PaginatedSearch paginatedSearch);
        Task<GetQueryTrackerLogsRepositoryLayerResponse> GetQueryTrackerLogsAsync(Dictionary<string, object> request, int pageNumberTwo, int pageSizeTwo);
        Task<GetLoginTrackerRepositoryLayerResponse> GetLoginLogsAsync(PaginatedSearch paginatedSearch);
        Task<GetErrorTrackingRepositoryLayerResponse> GetErrorLogsAsync(PaginatedSearch paginatedSearch);
        Task<List<string>> GetValidErrorStatusList();

        // User Statistics
        Task<GetUserStatisticsStoredProcedureResponse> GetUserStatisticsAsync(GetUserStatisticsRequest request);
        Task<GetUserStatisticsLogsPaginatedResponse> GetUserStatisticsLogsAsync(GetUserStatisticsLogsRequest request);
        Task<GetUserAnalyticsLogsPaginatedResponse> GetUserAnalyticsLogsAsync(GetUserAnalyticsLogsRequest request);
        Task<GetUserStatisticsGraphDataCombinedResponse> GetUserStatisticsGraphDataAsync(GetUserStatisticsGraphDataRequest request);
        Task<GetUserAnalyticsScreenWiseStoredProcedureResponse> GetUserAnalyticsScreenWiseAsync(GetUserAnalyticsScreenWiseRequest request);
        Task<List<GetUserStatisticsOnlineUsersStoredProcedureResponse>> GetUserStatisticsOnlineUsersAsync(GetUserStatisticsOnlineUsersRequest request);
    }
}
