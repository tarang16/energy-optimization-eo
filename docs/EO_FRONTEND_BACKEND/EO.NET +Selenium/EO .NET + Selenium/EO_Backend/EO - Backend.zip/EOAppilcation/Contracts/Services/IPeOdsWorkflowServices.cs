﻿using EODomain.Models.Config;
using EODomain.Models.Account.Workflow;
using EODomain.Common;


namespace EOApplication.Contracts.Services
{
    public interface IPeOdsWorkflowServices
    {
        ///Task<Response<List<GetOdsWorkflowActionLogsServiceLayerResponse>>> GetPeOdsWorkflowActionLogsByRequestId(RequestIdEoRequest request, string rootURL);
        Task<dynamic> GetPeOdsWorkflowActionLogsByRequestId(RequestIdEoRequest request, string rootURL);
        Task<Response<GetWorkflowMetaDataAndDetails>> GetOdsDataByRequestId(RequestIdEoRequest request, string rootURL);
        Task<Response<List<GetOdsActionSuggestionsStoredProcedureResponse>>> GetOdsActionSuggestionsByRequestId(RequestIdEoRequest request, string rootURL);
        Task<Response<List<GetWorkflowHistoricalDataForAllUsersServiceLayerResponse>>> GetWorkflowHistoricalDataForAllUsersAsync(WorkflowCauseIDRequest request, string rootURL);
    }
}
