﻿using EODomain.Common;
using System.Security.Claims;
using EODomain.Models.Account;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using EODomain.Models.ValidationModels;
using EODomain.Models.Account.Workflow;

namespace EOApplication.Contracts.Services
{
    public interface IAccountServices
    {
        Task<List<DeleteRoletoUserStoredProcedureResponse>> DeleteRoletoUserAsync(DeleteRoleForUserRequest request);
        Task<List<GetUsersByRoleStoredProcedureResponse>> GetUsersByRoleAsync(string role);
        Task<List<GetUsersDetailsWithCountryTimeZone>> GetUserByIDNameEmailAsync(string keyword);
        Task<List<PostAddRoleToUsersStoredProcedureResponse>> PostAddRoleToUsersRequestAsync(PostAddRoleToUsersRequest request);
        Task<string> GetValidRoleAsync(string role);
        Task<int> GetCaseIDCountFromCaseIDListAsync(string caseIDList);
        Task<int> GetUserCountFromEmployeeListAsync(string employeeIDList);
        List<string> GetUsersToAddAndExistingUsers(List<GetUsersByRoleStoredProcedureResponse> userRoleData, string userIDList);
        Task<User> GetUserbyEmployeeIdAsync(int ID);
        Task<Int32> AddUserToCustomUserTableAsync(AddUserToCustomUserTableRequest request);
        Task<Response<string>> DeleteClaimsFromUserAsync(DeleteClaimFromUserRequest request, int currentUserId);

        // To user using their domain login ID
        Task<User> GetUserbyLoginIdAsync(string ID, string UrlRequested);
        // Add multiple users to multiple claims
        Task<int?> AddClaimsToUsersAsync(AddClaimToUserRequest request, int createdBy);
        
        Task<GetDataForAuthenticationByUserIdStoredProcedureResponse> GetDataForAuthenticationByUserIdAsync(int userID);
        Task<AddUserToRoleValidationResponse> ValidationsPostAddRoleToUsers(PostAddRoleToUsersRequest request);

        // To Fetch claims for users
        Task<List<ClaimDto>> GetClaimsbyUserIdAsync(int ID, string urlRequested);

        // Custom Auth Middleware Authentication Data
        Task<GetTokenAuthorizationDataStoredProcedureResponse> GetTokenAuthorizationDataAsync(int userID, string? tokenGuid, HttpContext context);

        // To generate new token when admin action is taken
        Task<string> GenerateNewTokenWhenAdminActionTakenAsync(ClaimsPrincipal claimUser, HttpContext context, HttpRequest request);

        Task<GetUserAccessDetailsByEmployeeIDApiResponse> GetUserAccessdataByEmployeeIDAsync(string employeeID);
        Task<dynamic> GetUserDetailsWithAffiliateClaimAsync(AffiliateIdListClaimTypeRequest request);

        Task<List<string>> GetValidClaimTypes(string urlRequested);


        // Workflow Admin 
        Task<List<GetWorkFlowUsersByRolePlantAffiliateStoredProcedureResponse>> GetWorkflowUsersByRoleAffiliatePlantAsync(string? role=null , int? plantID=null);
        Task<List<int>> AddWorkflowUsersAsync(string? userIdList, string? role, int? affiliateId, string? managerID, string? createdBy);
        Task<List<GetRolesRoleIdByUserIdStoredProcResponse>> GetValidWorkflowRoles();
        Task<StatusMessageResponse> WorkflowUserAdditionValidation(string userID, string role, int? plantID);
        Task<GetWorkFlowUserRolesStoredProcedureResponse> GetWorkflowRequestRole(AddWorkflowUserRequest request);
        Task<DeleteWorkflowUserStoredProcedureResponse> DeleteWorkflowUserAsync(string? userId, string? role, string? updatedBy);
        Task<List<GetWorkFlowUserRolesStoredProcedureResponse>> GetWorkflowUserRoles();
        Task<bool> LogoutUserAsync(int userId);
        Task<StatusMessageResponse> AddClaimToUserRequestValidation(AddClaimToUserRequest request, HttpContext httpContext);

        Task<List<DeleteRoletoUserStoredProcedureResponse>> DeleteUerRoleClaimsByUserID(DeleteUerRoleClaimsByUserID request);


    }
}
