﻿using EODomain.Models.Account.Workflow;
using EODomain.Models.Email;
using EODomain.Models.RequestModels;
using EODomain.Models.Workflow;
using System;
using System.Data;

namespace EOApplication.Contracts.Repositories
{
    public interface IWorkflowRepository
    {
        Task<bool> AddMuteWorkflowNotificationsDataAsync(MuteWorkflowNotificationRequest request);
        Task<GetWorkflowMutedAlertByCauseIdStoredProcedureResponse> GetWorkflowMutedAlertByCauseIdAsync(CauseIdTimeInputRequest request);
        Task<List<GetOdsWorkflowActionLogsStoredProcedureResponse>> GetOdsWorkflowActionLogsByRequestIdAsync(int requestId);
        Task<List<GetWorkflowAssignedAlertListByUserIdStoredProcedureResponse>> GetWorkflowAssignedListByUserID(string userIdList);
        Task<List<GetOdsActionSuggestionsStoredProcedureResponse>> GetOdsActionSuggestionsByRequestIdAsync(int requestId, bool connectionFlag);
        Task<List<GetOdsAssigneeListStoredProcedureResponse>> GetOdsAssigneeListByRequestIdAsync(int requestId, byte isReassignment);
        Task<string> UpdateTemporaryStatusOfWorkflowRequestsAsync(DataTable dataTable);
        Task<GetOdsAssigneeStoredProcedureResponse> GetOdsAssigneeByRequestIdAsync(int requestId);
        Task<List<GetOdsDataStoredProcedureResponse>> GetOdsDataByRequestIdAsync(int requestId);
        Task<List<GetWorkflowHistoricalDataForAllUsersStoredProcedureResponse>> GetWorkflowHistoricalDataForAllUsersAsync(int reqId);
        Task<List<GetWorkflowHistoricalDataForAllUsersStoredProcedureResponse>> GetWorkflowHistoricalDataAsync(int reqId);
        Task<List<WorkflowConfigurations>> GetWorkflowConfigurationsAsync(GetWorkflowConfigurationsRequest request);
        Task<dynamic> UpdateWorkflowConfigurationsAsync(DataTable dataTable, int updatedBy);
        Task<int> UpdateWorkflowPmDelegationInfoAsync(DataTable dataTable);
        Task<SendEmailNotificationInput> GetWfDelegationMail(string assignedTo,string actionBy);
        Task<List<GetWorkflowPmDelegationInfoByEmployeeIdStoredProcResponse>> GetWorkflowPmDelegationInfoByEmployeeIdAsync(string employeeID);
        Task<int> PostOdsWorkflowActionAsync(PostOdsWorkflowActionNameRequest request);
        Task<GetWorkflowPmDelegationInfoStoredProcedureResponse> GetWorkflowPmDelegationInfoAsync(EmployeeIdInputRequest request);
        Task<List<string>> UpdateWorkflowConfigurations(UpdateWorkflowConfigurationsRequest request);
        Task<List<dynamic>> ODSCheckSendEmail(OdsCheckSendEmailRequest request);
        Task<List<dynamic>> OdsCheckAutoClosureByReqId(OdsCheckAutoClosureByReqIdRequest request);
        Task<string> PEODSValidateAssigneeByRequestIdAsync(PostOdsWorkflowActionRequest request);
        Task<string> UpdatePeOdsAlertDetailsAsync(PostOdsWorkflowActionRequest request);
        Task<dynamic> OdsGetNewEmailDataAsync(int requestID);
        Task<dynamic> OdsUpdateLogSentEmailAsync(int requestID,string statusName,string message);
        Task<dynamic> GetStartEoWorkflowAsync(GetStartEoWorkflowRequest request);
        Task<List<GetWFCumulativeLostOpportunityTrendDataByResponse>> GetWFCumulativeLostOpportunityTrendDataByRequest(GetWFCumulativeLostOpportunityTrendDataByRequest request);
        Task<List<GetTerminatedInstancesLogResponse>> GetTerminatedInstancesLog();
        Task<dynamic> AddTerminatedInstanceLog(DataTable TerminatedInstanceLog, string createdBy);
        Task<List<GetWorkFlowHandlingReasonsRsponse>> GetWorkFlowHandlingReasons(GetWorkFlowHandlingReasonsRequest request);
    }
}
