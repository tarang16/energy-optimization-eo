﻿using EODomain.Models.CCP;
using EODomain.Models.CcpOptimizer;
using EODomain.Models.Requests;
using System.Data;

namespace EOApplication.Contracts.Services
{
    public interface ICcpOptimizerServices
    {

        Task<List<dynamic>> GetOptimizerConstraintsAsync(int caseID);
        Task<List<dynamic>> GetOptimizerVariablesDataByCaseIdAsync(int caseID);
        Task<List<dynamic>> GetOptimizerParameterByCaseIdAsync(int caseID);
        Task<List<dynamic>> GetOptimizerDerivedEquationsAsync(int caseID);
        Task<List<dynamic>> GetOptimizerObjectiveFunctionAsync(int caseID);
        Task<dynamic> AddOptimizerObjectiveAsync(AddOptimizerObjectiveRequest request);
        Task<dynamic> AddOptimizerDerivedEquationAsync(AddOptimizerDerivedEquationRequest request);
        Task<dynamic> AddOptimizerVariableAsync(AddOptimizerVariableRequest request);
        Task<dynamic> AddOptimizerConstraintAsync(AddOptimizerConstraintRequest request);  
        Task<dynamic> UpdateOptimizerParameterAsync(AddOptimizerParameterRequest request);
        Task<string> PostDeleteOptimizerDerivedEquationAsync(OptimizerDerivedEquationIdRequest request);
        Task<string> PostDeleteOptimizerVariableAsync(OptimizerVariableIdRequest request);
        Task<string> PostDeleteOptimizerConstraintAsync(OptimizerConstraintIdRequest request);
        Task<string> PostDeleteOptimizerParameterAsync(OptimizerParameterIdRequest request);
        Task<List<dynamic>> GetOptimizerConstraintCategoryAsync();

        
        Task<string> UpdateEquipmentAvailabilityAsync(UpdEquipAvaliabilityRequestData request);
        Task<List<dynamic>> GetConfigEquipmentAvailabilityAsync(int caseID);
        Task<string> UpdateOptimizationPriceInputAsync(UpdateOptimizationPriceInput request);
        Task<dynamic> GetSeuDetailsDataAsync(int CaseID);
        Task<dynamic> GetSubModelDataAsync(int CaseID);
        Task<dynamic> UpdateSeuDetailsDataAsync(UpdateSeuDetailsRequest request);
        Task<dynamic?> UpdateSubModelDataAsync(UpdateSubModelRequest request);
        Task<dynamic?> GetSubModelParameterAsync(GetCaseIDRequest request);
        Task<dynamic?> UpdateSubModelParameterAsync(UpdateSubModelParameterRequest request);
    }
}
