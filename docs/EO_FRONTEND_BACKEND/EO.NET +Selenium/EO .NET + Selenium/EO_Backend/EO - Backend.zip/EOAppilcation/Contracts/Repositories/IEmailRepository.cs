﻿using System.Data;
using EODomain.Models;
using EODomain.Models.Workflow;
using EODomain.Models.Account;
using EODomain.Models.Email;

namespace EOApplication.Contracts.Repositories
{
    public interface IEmailRepository
    {
        Task<SendEmailNotificationInput> GetEmailRepository(string urlRequested);
        Task<UpdateEmailListResponse> AddEmailListAsync(UpdateEmailListRequest request);
        Task<SendEmailNotificationInput> GetEmailRepositoryAsync(GetEmailByIDRequest request);
        Task<List<SendEmailNotificationInput>> GetAllEmailRepositoryAsync();
        public Task<dynamic> GetSlownessDataReport(string UrlRequested);
        public Task<dynamic> GetFailureDataReport(string urlRequested);
        Task<UpdateEmailListResponse> AddEmailAsync(SendEmailNotificationInput request,string urlRequested);
        Task<List<GetWorkflowReportForMailResponse>> GetWorkflowReportForMail(string urlRequested);
        Task<List<GetWorkflowMailIdsForReportMailResponse>> GetWorkflowMailIdsForReportMail(string type, string urlRequested);
        Task<List<GetWorkflowReportForMailResponse>> GetWorkflowEscalationReportForMail(string urlRequested);
        Task<WorkflowEmailLastTriggeredInfo> GetWorkflowLastTriggeredInfo(string type, string urlRequested);
        Task<int?> UpdateWorkflowLastTriggeredInfo(string type, string urlRequested);
        Task<List<GetUsersByRoleStoredProcedureResponse>> GetUsersByRoleAsync(string userRole);
        Task<GetGlobalSetting> GetGlobalSetting(string activityName);
        Task<User> GetUserByEmployeeID(int userID);
        Task<List<GetUserIDByUserClaimID>> GetEmployeeIDByUserClaimID(string userClaimID);
        Task<List<GetUsersByRoleStoredProcedureResponse>> GetUserDetailsAsync(string employeeIDList);        
        string GetEnvironmentName();
        Task<List<GetEmailHtmlBodyForUserAccessChangeEmailData>> GetEmailHtmlBodyForUserAccessChangeEmail(string projectCode);
        Task<GetWorkflowProcessInstanceErrorsMail> GetWorkFlowProcessInstanceErrorsMailAsync();
    }
}
