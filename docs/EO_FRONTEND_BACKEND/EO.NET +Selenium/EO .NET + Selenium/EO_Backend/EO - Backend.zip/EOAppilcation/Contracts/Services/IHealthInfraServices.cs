﻿using EODomain.Models;
using EODomain.Models.RequestModels;

namespace EOApplication.Contracts.Services
{
    public interface IHealthInfraServices
    {
        Task<int?> LogInfraServicesStatusAsync(string urlRequested);
        Task<List<GetInfraMonitoringResponse>> GetInfraMonitoringConnectivityAsync(GetInfraMonitoringRequest request);
        Task<List<GetPIDataInfraMonitoringLagTrendResponse>> GetPIDataInfraMonitoringLagTrendAsync(GetPIDataInfraMonitoringLagTrendRequest request);
        Task<List<dynamic>> GetInfraMonitoringCaseWiseAsync(CaseIdListInputRequest request);
        Task<GetInfraMonitoringCaseWiseTrendResponse> GetInfraMonitoringCaseWiseTrendAsync(GetInfraMonitoringCaseWiseRequest request);
    }
}
