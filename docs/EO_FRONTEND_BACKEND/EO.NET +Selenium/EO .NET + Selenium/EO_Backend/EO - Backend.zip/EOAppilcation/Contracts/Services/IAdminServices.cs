﻿
using EODomain.Models.Account;
using EODomain.Models.Admin;
using EODomain.Models.LogTables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Contracts
{
    public interface IAdminServices
    {
        Task<GetUserActivityDataBySessionIDResponse> GetUserActivityDataBySessionIDAsync(string sessionID, int pageNumber = 1, int pageSize = 20);
        Task<bool> ModifyErrorStatusByErrorID(int errorID, string? status, string? assignedTo);
        Task<GetActivityTrackerLogsRepositoryLayerResponse> GetActivityTrackerLogsAsync(int pageNumber, int pageSize, string keyword);
        Task<GetApiRequestLogsRepositoryLayerResponse> GetApiRequestLogsAsync(int pageNumber, int pageSize, string keyword);
        Task<GetPerformanceLogsRepositoryLayerResponse> GetPerformanceLogsAsync(int pageNumber, int pageSize, string keyword);
        Task<GetQueryTrackerLogsRepositoryLayerResponse> GetQueryTrackerLogsAsync(int pageNumber, int pageSize, string keyword);
        Task<GetLoginTrackerRepositoryLayerResponse> GetLoginLogsAsync(int pageNumber, int pageSize, string keyword);
        Task<GetErrorTrackingRepositoryLayerResponse> GetErrorLogsAsync(int pageNumber, int pageSize, string keyword);
        Task<List<string>> GetValidErrorStatusList();

        // User Statistics
        Task<GetUserStatisticsStoredProcedureResponse> GetUserStatisticsAsync(GetUserStatisticsRequest request);
        Task<GetUserStatisticsLogsPaginatedResponse> GetUserStatisticsLogsAsync(GetUserStatisticsLogsRequest request);
        Task<GetUserAnalyticsLogsPaginatedResponse> GetUserAnalyticsLogsAsync(GetUserAnalyticsLogsRequest request);
        Task<GetUserStatisticsGraphDataCombinedResponse> GetUserStatisticsGraphDataAsync(GetUserStatisticsGraphDataRequest request);
        Task<GetUserAnalyticsScreenWiseStoredProcedureResponse> GetUserAnalyticsScreenWiseAsync(GetUserAnalyticsScreenWiseRequest request);
        Task<List<GetUserStatisticsOnlineUsersStoredProcedureResponse>> GetUserStatisticsOnlineUsersAsync(GetUserStatisticsOnlineUsersRequest request);
    }
}
