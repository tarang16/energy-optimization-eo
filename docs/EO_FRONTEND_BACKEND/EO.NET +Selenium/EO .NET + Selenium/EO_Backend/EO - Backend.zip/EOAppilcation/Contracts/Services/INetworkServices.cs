﻿using EODomain.Models.Network;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Mvc;

namespace EOApplication.Contracts.Services
{
    public interface INetworkServices
    {
        Task<dynamic> GetMstNetworkPagesAsync(GetMstNetworkPagesRequest request);
        Task<dynamic> GetTrnNetworkPagesAsync(GetTrnNetworkPagesRequest request);
        Task<dynamic> PostMstNetworkPagesAsync(PostMstNetworkPagesRequest request);
        Task<dynamic> PostTrnNetworkPagesAsync(PostTrnNetworkPagesRequest request);
        Task<dynamic> GetAllTagsByCaseIDAsync(CaseIdInputRequest request);
        Task<dynamic> GetAllTagDataByCaseIDAsync(CaseIdDateTimeRequest request);
    }
}
