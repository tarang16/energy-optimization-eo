﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdateTagsCcpAndPiAfResponse
    {
        public int status { get; set; }
        public string? message { get; set; }
        public Attributes? attributes { get; set; } = new Attributes();
    }

    [ExcludeFromCodeCoverage]
    public class Attributes
    {
        public List<string>? attributes_success { get; set; } = new List<string>();
        public List<string>? attributes_failed { get; set; } = new List<string>();
    }

    [ExcludeFromCodeCoverage]
    public class UpdatePiAfConstantResponse
    {
        public int status { get; set; }
        public string? message { get; set; }
    }
}
