﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class GetWalkthroughDataByFurnaceEcmRequest
    {
        public string? pageKey { get; set; }
    }
}
