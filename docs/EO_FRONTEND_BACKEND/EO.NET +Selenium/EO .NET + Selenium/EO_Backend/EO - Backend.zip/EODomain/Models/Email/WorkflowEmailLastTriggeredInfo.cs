﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class WorkflowEmailLastTriggeredInfo
    {
        public DateTime? LastTriggeredTime { get; set; }
        public int? MinuteFrequency { get; set; }
    }
}
