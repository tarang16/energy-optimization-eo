﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetUserAccessDetailsByEmployeeIDApiResponse
    {
        public dynamic? roles { get; set; }
        public dynamic? features { get; set; }
    }
}
