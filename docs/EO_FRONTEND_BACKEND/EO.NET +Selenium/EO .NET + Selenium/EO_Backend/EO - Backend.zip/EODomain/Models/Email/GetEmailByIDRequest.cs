﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class GetEmailByIDRequest
    {
        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? projectCode { get; set; }
    }
}
