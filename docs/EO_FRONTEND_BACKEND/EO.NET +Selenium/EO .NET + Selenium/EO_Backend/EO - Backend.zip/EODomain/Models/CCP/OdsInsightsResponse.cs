﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class OdsInsightsResponse
    {
        public string? Result { get; set; }
    }
}
