﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsLogsStoredProcedureResponse
    {
        public int? employeeId { get; set; }
        public string? employeeName { get; set; }
        public string? roleName { get; set; }
        public string? screenName { get; set; }
        public int? screenAccessedTimeInSec { get; set; }
    }
}
