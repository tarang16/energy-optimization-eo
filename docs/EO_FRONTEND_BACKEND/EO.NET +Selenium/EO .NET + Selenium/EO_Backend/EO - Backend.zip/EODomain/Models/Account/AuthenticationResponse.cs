﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class AuthenticationResponse
    {
        public string? Token { get; set; }
        public int StatusCode { get; set; }
    }
}
