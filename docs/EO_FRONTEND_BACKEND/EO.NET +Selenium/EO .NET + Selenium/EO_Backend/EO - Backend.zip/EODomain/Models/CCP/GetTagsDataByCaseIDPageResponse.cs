﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagsDataByCaseIDPageResponse
    {
       
            public int? tagID { get; set; }
            public int? modelTagID { get; set; }
            public int? modelID { get; set; }
            public string? tagName { get; set; }
            public string? description { get; set; }
            public string? uiDisplayName { get; set; }
            public string? piName { get; set; }
            public string? uom { get; set; }
            public int? uomID { get; set; }
            public string? tagType { get; set; }
            public string? inferredExpression { get; set; }
            public string? dataType { get; set; }
            public bool? active { get; set; }
            public bool? flagMA { get; set; }
            public bool? flagMAFilter { get; set; }
            public bool? flagDataAvailableCheck { get; set; }
            public bool? flagOutput { get; set; }
            public bool? flagOutputRunAlways { get; set; }
            public bool? flagParameter { get; set; }
            public string? designExpression { get; set; }
            public int? blockID { get; set; }
            public string? blockName { get; set; }
            public string? polarityExpression { get; set; }
            public int? caseID { get; set; }
            public string? modelName { get; set; }
            public string? modelDescription { get; set; }
            public string? modelType { get; set; }
        }
    }

