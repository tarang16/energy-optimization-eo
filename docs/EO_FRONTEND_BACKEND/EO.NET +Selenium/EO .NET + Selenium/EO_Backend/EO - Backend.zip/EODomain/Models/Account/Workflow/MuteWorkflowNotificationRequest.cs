﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class MuteWorkflowNotificationRequest
    {
        public int causeId { get; set; }
        public DateTime muteTill { get; set; }
        public string? mutedBy { get; set; }
        public int roleId { get; set; }
        public int? reasonID { get; set; }
        public string? comment { get; set; }
    }
}
