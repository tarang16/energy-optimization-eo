﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetAffectedModelIdsByTagIdRequest
    {
        [Required]
        [Range(0, 100000000)]
        public int tagId { get; set; }
        [Required]
        [Range(0, 100000000)]
        public int modelId { get; set; }
    }
}
