﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CcpOptimizer
{
    [ExcludeFromCodeCoverage]
    public class GetSubModelParameterSqlResponse
    {
        public int? subModelParameterID { get; set; }
        public string? parameter { get; set; }
        public string? value { get; set; }
        public string? subModelName { get; set; }
        public int? subModelVersion { get; set; }
        
    }
}
