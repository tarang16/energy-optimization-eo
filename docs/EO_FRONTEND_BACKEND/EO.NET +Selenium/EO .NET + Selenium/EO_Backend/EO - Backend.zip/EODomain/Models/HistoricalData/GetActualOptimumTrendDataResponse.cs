﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.HistoricalData
{
    [ExcludeFromCodeCoverage]
    public class GetActualOptimumTrendDataResponse
    {
        public string? tagName { get; set; }
        public double? max { get; set; }
        public double? min { get; set; }
        public bool? isOnlyActual { get; set; }
        public List<ActualOptimumTrendResponse>? data { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class ActualOptimumTrendResponse
    {
        public double? a { get; set; }
        public double? o { get; set; }
        public long? t { get; set; }
        public int? r { get; set; }
    }
}
