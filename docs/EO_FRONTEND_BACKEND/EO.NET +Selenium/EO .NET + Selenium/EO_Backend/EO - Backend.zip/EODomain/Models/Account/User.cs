﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class User
    {
        public int wmUserDetailId { get; set; } = 0;
        public string? employeeId { get; set; } = string.Empty;
        public string? employeeName { get; set; } = string.Empty;
        public string? firstName { get; set; } = string.Empty;
        public string? lastName { get; set; } = string.Empty;
        public string? domainLoginId { get; set; } = string.Empty;
        public string? affiliateCode { get; set; } = string.Empty;
        public string? affiliateName { get; set; } = string.Empty;
        public string? email { get; set; } = string.Empty;
        public string? country { get; set; } = string.Empty;
        public string? region { get; set; } = string.Empty;
        public string? timeZone { get; set; } = string.Empty;
        public bool isActive { get; set; } = false;
        public DateTime createdDate { get; set; } = DateTime.MinValue;

    }
}
