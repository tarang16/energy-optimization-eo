﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class PiElementsAndCategoryRequest
    {
        public string? elementName { get; set; }
        public string? category { get; set; }
        public string? databaseWebId { get; set; }
    }
}
