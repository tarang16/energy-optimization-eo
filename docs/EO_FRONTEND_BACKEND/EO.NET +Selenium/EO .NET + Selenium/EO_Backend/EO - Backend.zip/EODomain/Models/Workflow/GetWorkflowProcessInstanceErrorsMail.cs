﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public  class GetWorkflowProcessInstanceErrorsMail
    {
        public int? plantId { get; set; }
        public string? plantName { get; set; }
        public string? affiliateName { get; set; }
        public string? emailSubject { get; set; }
        public string? emailBody { get; set; }
    }
}
