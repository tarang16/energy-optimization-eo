﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class TriggerWorkflowCommonServiceRequest
    {
        public string? actionName { get; set; }
        public int targetDate { get; set; }
        public int requestId { get; set; }
        public string? assignedTo { get; set; }
        public string? assignedBy { get; set; }
        public string? stageId { get; set; }
        public double targetDifference { get; set; } = 0;
    }
}
