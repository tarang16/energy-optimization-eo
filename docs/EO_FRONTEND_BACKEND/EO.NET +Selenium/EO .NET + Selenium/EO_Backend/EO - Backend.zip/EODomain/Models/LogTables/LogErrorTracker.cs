﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class LogErrorLogs
    {
        public int? EmployeeId { get; set; }
        public string? ApplicationName { get; set; }
        public string? HostName { get; set; }
        public string? LayerName { get; set; }
        public string? ScreenName { get; set; }
        public string? ModuleName { get; set; }
        public string? API { get; set; }
        public string? StoredProcedure { get; set; }
        public string? Functionality { get; set; }
        public string? ErrorNumber { get; set; }
        public string? ErrorState { get; set; }
        public string? ErrorSeverity { get; set; }
        public string? StackTraceId { get; set; }
        public string? StackTrace { get; set; }
        public string? ErrorMessage { get; set; }
        public string? ErrorType { get; set; }
        public string? SessionId { get; set; }
        public string? RequestBody { get; set; }
        public int? StatusCode { get; set; }
        public string? WebServer { get; set; }
        public string? Status { get; set; }
        public string? AssignedTo { get; set; }
        public string? CreatedOn { get; set; }
        public int? CreatedBy { get; set; }
        public string? UpdatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public string? Duration { get; set; }
    }
}
