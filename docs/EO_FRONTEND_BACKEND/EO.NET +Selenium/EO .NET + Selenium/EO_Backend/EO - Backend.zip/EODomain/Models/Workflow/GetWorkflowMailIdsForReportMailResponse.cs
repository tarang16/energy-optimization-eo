﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowMailIdsForReportMailResponse
    {
        public int? id { get; set; }
        public string? projectCode { get; set; }
        public int? plantID { get; set; }
        public int? affiliate_id { get; set; }
        public string? emailTo { get; set; }
        public string? emailFrom { get; set; }
        public DateTime? lastTriggeredTime { get; set; }
        public int? minuteFrequency { get; set; }
    }
}
