﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class GetDemandInputsStoredProcedureResponse : GetDemandInternalData
    {
        
        public string? energyCategory { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class GetDemandInternalData
    {
        public int caseId { get; set; }
        public string? plantName { get; set; }
        public string? type { get; set; }
        public string? tagName { get; set; }
        public decimal? actual { get; set; }
        public int? modelTagId { get; set; }
        public decimal? adjustedValue {  get; set; }
        public decimal? referenceBias { get; set; } 
    }
}
