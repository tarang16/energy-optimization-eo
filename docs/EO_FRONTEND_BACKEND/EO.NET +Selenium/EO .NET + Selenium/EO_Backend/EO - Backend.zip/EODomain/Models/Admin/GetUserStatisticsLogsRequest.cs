﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsLogsRequest
    {

        [AllowNull]
        public DateTime? sTime { get; set; }

        [AllowNull]
        public DateTime? eTime { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [AllowNull]
        public string? screenIDs { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [AllowNull]
        public string? affiliateIDs { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [AllowNull]

        public byte ascOrder { get; set; } = 0; 
        public int pageNumber { get; set; } = 1;
        public int pageSize { get; set; } = 20;
    }
}
