﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagsDataCommon : GetTagsDataFlags
    {
        public int? tagID { get; set; }
        public string? name { get; set; }
        public string? nameShort { get; set; }
        public string? description { get; set; }
        public string? piName { get; set; }
        public float? hihi { get; set; }
        public float? lolo { get; set; }
        public float? high { get; set; }
        public float? low { get; set; }
        public string? uom { get; set; }
        public string? category { get; set; }
        public string? equipment { get; set; }
        public string? subEquipment { get; set; }
        public string? pipelineLocation { get; set; }
        public string? formulaState { get; set; }
    }
}
