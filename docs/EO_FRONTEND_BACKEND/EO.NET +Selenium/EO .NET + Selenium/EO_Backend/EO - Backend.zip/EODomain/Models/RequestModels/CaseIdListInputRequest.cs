﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.RequestModels
{
    [ExcludeFromCodeCoverage]
    public class CaseIdListInputRequest
    {
        [AllowNull]
        public string? caseIDList { get; set; }
    }
}
