﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetAffectedPiAfConstantsRequest
    {
        [Required]
        [Range(0, 100000000)]
        public int mstAfConstantId { get; set; }
        public int modelId { get; set; }
    }
}
