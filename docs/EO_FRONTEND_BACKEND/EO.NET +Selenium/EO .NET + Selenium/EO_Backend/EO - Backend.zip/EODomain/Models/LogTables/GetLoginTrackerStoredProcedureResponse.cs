﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetLoginTrackerStoredProcedureResponse
    {
        public int? EmployeeID { get; set; }
        public string? Role { get; set; }
        public string? IpAddress { get; set; }
        public string? BrowserName { get; set; }
        public string? ApplicationName { get; set; }
        public DateTime? LoginTime { get; set; }
        public long? LoginTimeEpoch { get; set; } = null;
        public DateTime? LogoutTime { get; set; }   
        public long? LogoutTimeEpoch { get; set; } = null;   
        public string? SessionId { get; set; }
        public string? IsOnline { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? CreatedOnEpoch { get; set; } = null;
        public int? UpdatedBy { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public long? UpdatedOnEpoch { get; set; } = null;
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
    }
}
