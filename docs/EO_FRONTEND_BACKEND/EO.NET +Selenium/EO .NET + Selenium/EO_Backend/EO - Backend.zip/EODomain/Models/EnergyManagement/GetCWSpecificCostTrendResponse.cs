﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetCWSpecificCostTrendResponse
    {
        public int dateFormat { get; set; }
        public decimal? cwHeatRejection { get; set; }
        public decimal? coolingWaterLoad { get; set; }
    }
}
