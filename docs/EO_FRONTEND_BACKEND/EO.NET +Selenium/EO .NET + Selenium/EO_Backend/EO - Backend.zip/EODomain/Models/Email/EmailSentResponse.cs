﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class EmailSentResponse
    {
        public SendEmailNotificationOutput? SendEmailNotificationOutput { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class SendEmailNotificationOutput
    {
        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? Status { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? StatusMessage { get; set; }
    }
}
