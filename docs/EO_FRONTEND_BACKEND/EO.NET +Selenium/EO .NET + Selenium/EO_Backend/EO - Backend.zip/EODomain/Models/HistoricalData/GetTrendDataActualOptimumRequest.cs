﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.HistoricalData
{
    [ExcludeFromCodeCoverage]
    public class GetTrendDataActualOptimumRequest
    {
        public int caseID { get; set; }

        [DynamicMaxLength]
        public string? tagNameList { get; set; }

        public DateTime sTime { get; set; }

        public DateTime eTime { get; set; }

        public int roundFactor { get; set; } = 2;
    }
}
