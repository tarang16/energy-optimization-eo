﻿using EOUtility;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Download
{
    [ExcludeFromCodeCoverage]
    public class DownloadDataRequest
    {
      
            public string? tagNames { get; set; }
            public string? plantID_list { get; set; }
            public DateTime sTime { get; set; }
            public DateTime eTime { get; set; }
            [SwaggerIgnore]
            public int chunkSize { get; set; }
        
    }
}
