﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public  class GetPlantAffiliatesResponse
    {
        public string? region  {get;set;}
        public string? plantName    {get;set;}
        public string? affiliate { get; set; }
    }
}
