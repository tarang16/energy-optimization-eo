﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class GetPIDataInfraMonitoringLagTrendRequest
    {
        public string? caseIDList { get; set; }
        public DateTime? stime { get; set; }
        public DateTime? etime { get; set; }
    }
}
