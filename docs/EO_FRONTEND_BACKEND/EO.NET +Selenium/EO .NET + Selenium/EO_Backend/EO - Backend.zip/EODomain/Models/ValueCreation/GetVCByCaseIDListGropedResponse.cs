﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetVCByCaseIDListGropedResponse
    {
        public int? caseID { get; set; }
        public string? caseName { get; set; }
        public double? realizedvalueEnergy { get; set; }
        public double? realizedvalueProduction { get; set; }
        public double? lostvalueEnergy { get; set; }
        public double? lostvalueProduction { get; set; }
    }
}
