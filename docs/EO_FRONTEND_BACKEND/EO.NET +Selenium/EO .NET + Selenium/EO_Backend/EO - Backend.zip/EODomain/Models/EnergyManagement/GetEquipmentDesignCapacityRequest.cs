﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetEquipmentDesignCapacityRequest
    {
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }

        [AllowNull]
        public int? affiliateID { get; set; }

        [AllowNull]
        public string? plantNameList { get; set; }

        [AllowNull]
        public string? category { get; set; }

        [AllowNull]
        public string? equipment { get; set; }
    }
}
