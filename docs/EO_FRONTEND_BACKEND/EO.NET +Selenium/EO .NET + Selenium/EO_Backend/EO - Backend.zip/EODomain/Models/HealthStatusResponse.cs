﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class HealthStatusResponse
    {
        public int? caseID { get; set; } = null;
        public int? state { get; set; }
        public string? message { get; set; }
        public string? details { get; set; } = null;
    }
}
