﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public  class GetOverallSignificanceEnergyResponse
    {
        public DateTime? kpiDate { get; set; }
        public string? affiliate { get; set; }
        public string? plantName { get; set; }
        public string? equipmentCategory { get; set; }
        public string? equipment { get; set; }
        public string? energySource { get; set; }
        public string? equipmentDescription { get; set; }
        public decimal? energyConsumed { get; set; }
        public decimal? enpiDollars { get; set; }
        public decimal? enpiGj { get; set; }
        public int? equipmentOperationDays { get; set; }
        public decimal? totalEnergy { get; set; }
        public decimal? efficiency { get; set; }
        public string? opportunity { get; set; }
    }
}
