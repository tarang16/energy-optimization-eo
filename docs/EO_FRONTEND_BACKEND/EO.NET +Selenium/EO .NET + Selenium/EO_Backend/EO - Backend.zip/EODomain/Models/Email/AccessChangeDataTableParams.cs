﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class AccessChangeDataTableParams
    {
        public string? FeatureAccess { get; set; }
        public string? ActionType { get; set; }
        public string? AffiliatePlant { get; set; }
        public string? User { get; set; }
        public string? ModifiedBy { get; set; }
        public string? TimeStamp { get; set; }

    }
}
