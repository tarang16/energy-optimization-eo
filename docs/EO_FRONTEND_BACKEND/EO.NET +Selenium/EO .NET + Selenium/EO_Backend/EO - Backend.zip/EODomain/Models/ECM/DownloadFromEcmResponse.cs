﻿
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class DownloadFromEcmResponse
    {
        public string? FileName { get; set; }
        public byte[]? FileStream { get; set; }
        public string? Message { get; set; }

    }
}
