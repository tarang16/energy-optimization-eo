﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetPlantEnergyEciAirWaterSteamResponse
    {
        public string? groupByCol { get; set; }
        public decimal? airSystemPerformance { get; set; }
        public decimal? coolingWaterPerformance { get; set; }
        public decimal? steamSystemLosses { get; set; }
        public decimal? totalPurchasedEnergyConsumption { get; set; }
        public decimal? energyCostIndex { get; set; }
        public decimal? specificEnergy { get; set; }
        public string? energyTarget { get; set; }
        public string? airTarget { get; set; }
        public string? steamTarget { get; set; }
    }
}
