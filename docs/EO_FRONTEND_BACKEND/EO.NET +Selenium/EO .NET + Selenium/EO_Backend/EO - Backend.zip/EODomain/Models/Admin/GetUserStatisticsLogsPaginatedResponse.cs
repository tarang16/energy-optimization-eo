﻿using EODomain.Models.Admin;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsLogsPaginatedResponse
    {
        public List<GetUserStatisticsLogsStoredProcedureResponse>? data {  get; set; }
        public int pageCount { get; set; }
    }
}
