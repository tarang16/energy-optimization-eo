﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Network
{
    [ExcludeFromCodeCoverage]
    public class PostTrnNetworkPagesRequest
    {
        public int caseID { get; set; }
        public int pageId { get; set; }
        public string? nodeJson { get; set; }
        public string? edgeJson { get; set; }
        public int createdBy { get; set; } = 1;
        public int modifiedBy { get; set; } = 1;
        public DateTime ModifiedOn { get; set; }
    }
}
