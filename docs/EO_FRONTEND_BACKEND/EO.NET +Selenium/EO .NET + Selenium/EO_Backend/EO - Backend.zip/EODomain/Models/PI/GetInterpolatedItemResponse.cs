﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class GetInterpolatedItemResponse
    {
        public DateTime Timestamp { get; set; }
        public object? Value { get; set; }
        public string? UnitsAbbreviation { get; set; }
        public bool Good { get; set; }
        public bool Questionable { get; set; }
        public bool Substituted { get; set; }
        public bool Annotated { get; set; }
    }
}
