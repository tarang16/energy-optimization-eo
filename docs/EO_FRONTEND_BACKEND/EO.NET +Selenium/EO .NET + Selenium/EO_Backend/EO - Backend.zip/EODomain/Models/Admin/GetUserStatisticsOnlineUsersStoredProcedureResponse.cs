﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsOnlineUsersStoredProcedureResponse
    {
        public int? employeeId { get; set; }
        public string? employeeName { get; set; }
        public string? roleName { get; set; }
        public string? ScreenName { get; set; }
        public DateTime? LastAccessedTime { get; set; }
        public long? lastAccessedTimeEpoch { get; set; }
    }
}
