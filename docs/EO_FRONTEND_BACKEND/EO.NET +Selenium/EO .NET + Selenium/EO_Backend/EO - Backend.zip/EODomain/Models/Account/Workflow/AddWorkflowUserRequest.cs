﻿using EOUtility;
using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class AddWorkflowUserRequest
    {
        [Required]
        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        public string? userIDList { get; set; }

        [Required]
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? role { get; set; }

        [Required]
        [Range(0, 100000)]
        public int? affiliateId { get; set; }

       
        [Range(0,1000000000)]
        [SwaggerIgnore]
        public string? createdBy { get; set; }


        public string? managerID { get; set; }
    }
}
