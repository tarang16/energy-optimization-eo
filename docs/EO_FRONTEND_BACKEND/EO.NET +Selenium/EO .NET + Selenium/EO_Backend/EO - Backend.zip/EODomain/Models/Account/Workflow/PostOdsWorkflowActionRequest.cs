﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class PostOdsWorkflowActionRequest
    {

        public string? requestIdList { get; set; }   
        
        [Range(0, 1000000000)]
        [AllowNull]
        public int requestId { get; set; }

        [Range(0, 20)]
        public int stageId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? assigneeId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? createdBy { get; set; }

        [Range(0, 20)]
        public int actionId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? comments { get; set; }

        public byte? considerSuggestion { get; set; }

        [AllowNull]
        public DateTime? targetDate { get; set; }

        [AllowNull]
        public List<Suggestions>? suggestions { get; set; }

        [AllowNull]
        public List<Files>? files { get; set; }
    }


    [ExcludeFromCodeCoverage]
    public class PostOdsWorkflowActionNameRequest
    {

        public string? requestIdList { get; set; }

        [Range(0, 1000000000)]
        [AllowNull]
        public int requestId { get; set; }

        [Range(0, 20)]
        public int stageId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? assigneeId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? createdBy { get; set; }

        
        public string? actionName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? comments { get; set; }

        public byte? considerSuggestion { get; set; }

        [AllowNull]
        public DateTime? targetDate { get; set; }

        [AllowNull]
        public List<Suggestions>? suggestions { get; set; }

        [AllowNull]
        public List<Files>? files { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Suggestions
    {
        [Range(-100000, 10000000)]
        public double? actual { get; set; }

        [Range(-100000, 10000000)]
        public double? optimum { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? suggestion { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Files
    {
        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? fileName { get; set; }
                       
        [AllowNull]    
        public byte[]? fileData { get; set; } = null;
                       
        [AllowNull]    
        public string? fileUrl { get; set; }
    }
}
