﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetOdsActionSuggestionsStoredProcedureResponse
    {
		public string? suggestion { get; set; }
        public double? actual { get; set; }
		public double? optimum { get; set; }
        public string? suggestedBy { get; set; }
    }
}
