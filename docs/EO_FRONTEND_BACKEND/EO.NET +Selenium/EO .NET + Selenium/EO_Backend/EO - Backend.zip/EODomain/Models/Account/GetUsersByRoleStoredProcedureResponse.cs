﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetUsersByRoleStoredProcedureResponse
    {
        public string? employeeName { get; set; }
        public int employeeId { get; set; }
        public string? firstName { get; set; }
        public string? lastName { get; set; }
        public string? email { get; set; }
        public string? affiliateName { get; set; }
    }
}
