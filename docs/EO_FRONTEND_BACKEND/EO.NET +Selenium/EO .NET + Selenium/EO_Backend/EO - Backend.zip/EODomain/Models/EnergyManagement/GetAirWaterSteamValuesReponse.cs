﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetAirWaterSteamValuesResponse
    {
        public decimal? airSystemPerformance { get; set; }
        public decimal? coolingWaterPerformance { get; set; }
        public decimal? steamSystemLosses { get; set; }
        public decimal? totalPurchasedEnergyConumption { get; set; }
        public decimal? energyCostIndex { get; set; }
        public decimal? seuEnpiNet { get; set; }
    }
}
