﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class DeleteWorkflowUserStoredProcedureResponse
    {
        public int roleId { get; set; }
        public int isActive { get; set; }
    }
}
