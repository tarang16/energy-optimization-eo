﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class AdmUserTokenInsert
    {
        public System.Guid? TokenGuid { get; set; }
        public System.Guid? SessionGuid { get; set; }
        public byte IsActive { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }

    }
}
