﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.WinAuth
{
    [ExcludeFromCodeCoverage]
    public class Token
    {
        public string? value { get; set; }
    }
}
