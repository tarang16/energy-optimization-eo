﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetLandingCorporateSPResponse
    {
        public int? caseId { get; set; }
        public string? regionName { get; set; }
        public string? regionNameShort { get; set; }
        public string? affiliateName { get; set; }
        public int? affiliateCode { get; set; }
        public int? affiliateID { get; set; }
        public string? urlAffiliateImage { get; set; }
        public int active { get; set; }
        public decimal? opportunityEnergyBills { get; set; }
        public decimal? opportunityFuel { get; set; }
        public decimal? opportunityCo2 { get; set; }
        public DateTime? timeStamp { get; set; }
        public long? timeStampEpoch { get; set; }
        public decimal? seecGain { get; set; }
    }
}
