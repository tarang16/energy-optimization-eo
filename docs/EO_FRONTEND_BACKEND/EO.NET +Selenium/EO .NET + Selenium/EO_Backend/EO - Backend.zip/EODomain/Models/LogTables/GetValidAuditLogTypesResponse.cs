﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetValidAuditLogTypesResponse
    {
        public int id { get; set; }
        public string? name { get; set; }
        public string? description { get; set; }
        public string? category { get; set; }

    }
}
