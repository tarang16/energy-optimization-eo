﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetOdsWorkflowActionLogsServiceLayerResponse
    {
        public int actionLogId { get; set; }
        public string? employeeId { get; set; }
        public string? employeeName { get; set; }
        public string? email { get; set; }
        public string? roleName { get; set; }
        public string? action { get; set; }
        public int actionId { get; set; }
        public string? comments { get; set; }
        public List<Attachments>? attachments { get; set; }
        public DateTime? createdOn { get; set; }
        public long? createdOnEpoch { get; set; }
        public string? errorMsg { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Attachments
    {
        public string? attachmentName { get; set; }
        public string? attachmentUrl { get; set; }
    }
}
