﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetValidationDataForAddRoleToUsersStoredProcedureResponse
    {
        public string? validRole { get; set; }
        public int createdByCount { get; set; }
        public int usersCount { get; set; }
        public List<GetUsersByRoleStoredProcedureResponse>? users { get; set; }

    }
}
