﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class CorporateResponseAffiliate
    {
        public int? affiliateCode { get; set; }
        public int? affiliateID { get; set; }
        public string? affiliateName { get; set; }
        public int? caseID { get; set; }
        public decimal? seecGain { get; set; }
        public decimal? opportunityCo2 { get; set; }
        public decimal? opportunityEnergyBills { get; set; }
        public string? urlAffiliateImage { get; set; }
        public DateTime? timeStamp { get; set; }
        public long? timeStampEpoch { get; set; }
    }
}
