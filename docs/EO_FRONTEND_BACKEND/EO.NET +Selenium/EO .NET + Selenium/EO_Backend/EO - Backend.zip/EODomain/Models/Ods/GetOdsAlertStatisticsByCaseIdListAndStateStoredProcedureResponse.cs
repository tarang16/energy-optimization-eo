﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAlertStatisticsByCaseIdListAndStateStoredProcedureResponse
    {
        public int alertId {  get; set; }
        public string? system { get; set; }
        public string? name { get; set; }
        public string? role { get; set; }
        public string? status { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
    }
}
