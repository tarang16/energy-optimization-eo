﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{

    [ExcludeFromCodeCoverage]
    public class GetAllPiTagsByCategoryResponse
    {
        public List<Item>? Items { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Item
    {
        public string? Name { get; set; }
        public string? DataReferencePlugIn { get; set; }
        public string? ConfigString { get; set; }
        public string? Path { get; set; }
        public Links? Links { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Links
    {
        public string? Point { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class GetAllPiTagsByCategoryDynamicBatchResponse
    {
        public Content? Content { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Content
    {
        public List<Item>? Items { get; set; }
    }
}
