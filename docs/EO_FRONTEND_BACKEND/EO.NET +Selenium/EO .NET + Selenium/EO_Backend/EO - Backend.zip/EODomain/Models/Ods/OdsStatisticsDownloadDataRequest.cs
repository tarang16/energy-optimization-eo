﻿using EOUtility;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class OdsStatisticsDownloadDataRequest
    {
        public string? caseIdList { get; set; }

        public DateTime? fromDate { get; set; }
        [SwaggerIgnore]
        public int chunkSize { get; set; }
    }
}
