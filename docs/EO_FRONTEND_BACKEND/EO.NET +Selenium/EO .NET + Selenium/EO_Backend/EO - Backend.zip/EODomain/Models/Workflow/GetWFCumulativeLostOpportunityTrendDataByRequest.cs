﻿
using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWFCumulativeLostOpportunityTrendDataByRequest
    {
        public int? requestID { get; set; }
    }
}
