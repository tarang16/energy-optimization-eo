﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetQueryTrackerLogsStoredProcedureResponse
    {
        public string? storedProcedure { get; set; }
        public int? totalRecords { get; set; }
        public string? totalTime { get; set; }
        public double? size { get; set; }
        public DateTime? createdDate { get; set; }
        public long? createdDateEpoch { get; set; } = null;
        public string? webServer { get; set; }
        public string? actionUrl { get; set; }
        public string? errorMessage { get; set; }
        public string? parallelSql { get; set; }
    }
}
