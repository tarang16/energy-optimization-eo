﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetEnpiDailyTrendResponse
    {
        public DateTime? kpiDate {  get; set; }
        public decimal? positiveSumValues { get; set; }
        public decimal? negativeSumValues { get; set; }
        public decimal? differenceValues { get; set; }
    }
}
