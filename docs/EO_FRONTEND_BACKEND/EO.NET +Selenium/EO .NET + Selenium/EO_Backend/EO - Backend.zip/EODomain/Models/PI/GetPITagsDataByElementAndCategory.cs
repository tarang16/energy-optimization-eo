﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class GetPITagsDataByElementAndCategory
    {
        public List<ItemWithConfigString>? Items { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class ItemWithConfigString
    {
        public string? WebId { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? DataReferencePlugIn { get; set; }
        public string? ConfigString { get; set; }
    }
}
