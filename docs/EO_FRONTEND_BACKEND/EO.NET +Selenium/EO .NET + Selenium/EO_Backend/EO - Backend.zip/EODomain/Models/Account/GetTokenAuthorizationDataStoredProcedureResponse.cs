﻿using EODomain.Models.LogTables;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetTokenAuthorizationDataStoredProcedureResponse
    {
        public GetTokenRelatedData? tokenInfo { get; set; }
        public GetRolesRoleIdByUserIdStoredProcResponse? userRole { get; set; }
        public List<ClaimDto>? allClaims { get; set; }

    }

    [ExcludeFromCodeCoverage]
    public class GetTokenRelatedData : GetLatestTokenDataBySessionStoredProcedureResponse
    {
        public Guid? loginGuid { get; set; }
        public DateTime? startTime { get; set; }
        public DateTime? endTime { get; set;}
        public int? isOnline { get; set;}
    }
}
