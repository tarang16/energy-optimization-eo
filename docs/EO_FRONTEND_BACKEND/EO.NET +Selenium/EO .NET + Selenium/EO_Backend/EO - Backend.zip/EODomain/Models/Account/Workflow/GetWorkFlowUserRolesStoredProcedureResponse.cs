﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkFlowUserRolesStoredProcedureResponse
    {
        public int roleId { get; set; }
        public string? role { get; set; }
        public int stageId { get; set; }
    }
}
