﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetAuditLogRequest
    {
        [Range(0, 100)]
        public int? activityTypeId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? target { get; set; }


        [Range(0, int.MaxValue)]
        public string? targetValue { get; set; }
    }
}
