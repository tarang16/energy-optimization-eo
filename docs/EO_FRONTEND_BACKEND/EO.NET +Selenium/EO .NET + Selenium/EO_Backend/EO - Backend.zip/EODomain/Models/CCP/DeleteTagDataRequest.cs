﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class DeleteTagDataRequest
    {
        [AllowNull]
        public int? tagID { get; set; } = null;
    }
}
