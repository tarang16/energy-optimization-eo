﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetErrorTrackingStoredProcedureResponse
    {
        public int? ErrorID { get; set; }
        public string? EmployeeID { get; set; }
        public string? Role { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? CreatedOnEpoch { get; set; } = null;
        public string? ApplicationName { get; set; }
        public string? HostName { get; set; }
        public string? LayerName { get; set; }
        public string? API { get; set; }
        public string? StoredProcedure { get; set; }
        public string? StackTraceID { get; set; }
        public string? StackTrace { get; set; }
        public string? ErrorMessage { get; set; }
        public string? SessionID { get; set; }
        public string? RequestBody { get; set; }
        public string? ResponseBody { get; set; }
        public string? StatusCode { get; set; }
        public string? ScreenName { get; set; }
        public string? ModuleName { get; set; }
        public string? Functionality { get; set; }
        public string? ErrorNumber { get; set; }
        public string? ErrorState { get; set; }
        public string? ErrorSeverity { get; set; }
        public DateTime? UpdatedOn { get; set; }
        public long? UpdatedOnEpoch { get; set; } = null;
        public string? Status { get; set; }
        public string? AssignedTo { get; set; }
        public string? EmailID { get; set; }
        public string? UserName { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
    }
}
