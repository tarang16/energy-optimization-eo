﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowAssignedAlertListByUserIdStoredProcedureResponse
    {
        public int requestId { get; set; }
        public DateTime? deviationTime { get; set; }
        public DateTime? lastOccurrence { get; set; }
        public int caseId { get; set; }
        public string? Plant { get; set; }
        public string? affiliate { get; set; }
        public string? modifiedBy { get; set; }
        public DateTime? modifiedOn { get; set; }
        public string? deviationStatus { get; set; }
        public string? system { get; set; }
        public string? kpi { get; set; }
        public string? cause { get; set; }
        public string? category { get; set; }
        public long? dueDateEpoch { get; set; }
        public long? deviationTimeEpoch { get; set; }
        public long? lastOccurrenceEpoch { get; set; }
        public string? assignedTo { get; set; }
        public string? suggestion { get; set; }
        public int? bpmInitiated { get; set; }
        public long? bpmSubmissionTimeEpoch { get; set; }
        public int? stageId { get; set; }
        public int? cumulativeLostOpportunity { get; set; }
        public int? processOperationRejection { get; set; }
        public string? roleName { get; set; }
        public string? reviewStatus { get; set; }

    }
}
