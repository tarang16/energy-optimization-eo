﻿

using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class GetEcmAuthTokenResponse
    {
        public string? ticket { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class EcmFileInfo
    {
        public string? Id { get; set; }
        public string? file_name { get; set; }
        public string? file_type { get; set; }
        public string? file_size { get; set; }
    }
}
