﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class RequestIpBrowserVersion
    {
        public string? IpAddress { get; set; }
        public string? BrowserName { get; set; }
        public string? BrowserVersion { get; set; }
    }
}
