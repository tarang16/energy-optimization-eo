﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class AddTagRequest
    {
        public int caseID {  get; set; }
        public string? tagName { get; set; }
        public string? tagType { get; set; }
        public string? inferredExpression { get; set; }
        public string? piName {get;set;}    
        public string? dataType { get; set; }
        public string? uiDisplayName { get; set; }
        public string? description {  get; set; }
        public int? modelID { get; set; }
        public int? uomID { get; set; }
    }
}
