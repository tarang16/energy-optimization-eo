﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.HistoricalData
{
    [ExcludeFromCodeCoverage]
    public class GetDataTimeStartEndStoredProcResponse
    {
        public string? name { get; set; }
        public double? actualValue { get; set; }
        public double? optimumValue { get; set; }
        public DateTime time { get; set; }
        public long? timeEpoch { get; set; }
        public int? tagID { get; set; }
        public int? runDay { get; set; }
    }
}
