﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagDataByCaseIDRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }
    }
}
