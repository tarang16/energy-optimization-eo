﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.AIHub
{
    [ExcludeFromCodeCoverage]
    public class GetStateOfAllJobsQueryResponse
    {
        public List<Content>? content { get; set; }
        public bool first { get; set; }
        public bool last { get; set; }
        public int totalPages { get; set; }
        public int totalElements { get; set; }
        public long size { get; set; }
        public int number { get; set; }
        public int numberOfElements { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Content
    {
        public long createdAt { get; set; }
        public Jobagent? jobAgent { get; set; }
        public string? jobContainerName { get; set; }
        public string? location { get; set; }
        public bool stopRequested { get; set; }
        public string? id { get; set; }
        public string? ownerId { get; set; }
        public long endedAt { get; set; }
        public long startedAt { get; set; }
        public long duration { get; set; }
        public string? queueName { get; set; }
        public long maxMemory { get; set; }
        public long usedMemory { get; set; }
        public Progress? progress { get; set; }
        public string? state { get; set; }
        public Error? error { get; set; }
        public int maxTTL { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Progress
    {
        public long duration { get; set; }
        public long avgDuration { get; set; }
        public List<Stacktrace>? stacktrace { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Stacktrace
    {
        public string? name { get; set; }
        public int iteration { get; set; }
        public long duration { get; set; }
        public int progress { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Error
    {
        public string? type { get; set; }
        public string? title { get; set; }
        public string? message { get; set; }
        public string? explanation { get; set; }
        public string? trace { get; set; }
    }

}
