﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PITags
{
    [ExcludeFromCodeCoverage]
    public class GetPITagItemsByElement
    {
        public Content? Content { get; set; }
    }


    [ExcludeFromCodeCoverage]
    public class Content
    {
        public List<Item>? Items { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Item
    {
        public string? WebId { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public string? DataReferencePlugIn { get; set; }
        public string? ConfigString { get; set; }
    }
}
