﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetDownloadTagListRequest
    {
        public string? plantIDList { get; set; }
    }
}
