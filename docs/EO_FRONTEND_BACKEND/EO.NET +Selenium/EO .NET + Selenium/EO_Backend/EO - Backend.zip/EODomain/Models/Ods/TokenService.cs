﻿using EODomain.Models.WinAuth;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Security;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class TokenService
    {
        private readonly IWebHostEnvironment _env;
        private readonly IConfiguration _configuration;
        public TokenService(IWebHostEnvironment env, IConfiguration configuration)
        {
            _env = env;
            _configuration = configuration;
        }


        public async Task<dynamic> GetAuthenticationTokenAsync(string _baseUrl)
        {

            try

            {

                using (var handler = new HttpClientHandler())

                {
                    System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12;
                    handler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) =>
                    {
                        // Default validation result
                        bool isValid = sslPolicyErrors == SslPolicyErrors.None;

                        if (!isValid)
                        {                            
                            return false; 
                        }

                        return true; 
                    };
                    var clientCertificate = new X509Certificate2(Path.Combine(_env.ContentRootPath, "Utility", "1985449.cer"));
                    handler.ClientCertificates.Add(clientCertificate);

                    handler.Credentials = new NetworkCredential(_configuration.GetSection("NetworkCredentials").GetSection("userName").Value!.ToString(),
                                            _configuration.GetSection("NetworkCredentials").GetSection("password").Value!.ToString(), "");

                    using (var httpClient = new HttpClient(handler))

                    {

                        var request = new GetTokenRequest

                        {

                            forcedLogin = 1

                        };

                        var jsonContent = JsonConvert.SerializeObject(request);

                        var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                        string pointURL = _configuration.GetSection("PELocalhostDetails").GetSection("PointURL").Value!;
                        var response = await httpClient.PostAsync(pointURL, content);

                        var responseContent = await response.Content.ReadAsStringAsync();

                        var apiResponse = JsonConvert.DeserializeObject<dynamic>(responseContent);

                        return apiResponse!;


                    }

                }

            }

            catch (Exception ex)

            {
                return ex.Message;


            }



        }


    }

}
