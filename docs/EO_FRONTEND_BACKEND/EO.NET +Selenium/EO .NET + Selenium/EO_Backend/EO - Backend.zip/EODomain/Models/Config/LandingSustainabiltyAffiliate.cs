﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class LandingSustainabiltyAffiliate
    {
        public int affiliateID { get; set; }
        public int affiliateCode { get; set; }
        public int caseID { get; set; }
        public string? affiliateName { get; set; }
        public decimal? co2Opp { get; set; }
        public decimal? seecGain { get; set; }
        public decimal? energyOpp { get; set; }
        public int? isActive { get; set; }
    }
}
