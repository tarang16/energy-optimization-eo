﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetCaseIDRepositoryResponse
    {
        public List<GetCaseIDResponse>? GetCaseIDResponse { get; set; }
        public int pageCount { get; set; }

    }
}
