﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class AdmUserSessionInsert
    {
        public System.Guid? SessionGUID { get; set; }
        public System.Guid? LoginGUID { get; set; }
        public byte IsOnline { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }

    }
}
