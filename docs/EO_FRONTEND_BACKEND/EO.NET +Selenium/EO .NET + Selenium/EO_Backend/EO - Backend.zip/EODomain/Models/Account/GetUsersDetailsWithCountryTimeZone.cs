﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetUsersDetailsWithCountryTimeZone : GetUsersByRoleStoredProcedureResponse
    {
        public string? country { get; set; }
        public string? timeZone { get; set; }

    }
}
