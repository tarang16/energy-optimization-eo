﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsKpiTagByCaseIDStoredProcedureResponse
    {
        public int? caseId { get; set; }
        public string? businessKpiTagName { get; set; }
        public string? effectTagName { get; set; }
    }
}
