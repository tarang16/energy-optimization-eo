﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class PostAddRoleToUsersRequest
    {
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? role { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? userIDList { get; set; }

        [Range(0,1000000000)]
        public int createdByUserID { get; set; }
    }
}
