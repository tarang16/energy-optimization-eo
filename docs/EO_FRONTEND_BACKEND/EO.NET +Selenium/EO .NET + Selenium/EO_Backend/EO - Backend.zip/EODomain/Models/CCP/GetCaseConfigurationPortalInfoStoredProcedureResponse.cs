﻿
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetCaseConfigurationPortalInfoStoredProcedureResponse
    {
        public List<CcpInfo>? tag_out_of_bound_switch { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class CcpInfo
    {
        public int? ccp_info_id { get; set; }
        public string? description { get; set; }
    }
}
