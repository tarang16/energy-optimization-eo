﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowHistoricalDataForAllUsersServiceLayerResponse
    {
        public int alertId { get; set; }
        public long deviationEpoch { get; set; }
        public long lastOccurrenceEpoch { get; set; }
        public List<HistoryData>? history { get; set; } 
    }

    [ExcludeFromCodeCoverage]
    public class HistoryData
    {
        public long timeEpoch { get; set; }
        public string? employeeName { get; set; }
        public string? comments { get; set; }
        public string? considerSuggestion { get; set; } 
        public List<WorkflowUserSuggestions>? suggestions { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WorkflowUserSuggestions
    {
        public string? suggestion { get; set; }
        public double? actual { get; set; }
        public double? optimum { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
    }


}
