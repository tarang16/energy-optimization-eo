﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetCaseIDResponse
    {
        public int? caseID { get; set; }
        public int? tagID { get; set; }
        public string? tagName { get; set; } = string.Empty;
        public string? uom { get; set; }
        public string? tagDescription { get; set; }
        public double? max { get; set; }
        public double? min { get; set; }
        public int? tagOutOfBoundSwitch { get; set; }
        public int? tagStuckSwitch { get; set; }
        public int? defaultSwitch { get; set; }
        public bool? tagBoundAtLimitsSwitch { get; set; }
        public bool? piAfTag { get; set; }
        public string? defaultValue { get; set; }
        public double? refMax { get; set; }
        public double? refMin { get; set; }
        public int? modelID { get; set; }
        public string? modelName { get; set; }
        public string? modelType { get; set; }
        public string? modelDescription { get; set; }
        public string? tagFullName { get; set; }
        public string? piTagName { get; set; }
        public string? equipmentName { get; set; }
        public string? type { get; set; }
        public int? tagNanSwitch { get; set; }
               

    }
}
