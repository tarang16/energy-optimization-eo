﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;


namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class DownloadFromEcmRequest
    {
        [Required(ErrorMessage = "The fileId field is required.")]
        [MinLength(4, ErrorMessage = "The fileId must be at least 4 characters long.")]
        [MaxLength(16, ErrorMessage = "The fileId cannot be longer than 16 characters.")]
        public string? fileId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [AllowNull]
        public string? server { get; set; }

    }
}
