﻿using EOUtility;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdatePiAfConstantsDataRequest
    {
        public int? tagId { get; set; } = null;
        public decimal value { get; set; }
        public string? element { get; set; } = null;
        public string? attribute { get; set; } = null;
        [SwaggerIgnore]
        public string? category { get; set; } = null;
        [SwaggerIgnore]
        public int? updatedBy { get; set; }
    }
}
