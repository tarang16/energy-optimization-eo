﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetEnergyCostIndexEnergyGapMonthlyIndexResponse
    {
        public string? monthly { get; set; }
        public string? affiliate { get; set; }
        public string? plantName { get; set; }
        public decimal? energyGap { get; set; }
        public decimal? actualEnergy { get; set; }
        public decimal? bestQuartileEnergy { get; set; }
        public decimal? electricityCostIndex { get; set; }
        public decimal? fuelCostIndex { get; set; }
        public decimal? steamCostIndex { get; set; }
        public decimal? energyIntensity { get; set; }
    }
}
