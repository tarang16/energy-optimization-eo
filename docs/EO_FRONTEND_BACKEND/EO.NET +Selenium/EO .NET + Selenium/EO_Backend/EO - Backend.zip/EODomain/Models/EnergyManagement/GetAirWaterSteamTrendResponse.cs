﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetAirWaterSteamTrendResponse
    {
        public int? year { get; set; }
        public int? month { get; set; }
        public decimal? airSpecificEnpi { get; set; }
        public decimal? airSpecificEnpiTarget { get; set; }
        public decimal? airEnpi { get; set; }
        public decimal? airEnpiTarget { get; set; }
        public decimal? coolingWaterLoad { get; set; }
        public decimal? coolingWaterCost { get; set; }
        public decimal? coolingWaterCostTarget { get; set; }
        public decimal? closedCoolingWaterFlowRate { get; set; }
        public decimal? seaWaterFlowRate { get; set; }
        public decimal? cwChemicalCost { get; set; }
        public decimal? cwEnergyCost { get; set; }
        public decimal? cwWaterChemCost { get; set; }
        public decimal? steamLetDownLosses { get; set; }
        public decimal? steamVentsLosses { get; set; }
        public decimal? steamDumpedLosses { get; set; }
        public decimal? steamLossTarget { get; set; }
    }
}
