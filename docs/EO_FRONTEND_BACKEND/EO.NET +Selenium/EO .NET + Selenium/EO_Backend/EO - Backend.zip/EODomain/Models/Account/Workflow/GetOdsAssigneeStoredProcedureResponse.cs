﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAssigneeStoredProcedureResponse
    {
        public string? assigneeId { get; set; }
        public string? powerUserId { get; set; }
        public int stageId { get; set; }
        public string? employeeName { get; set; }
        public string? email { get; set; }
        public string? roleName { get; set; }
        public string? status { get; set; }
        public string? systemAdmin { get; set; }
    }
}
