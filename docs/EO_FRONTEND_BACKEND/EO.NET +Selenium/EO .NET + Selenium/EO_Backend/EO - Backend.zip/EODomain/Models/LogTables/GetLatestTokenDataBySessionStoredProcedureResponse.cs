﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetLatestTokenDataBySessionStoredProcedureResponse
    {
        public int? userId { get; set; }
        public Guid? tokenGuid { get; set; }
        public Guid? sessionGuid { get; set; }
        public DateTime? tokenStartTime { get; set; }
        public DateTime? tokenEndTime { get; set; }
        public DateTime? loginTime { get; set; }
        public DateTime? logoutTime { get; set; }
        public string? ipAddress { get; set; }
        public string? browserName { get; set; }
        public string? browserVersion { get; set; }
        public byte isActive { get; set; }
    }
}
