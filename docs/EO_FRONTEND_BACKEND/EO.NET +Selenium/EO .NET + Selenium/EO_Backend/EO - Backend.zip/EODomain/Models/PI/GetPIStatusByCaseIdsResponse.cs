﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class GetPIStatusByCaseIdsResponse
    {
        public int caseId { get; set; }
        public int modelId { get; set; }
        public string? category { get; set; }
        public string? parameter { get; set; }
        public string? value { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class GetAllAvailablePITimeTagResponse
    {
        public int caseID { get; set; }
        public string? tagName { get; set; }
        public string? affiliateName { get; set; }
        public string? plantName { get; set; }
        public string? systemName { get; set; }
    }
}
