﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class GetTreeDiagramByCaseIDRequest
    {
        [Range(0, 1000000000)]
        public int caseId { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime timeStamp { get; set; }

        [DynamicMaxLength]
        public string? category { get; set; }
    }
}
