﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class InsertCaseDetailsRequest
    {
        public byte active { get; set; }

        public int plantID { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? caseName { get; set; }
        
        public int processFrequency { get; set; }
        
        public int slot { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? description { get; set; }
    }
}
