﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;


namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserAnalyticsScreenWiseRequest
    {
        public int employeeId { get; set; }

        [AllowNull]
        public DateTime? sTime { get; set; }
        
        [AllowNull]
        public DateTime? eTime { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [AllowNull]
        public string? screenIDs { get; set; }
    }
}
