﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class EmailSettingsEntity
    {
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public string? Link { get; set; }
        public string? BaseURL { get; set; }
        public string? ProjectCode { get; set; }
    }
}
