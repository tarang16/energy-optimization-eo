﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public  class GetAirTrendResponse
    {
        public int? dateFormat { get; set; }
        public decimal? airSpecificEnpi { get; set; }
        public decimal? airSpecificEnpiTarget { get; set; }
        public decimal? airEnpi { get; set; }
        public decimal? airEnpiTarget { get; set; }
    }
}
