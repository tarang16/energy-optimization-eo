﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class OdsCaseIdDateTimeRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime time { get; set; }
    }
}
