﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserAnalyticsLogsStoredProcedureResponse
    {
        public string? AffiliatePlantSystem { get; set; }
        public string? Affiliate { get; set; }
        public string? Plant { get; set; }
        public string? System { get; set; }
        public string? ScreenName { get; set; } 
        public string? FunctionalityName { get; set; }
        public string? UserActionName { get; set; }
        public string? CreatedOn { get; set; }
        public long? CreatedOnEpoch { get; set; }
        public decimal? ScreenDurationInSec { get; set; }
    }
}
