﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.InfraJobServices
{
    [ExcludeFromCodeCoverage]
    public class PiConnectionResponse
    {
        public string? piStatus { get; set; }
        public string? piResponse { get; set; }
        public int? piConnResponseCode { get; set; }
    }
}
