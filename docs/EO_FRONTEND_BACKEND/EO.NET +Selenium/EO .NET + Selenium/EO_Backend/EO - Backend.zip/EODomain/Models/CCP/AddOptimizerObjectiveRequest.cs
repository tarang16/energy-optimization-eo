﻿using EODomain.Common;
using EOUtility;
using Microsoft.AspNetCore.Http.HttpResults;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class AddOptimizerObjectiveRequest
    {

        [Range(0, 100000000)]
        public int? objectiveId { get; set; }

        public int modelTagId { get; set; }
        
        public int direction { get; set; }

        [SwaggerIgnore]
        public int? createdBy { get; set; }
        [SwaggerIgnore]
        public int? modifiedBy { get; set; }
        public string? formulaExpression { get; set; }
    }
}
