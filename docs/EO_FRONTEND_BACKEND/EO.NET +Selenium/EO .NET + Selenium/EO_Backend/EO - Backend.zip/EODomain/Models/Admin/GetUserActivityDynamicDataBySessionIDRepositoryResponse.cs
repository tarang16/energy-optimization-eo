﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserActivityDynamicDataBySessionIDRepositoryResponse
    {
        public int? pageCount { get; set; }
        public List<GetUserActivityDynamicDataBySessionIDStoredProcedureResponse>? data { get; set; }
    }
}
