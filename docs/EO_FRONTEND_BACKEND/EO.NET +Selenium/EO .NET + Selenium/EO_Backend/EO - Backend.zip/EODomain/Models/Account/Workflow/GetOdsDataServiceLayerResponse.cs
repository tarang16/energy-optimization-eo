﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetOdsDataServiceLayerResponse
    {
        public int causeId { get; set; }
        public string? cause { get; set; }
        public string? suggestion { get; set; }
        public double? causeActual { get; set; }
        public double? causeOptimum { get; set; }
        public long? deviationTimestamp { get; set; }
        public long? lastOccurence { get; set; }
        public string? causeUom { get; set; }
        public string? affiliate { get; set; }
        public string? plant { get; set; }
        public string? system { get; set; }
        public long? targetDate { get; set; }
        public int bpmInitiated { get; set; }
        public long? bpmSubmissionTimeEpoch { get; set; }
        public int stageId { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
        public int? processOperationRejection { get; set; }
        public List<Kpi>? kpis { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Kpi
    {
        public string? effect { get; set; }
        public string? effectTagName { get; set; }
        public string? effectUom { get; set; }  
        public double? effectActual { get; set; }
        public double? effectOptimum { get; set;}        
    }  
}
