﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class GeEcmUploadInfoResponse
    {
        public string? AttachmentID { get; set; }
        public string? AttachmentName { get; set; }
    }
}
