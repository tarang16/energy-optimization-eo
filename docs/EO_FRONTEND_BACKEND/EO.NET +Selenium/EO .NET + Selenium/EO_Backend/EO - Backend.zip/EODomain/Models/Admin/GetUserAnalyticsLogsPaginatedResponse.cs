﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserAnalyticsLogsPaginatedResponse
    {
        public List<GetUserAnalyticsLogsStoredProcedureResponse>? data {  get; set; }
        public int pageCount { get; set; }
    }
}
