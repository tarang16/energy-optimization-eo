﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetReconciledEnergyResponse
    {
        public decimal? totalPurchasedEnergyConsumption { get; set; }
        public decimal? energyCostIndex { get; set; }
    }
}
