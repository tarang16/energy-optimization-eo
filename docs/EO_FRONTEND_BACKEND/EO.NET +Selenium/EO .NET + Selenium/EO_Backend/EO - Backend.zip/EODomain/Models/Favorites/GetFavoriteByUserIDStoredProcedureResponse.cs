﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class GetFavoriteByUserIDStoredProcedureResponse
    {
        public int Id { get; set; }
        public string? url { get; set; }
        public string? title { get; set; }
    }
}
