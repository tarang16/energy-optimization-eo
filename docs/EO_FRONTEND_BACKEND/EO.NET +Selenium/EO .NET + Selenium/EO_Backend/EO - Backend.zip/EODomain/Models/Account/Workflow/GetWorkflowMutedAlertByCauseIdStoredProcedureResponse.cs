﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowMutedAlertByCauseIdStoredProcedureResponse
    {
        public int? frequency { get; set; }
    }
}
