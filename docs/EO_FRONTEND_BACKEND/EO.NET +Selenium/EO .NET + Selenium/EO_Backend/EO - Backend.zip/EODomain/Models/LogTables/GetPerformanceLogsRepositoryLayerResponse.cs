﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetPerformanceLogsRepositoryLayerResponse
    {
        public int? pageCount { get; set; }
        public List<GetPerformanceLogsStoredProcedureResponse>? data { get; set; }
    }
}
