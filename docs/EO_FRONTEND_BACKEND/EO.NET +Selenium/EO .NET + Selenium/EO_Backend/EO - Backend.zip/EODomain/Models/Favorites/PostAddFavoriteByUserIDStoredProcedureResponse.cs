﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class PostAddFavoriteByUserIDStoredProcedureResponse
    {
        public int ID { get; set; }
    }
}
