﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetLoginTrackerRepositoryLayerResponse
    {
        public int? pageCount { get; set; }
        public List<GetLoginTrackerStoredProcedureResponse>? data { get; set; }
    }
}
