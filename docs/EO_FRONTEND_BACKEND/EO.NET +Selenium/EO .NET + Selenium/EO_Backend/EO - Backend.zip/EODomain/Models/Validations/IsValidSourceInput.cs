﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValidationModels
{
    [ExcludeFromCodeCoverage]
    public class IsValidSourceInput
    {
        public string? tokenIp { get; set; }
        public string? requestIp { get; set; }
    }
}
