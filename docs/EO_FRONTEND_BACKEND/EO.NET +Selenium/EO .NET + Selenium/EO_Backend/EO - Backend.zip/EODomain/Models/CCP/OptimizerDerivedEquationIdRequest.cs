﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class OptimizerDerivedEquationIdRequest
    {
        public int derivedEquationId { get; set; }
    }
}
