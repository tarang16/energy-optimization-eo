﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class ResponsePIStatusByCaseID
    {
        public int caseId { get; set; }
        public string? tag { get; set; }
        public DateTime? tagTime { get; set; }
        public byte issueFlag { get; set; }
        public string? issueMessage { get; set; }
        public string? issueDetails { get; set; }

    }
}
