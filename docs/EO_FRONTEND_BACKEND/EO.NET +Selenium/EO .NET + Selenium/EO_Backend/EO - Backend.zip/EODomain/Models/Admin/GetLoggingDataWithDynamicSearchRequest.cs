﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetLoggingDataWithDynamicSearchRequest
    {
        [Range(0,10000000)]
        public int pageNumber { get; set; } = 1;

        [Range(0, 10000)]
        public int pageSize { get; set; } = 20;

        [DynamicMaxLength]
        public string? keyword { get; set; } = "";
    }
}
