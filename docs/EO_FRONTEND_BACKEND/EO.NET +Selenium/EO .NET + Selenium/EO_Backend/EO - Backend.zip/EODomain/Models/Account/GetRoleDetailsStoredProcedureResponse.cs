﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetRoleDetailsStoredProcedureResponse
    {
        public int userID { get; set; }
    }
}
