﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class ActivityTracker
    {
        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? SessionID { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? ApplicationName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? ScreenName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? FunctionalityName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? UserActionName { get; set; }

        [Range(0, 1)]
        public int IsOnline { get; set; }

        [Range(0, 1000000000)]
        public int? CreatedBy { get; set; }

        
        [DynamicMaxLength]
        public string? CreatedOn { get; set; }

        [Range(0, 1000000000)]
        public int? UpdatedBy { get; set; }
        
        [DynamicMaxLength]
        public string? UpdatedOn { get; set; }

        [AllowNull]
        public int? AffiliateID { get; set; }

        [AllowNull]
        public int? CaseID { get; set; }
    }
}
