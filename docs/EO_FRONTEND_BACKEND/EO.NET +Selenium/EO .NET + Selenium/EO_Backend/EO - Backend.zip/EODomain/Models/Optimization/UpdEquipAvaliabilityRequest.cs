﻿using EOUtility;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class UpdEquipAvaliabilityRequest
    {
        public Int32 equipmentId { get; set; }
        public bool availability { get; set; }

        [AllowNull]
        public bool? mustRun { get; set; }

    }

    [ExcludeFromCodeCoverage]
    public class UpdEquipAvaliabilityRequestData
    {
        public List<UpdEquipAvaliabilityRequest>? equipmentData { get; set; }
        [SwaggerIgnore]
        public int createdBy { get; set; }

    }

}
