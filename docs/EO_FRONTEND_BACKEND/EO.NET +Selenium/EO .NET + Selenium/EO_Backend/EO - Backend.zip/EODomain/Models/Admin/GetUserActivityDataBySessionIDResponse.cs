﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EODomain.Models.Admin;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserActivityDataBySessionIDResponse : GetUserActivityStaticDataBySessionIDStoredProcedureResponse
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public List<GetUserActivityDynamicDataBySessionIDStoredProcedureResponse>? activityData { get; set; }
        public int? pageCount { get; set; }
    }
}
