﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class GetWhatIfPlantParametersResponse
    {
        public int? caseId { get; set; }
        public string? plantName { get; set; }
        public int? tagId { get; set; }
        public string? tagName { get; set; }
        public string? tagUiDisplayName { get; set; }
        public decimal? actual { get; set; }
        public decimal? optimum { get; set; }
        public string? uomName { get; set; } 
        public int? modelId { get; set; }  
        public int? modelTagId { get; set; }  
        public bool? flagShowUi { get; set; }
        public float? referenceMax { get; set; }
        public float? referenceMin { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class GetWhatIfPlantParametersGroupedResponse
    {
        public int? modelId { get; set; }
        public List<GetWhatIfPlantParametersGroupedDetails>? plantParameterDetails { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class GetWhatIfPlantParametersGroupedDetails
    {
        public string? plantName { get; set; }
        public List<GetWhatIfPlantParametersGroupedModel>? data { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class GetWhatIfPlantParametersGroupedModel
    {
        public int? tagId { get; set; }
        public string? tagName { get; set; }
        public string? tagUiDisplayName { get; set; }
        public decimal? actual { get; set; }
        public decimal? optimum { get; set; }
        public string? uomName { get; set; }
        public int? modelTagId { get; set; }
        public bool? flagShowUi { get; set; }
        public float? referenceMax { get; set; }
        public float? referenceMin { get; set; }
    }
}
