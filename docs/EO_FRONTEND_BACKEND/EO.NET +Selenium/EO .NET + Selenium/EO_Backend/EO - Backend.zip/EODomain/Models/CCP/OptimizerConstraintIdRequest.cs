﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class OptimizerConstraintIdRequest
    {
        public int constraintId { get; set; }
    }
}
