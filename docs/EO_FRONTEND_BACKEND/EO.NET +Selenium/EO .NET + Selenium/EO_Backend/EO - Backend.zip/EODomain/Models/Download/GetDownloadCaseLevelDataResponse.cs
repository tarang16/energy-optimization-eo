﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Download
{
    
        [ExcludeFromCodeCoverage]

        public class GetDownloadCaseWiseDataResponse
        {
            public string? affiliateName { get; set; }

            public string? plantName { get; set; }

            public string? systemName { get; set; }

            public string? tagName { get; set; }

            public int tagId { get; set; }
            public DateTime? timeStamp { get; set; }
            public int modelId { get; set; }

            public string? piName { get; set; }
            public string? uom { get; set; }

            public decimal? value { get; set; }

        }

        [ExcludeFromCodeCoverage]
        public class GetDownloadCaseLevelDataResponse
        {
            [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
            [DynamicMaxLength]
            public string? Status { get; set; }
            public byte[]? fileStream { get; set; }
            public string? message { get; set; }
        }
    
}
