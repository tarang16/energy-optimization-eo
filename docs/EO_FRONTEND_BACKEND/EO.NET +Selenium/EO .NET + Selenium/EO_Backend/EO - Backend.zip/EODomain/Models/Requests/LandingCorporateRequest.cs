﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;
namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class LandingCorporateRequest
    {
        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? caseIDList { get; set; }
    }
}
