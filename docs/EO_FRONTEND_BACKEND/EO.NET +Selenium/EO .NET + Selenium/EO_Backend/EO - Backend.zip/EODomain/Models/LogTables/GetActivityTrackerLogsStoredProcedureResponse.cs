﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetActivityTrackerLogsStoredProcedureResponse
    {
        public string? firstName { get; set; }
        public string? lastName { get; set; }
        public int? employeeId { get; set; }
        public string? role { get; set; }
        public string? sessionId { get; set; }
        public string? userAgent { get; set; }
        public string? browser { get; set; }
        public string? browserVersion { get; set; }
        public string? browserLanguage { get; set; }
        public string? clientId { get; set; }
        public DateTime? sessionStartTimeStamp { get; set; }
        public long? sessionStartTimeStampEpoch { get; set; } = null;
        public DateTime? sessionEndTimeStamp { get; set; }
        public long? sessionEndTimeStampEpoch { get; set; } = null;
        public string? ipAddress { get; set; }
        public string? applicationName { get; set; }
        public string? screenName { get; set; }


        public string? functionalityName { get; set; }
        public string? userAction { get; set; }
        public DateTime? createdOn { get; set; }
        public long? createdOnEpoch { get; set; } = null;
        public int? updatedBy { get; set; }
        public DateTime? updatedOn { get; set; }
        public long? updatedOnEpoch { get; set; } = null;
        public string? affiliate { get; set; } = string.Empty;
        public string? plant { get; set; } = string.Empty;
        public string? system { get; set; } = string.Empty;
    }
}
