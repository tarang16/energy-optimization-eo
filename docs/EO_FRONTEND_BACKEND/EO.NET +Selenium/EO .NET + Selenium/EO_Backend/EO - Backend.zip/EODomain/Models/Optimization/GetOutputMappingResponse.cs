﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class GetOutputMappingResponse
    {
        public List<GetOutputMappingResponseModel>? outputDetails { get; set; }
        public int? modelStatus { get; set; }
        public string? modelMessage { get; set; }
       
        public string? url { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class GetOutputMappingResponseModel
    {
        public int caseId { get; set; }
        public int sortId { get; set; }
        public string? category { get; set; }
        public string? uiDisplayName { get; set; }
        public string? tagName { get; set; }
        public int tagId { get; set; }
        public int modelTagId { get; set; }
        public string? uomName { get; set; }
        public double? actual { get; set; }
        public double? optimum { get; set; }
        public object? statusActual { get; set; }
        public double? statusOptimum { get; set; }
        public bool flagAggregation { get; set; }
        public double? benefitActual { get;set; }
        public int? polarityActual { get; set; }
    }

   
}
