﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetUserByCaseIdResponse
    {
        public int WMUserDetailID { get; set; }
        public int EmployeeID { get; set; }
        public string? EmployeeName { get; set; }
        public string? DomainLoginID { get; set; }
        public int AffiliateCode { get; set; }
        public string? AffiliateName { get; set; }
        public string? Email { get; set; }        
        public string? Country { get; set; }
        public string? Region { get; set; }
        public string? ClaimType { get; set; }
        public int ClaimId { get; set; }
        public List<ClaimDto>? ClaimsList { get; set; }
    }
}
