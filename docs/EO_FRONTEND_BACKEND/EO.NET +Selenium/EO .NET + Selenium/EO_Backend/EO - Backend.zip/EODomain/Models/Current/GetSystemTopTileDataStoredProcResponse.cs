﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Current
{
    [ExcludeFromCodeCoverage]
    public class GetSystemTopTileDataStoredProcResponse
    {
        public int? caseId { get; set; }
        public int? tagId { get; set; }
        public string? tagName { get; set; }
        public double? actual { get; set; }
        public string? uomName { get; set; }

        public int? deviationActive { get; set; }
        public int? deviationOverdue { get; set; }

    }
}
