﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdateCleanDataRangeWithCaseIDRequest
    {
        public int caseID {  get; set; } 
        public List<UpdateCleanDataRangeRequest>? data {  get; set; }
    }
}
