﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdateCcpRequest
    {
        public int caseID { get; set; }
        public int modelID { get; set; }
        public string? tagName { get; set; }
        public byte? defaultSwitch { get; set; }
        public double? defaultValue { get; set; }
        public double? tagMin { get; set; }
        public double? tagMax { get; set; }
        public int? tagOutOfBoundSwitch { get; set; }
        public int? tagStuckSwitch { get; set; }
        public int? tagNanSwitch { get; set; }

    }
}
