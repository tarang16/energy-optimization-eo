﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CcpOptimizer
{
    [ExcludeFromCodeCoverage]
    public class UpdateSubModelParameterRequest
    {
        public int subModelParameterId { get; set; }  
        public required string value { get; set; }
    }
}
