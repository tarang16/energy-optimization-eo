﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetCaseInfoByByCaseIdListResponse
    {
        public int caseID { get; set; }
        public string? caseName { get; set; }
        public int? frequency { get; set; }
        public int? slot { get; set; }
        public string? description { get; set; }
        public string? url { get; set; }
        public int? affiliateID { get; set; }
        public int? active { get; set; }
    }
}
