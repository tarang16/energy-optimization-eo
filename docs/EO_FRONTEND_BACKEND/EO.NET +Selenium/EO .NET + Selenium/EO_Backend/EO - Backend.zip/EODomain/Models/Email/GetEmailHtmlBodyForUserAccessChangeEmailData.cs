﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class GetEmailHtmlBodyForUserAccessChangeEmailData
    {
        public string? section { get; set; }
        public string? html { get; set; }
    }
}
