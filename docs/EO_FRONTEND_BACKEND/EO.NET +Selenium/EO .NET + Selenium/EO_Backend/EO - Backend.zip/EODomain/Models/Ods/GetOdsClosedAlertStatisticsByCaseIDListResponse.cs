﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsClosedAlertStatisticsByCaseIDListResponse
    {
        public string? year { get; set; }
        public string? monthName { get; set; }
        public int closedImplemented { get; set; }
        public int closedRejected { get; set; }
        public int closedSystem { get; set; }
        public int closedTotal { get; set; }
        public int totalGenerated { get; set; }
        public string? utilizationRate { get; set; }
        public int pending { get; set; }
        public int overdue { get; set; }
        public int inProgress { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
    }
}
