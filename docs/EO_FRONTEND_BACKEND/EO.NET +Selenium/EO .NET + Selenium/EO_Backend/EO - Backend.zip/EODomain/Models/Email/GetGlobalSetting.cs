﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class GetGlobalSetting
    {
        public string?  keys { get; set; }
        public string? preferences { get; set; }
        public string? parameter { get; set; }
    }
}
