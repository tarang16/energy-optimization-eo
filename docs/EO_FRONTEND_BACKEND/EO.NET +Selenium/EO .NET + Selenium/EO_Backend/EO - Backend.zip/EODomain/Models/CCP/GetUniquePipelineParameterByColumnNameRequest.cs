﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetUniquePipelineParameterByColumnNameRequest
    {
        public string? ColumnName { get; set; }
    }
}
