﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetValueCreationSpanDataForCaseResponse
    {

        public string? vCSpanID { get; set; }
        public int caseID { get; set; }
        public string? tagName { get; set; }
        public DateTime? startTime { get; set; }
        public DateTime? endTime { get; set; }
        public long? startTimeEpoch { get; set; }
        public long? endTimeEpoch { get; set; }
        public double realizedValue { get; set; }
        public double lostValue { get; set; }
    }
}
