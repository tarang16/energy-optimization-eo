﻿using EODomain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public  class GetModelDetailsByCaseIDListRequest
    {
        [Required]
        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]        
        public string? caseIDList { get; set; }
    }
}
