﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValidationModels
{
    [ExcludeFromCodeCoverage]
    public class StatusMessageResponse
    {
        public bool isValid { get; set; }
        public string? message { get; set; }
    }
}
