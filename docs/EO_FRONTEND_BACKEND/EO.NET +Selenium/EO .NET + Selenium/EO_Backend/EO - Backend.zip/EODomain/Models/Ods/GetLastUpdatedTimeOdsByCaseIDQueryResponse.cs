﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetLastUpdatedTimeOdsByCaseIDQueryResponse
    {
        public DateTime lastUpdatedTime { get; set; }
        public long? lastUpdatedTimeEpoch { get; set; }
    }

}
