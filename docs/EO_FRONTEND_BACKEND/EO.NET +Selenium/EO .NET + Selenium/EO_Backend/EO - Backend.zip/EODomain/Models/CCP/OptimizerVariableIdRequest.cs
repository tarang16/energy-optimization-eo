﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class OptimizerVariableIdRequest
    {
        public int variableId { get; set; }
    }
}
