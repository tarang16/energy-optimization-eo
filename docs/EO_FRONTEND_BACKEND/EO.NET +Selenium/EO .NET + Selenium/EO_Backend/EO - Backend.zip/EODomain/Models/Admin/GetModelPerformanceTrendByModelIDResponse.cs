﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public  class GetModelPerformanceTrendByModelIDResponse
    {
        public int? ModelID { get; set; }
        public string? Parameter { get; set; }                                                                                              
        public int? model_version_id { get; set; }
        public DateTime? dateTimeStamp { get; set; }
        public long? timeEpoch { get; set; }
        public double? BestScore { get; set; }
        public int? ModelHealth { get; set; }
        public double? Value { get; set; }
        public double? BaseModelValue { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class GetModelPerformanceTrendByModelIDServiceLayerResponse
    {
        public int? modelID { get; set; }
        public string? parameter { get; set; }
        public int? modelVersionID { get; set; }
        public double? bestScore { get; set; }
        public List<ModelTrendData>? data { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class ModelTrendData
    {
        public double? v { get; set; }
        public double? bm { get; set; }
        public long? et { get; set; }
        public int? mh { get; set; }
        public DateTime? dt { get; set; }
    }
}
