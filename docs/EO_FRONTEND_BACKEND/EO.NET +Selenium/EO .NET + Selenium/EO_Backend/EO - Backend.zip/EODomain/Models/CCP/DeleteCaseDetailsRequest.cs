﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class DeleteCaseDetailsRequest
    {
        public int caseID { get; set; }
        public short isActive { get; set; }
    }
}
