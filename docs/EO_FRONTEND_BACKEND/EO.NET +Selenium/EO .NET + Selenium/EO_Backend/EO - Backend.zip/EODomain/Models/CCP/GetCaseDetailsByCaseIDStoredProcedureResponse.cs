﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetCaseDetailsByCaseIDStoredProcedureResponse
    {
        public int caseId { get; set; }
        public string? caseName { get; set; }
        public int plantId { get; set; }
        public string? plantName { get; set; }
        public int affiliateSapID { get; set; }
        public string? affiliateName { get; set; }
        public int processFrequency { get; set; }
		public string? referenceDocUrl { get; set; }
		public int slot { get; set; }
		public string? description { get; set; }
        public int active { get; set; }
    }
}
