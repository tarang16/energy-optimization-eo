﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public  class GetModelDetailsByCaseIDListResponse
    {
        public int? caseID { get; set; }
        public int? modelID { get; set; }
        public string? modelName { get; set; }
        public string? modelDescription { get; set; }
        public string? tagRoleModelType { get; set; }

    }
}
