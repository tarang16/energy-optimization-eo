﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class UpdateOptimizationPriceInput
    {
        public int caseId { get; set; }
       
        public int modelTagId { get; set; }
        public float? currentValue { get; set; }
    }
}
