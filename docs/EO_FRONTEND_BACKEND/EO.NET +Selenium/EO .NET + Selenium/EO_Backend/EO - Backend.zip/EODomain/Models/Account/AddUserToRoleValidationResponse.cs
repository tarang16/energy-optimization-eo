﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class AddUserToRoleValidationResponse
    {
        public bool isValid { get; set; }
        public string? message { get; set; }
        public List<GetUsersByRoleStoredProcedureResponse>? userData { get; set; }
    }
}
