﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetTerminatedInstancesLogResponse
    {
        public int? requestID { get; set; }
        public int? processInstanceID { get; set; }
        public string? affiliateName { get; set; }
        public string? plantName { get; set; }
        public string? systemName { get; set; }
        public string? bpmInitiated { get; set; }
        public string? status { get; set; }
        public string? createdBy { get; set; }
        public DateTime? createdOn { get; set; }
    }
}
