﻿using EODomain.Common;
using EOUtility;
using Microsoft.AspNetCore.Http.HttpResults;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class AddOptimizerParameterRequest
    {
        [Range(0, 100000000)]
        public int? modelTagId { get; set; }
        
        public bool? flagParameter { get; set; }
    }
}
