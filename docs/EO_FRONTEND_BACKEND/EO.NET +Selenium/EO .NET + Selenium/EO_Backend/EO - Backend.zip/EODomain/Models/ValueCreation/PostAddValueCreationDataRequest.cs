﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;


namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class PostAddValueCreationDataRequest
    {
        [Range(0, 100000000)]
        public int? vCActionID { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [Required]
        public string? actionTitle { get; set; }

        [Range(0, 100000000)]
        public int caseID { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [Required]
        public string? actionDescription { get; set; }

        [Range(0, 100000000)]
        public int potentialPeriod { get; set; }
    }
}
