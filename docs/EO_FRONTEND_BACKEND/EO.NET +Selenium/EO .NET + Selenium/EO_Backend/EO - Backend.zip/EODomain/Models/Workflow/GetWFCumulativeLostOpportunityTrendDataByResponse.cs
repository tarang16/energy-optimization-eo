﻿
using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWFCumulativeLostOpportunityTrendDataByResponse
    {
        public DateTime? timeStamp { get; set; }

        public int? lastOpportunity { get; set; }

        public int? timeEpoch { get; set; }

    }
}
