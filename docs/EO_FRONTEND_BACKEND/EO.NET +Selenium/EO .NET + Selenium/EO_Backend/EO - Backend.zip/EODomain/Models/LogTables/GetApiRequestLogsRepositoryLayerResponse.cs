﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetApiRequestLogsRepositoryLayerResponse
    {
        public int? pageCount { get; set; }
        public List<GetApiRequestLogsStoredProcedureResponse>? data { get; set; }
    }
}
