﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsClosedAlertStatisticsByCaseIDListRequest
    {
        public string? caseIdList { get; set; }
        public DateTime dateTime { get; set; }
    }
}
