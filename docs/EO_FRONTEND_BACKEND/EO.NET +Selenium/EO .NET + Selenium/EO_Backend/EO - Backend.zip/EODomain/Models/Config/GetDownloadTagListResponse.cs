﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetDownloadTagListResponse
    {
        public int? plant_id { get; set; }
        public string? plant_name { get; set; }
        public int? affiliate_sap_id { get; set; }
        public string? tagList { get; set; }
        public string? nameShort { get; set; }
        public string? tagLevel { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class GetDownloadDataResponse
    {
        [RegularExpression(Constants.ENGLISH_TEXT_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? Status { get; set; }
        public byte[]? fileStream { get; set; }
        public string? message { get; set; }
    }
}
