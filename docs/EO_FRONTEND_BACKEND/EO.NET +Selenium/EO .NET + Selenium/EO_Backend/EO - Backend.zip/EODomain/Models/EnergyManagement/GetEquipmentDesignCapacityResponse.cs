﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetEquipmentDesignCapacityResponse
    {
        public dynamic? designCapacity {  get; set; }   
        public dynamic? kevUom { get; set; }
    }
}
