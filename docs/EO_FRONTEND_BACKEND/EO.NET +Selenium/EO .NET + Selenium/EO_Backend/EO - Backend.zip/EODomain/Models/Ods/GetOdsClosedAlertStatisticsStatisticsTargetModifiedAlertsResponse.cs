﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsResponse
    {
        public int alertId { get; set; }
        public string? system { get; set; }
        public long dueDateEpoch { get; set; }
        public int targetModifiedCount { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
    }
}
