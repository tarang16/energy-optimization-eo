﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowUsersByRoleRequest
    {
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? role { get; set; }

        [Range(0, 10000)]
        [AllowNull]
        public int? affiliateId { get; set; }
    }
}
