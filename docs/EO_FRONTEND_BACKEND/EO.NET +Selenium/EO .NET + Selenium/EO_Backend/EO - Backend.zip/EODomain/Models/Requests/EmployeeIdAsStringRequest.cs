﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class EmployeeIdAsStringRequest
    {
        public string? employeeID { get; set; }
    }
}
