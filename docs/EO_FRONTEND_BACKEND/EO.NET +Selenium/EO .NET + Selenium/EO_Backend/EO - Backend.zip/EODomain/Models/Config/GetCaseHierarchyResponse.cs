﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetCaseHierarchyResponse
    {
        public string? caseId { get; set; }
        public string? region { get; set; }
        public string? regionShortName { get; set; }
        public string? country { get; set; }
        public string? affiliate { get; set; }
        public string? caseName { get; set; }
        public int? affiliateId { get; set; }
        public int? affiliateSapId { get; set; }
        public string? affiliateImage { get; set; }
    }
}
