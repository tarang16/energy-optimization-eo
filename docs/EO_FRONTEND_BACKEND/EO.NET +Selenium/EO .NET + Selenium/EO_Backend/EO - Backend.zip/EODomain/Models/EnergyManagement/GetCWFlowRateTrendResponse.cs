﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetCWFlowRateTrendResponse
    {
        public int? dateFormat { get; set; }
        public decimal? coolingWaterCost { get; set; }
        public decimal? coolingWaterCostTarget { get; set; }
        public int? closedCoolingWaterFlowRate { get; set; }
        public int? seaWaterFlowRate { get; set; }
    }
}
