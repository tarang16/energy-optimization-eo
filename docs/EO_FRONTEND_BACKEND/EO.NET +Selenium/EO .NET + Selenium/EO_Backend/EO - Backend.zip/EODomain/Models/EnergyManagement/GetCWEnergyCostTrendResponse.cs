﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetCWEnergyCostTrendResponse
    {
        public int? dateFormat { get; set; }
        public decimal? cwChemicalCost { get; set; }
        public decimal? cwEnergyCost { get; set; }
        public decimal? cwWaterChemCost { get; set; }
    }
}
