﻿using System.Net;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class WhatIfOutputResponse
    {
        public List<WhatIfOutputResponseModel>? data { get; set; }
        public HttpStatusCode status { get; set; }
        public BadRequestModel? message { get; set; } = null;
        public string? url { get; set; }
        public WhatIfOutputErrorResponse? responseException { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfOutputResponseModel
    {
        public string? current { get; set; }
        public string? optimum { get; set; }
        public decimal? tag_id { get; set; }
        public decimal? model_id { get; set; }
        public string? actual { get; set; }
        public decimal? model_tag_id { get; set; }
        public decimal? model_status { get; set; }
        public string? model_message { get; set; }

        public string? polarity { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfOutputErrorResponse
    {
        public List<WhatIfOutputErrorResponseModel>? data { get; set; }
        
        public HttpStatusCode status { get; set; }
        public BadRequestModel? message { get; set; } = null;
    }
    [ExcludeFromCodeCoverage]
    public class WhatIfOutputErrorResponseModel
    {
        public string? optimum { get; set; }
        public string? model_id { get; set; }
        public string? actual { get; set; }
        public string? model_tag_id { get; set; }
        public decimal? model_status { get; set; }
        public string? model_message { get; set; }

    }
}
