﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowPmDelegationInfoStoredProcedureResponse
    {
        public string? assignedTo { get; set; }
        public int delegatedAfterDays { get; set; }
        public DateTime? notAvailableUpto { get; set; }
        public long? notAvailableUptoEpoch { get; set; }
        public string? assigneToName { get; set; }
        public int? active { get; set; }
        
    }
}
