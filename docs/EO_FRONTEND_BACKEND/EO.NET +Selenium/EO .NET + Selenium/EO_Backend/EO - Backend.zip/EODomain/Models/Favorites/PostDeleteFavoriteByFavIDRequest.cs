﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;


namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class PostDeleteFavoriteByFavIDRequest
    {
        [Range(0, 100000000)]
        public int ID { get; set; }

        [Range(0, 100000000)]
        public int userID { get; set; }
    }
}
