﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetLoginActivityDataStoredProcedureResponse
    {
        public int? EmployeeID { get; set; }
        public int? IsOnline { get; set; }
        public int? UpdatedBy { get; set; }
        public string? SessionId { get; set; }
        public string? Role { get; set; }        
        public string? BrowserName { get; set; }
        public string? IpAddress { get; set; }
        public string? ApplicationName { get; set; }
        public DateTime? LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }
        public DateTime? CreatedOn { get; set; }
        public DateTime? UpdatedOn { get; set; }
        
        
        
    }
}
