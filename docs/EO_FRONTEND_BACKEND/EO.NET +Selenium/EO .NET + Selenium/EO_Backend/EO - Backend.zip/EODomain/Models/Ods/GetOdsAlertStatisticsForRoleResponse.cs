﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAlertStatisticsForRoleResponse
    {
        public string? role { get; set; }
        public int pending { get; set; }
        public int inProgress { get; set; }
        public int overdue { get; set; }
        public int total { get; set; }
    }
}
