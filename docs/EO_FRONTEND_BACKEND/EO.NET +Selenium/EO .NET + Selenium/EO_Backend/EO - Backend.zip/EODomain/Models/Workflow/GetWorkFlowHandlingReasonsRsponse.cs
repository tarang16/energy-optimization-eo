﻿
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkFlowHandlingReasonsRsponse
    {
        public int? reasonID { get; set; }
        public int? roleID { get; set; }
        public string? role { get; set; }
        public string? reason { get; set; }

    }
}
