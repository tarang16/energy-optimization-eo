﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.InfraJobServices
{
    [ExcludeFromCodeCoverage]
    public class GetInfraStatusFrequencyResponse
    {
        public int? InfraId { get; set; }
        public string? ServiceUrl { get; set; }
        public string? Route { get; set; }
        public string? ServiceType { get; set; }
        public DateTime? LastTriggeredTime { get; set; }
        public int? MinuteFrequency { get; set; }
        public int? IsActive { get; set; }

    }
}
