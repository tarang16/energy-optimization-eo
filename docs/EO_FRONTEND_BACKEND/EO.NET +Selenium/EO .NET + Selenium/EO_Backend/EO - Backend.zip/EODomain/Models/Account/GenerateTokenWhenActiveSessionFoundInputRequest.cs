﻿using EODomain.Models.LogTables;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GenerateTokenWhenActiveSessionFoundInputRequest
    {
        public GetLatestLoginSessionByUserStoredProcedureResponse? loginSessionData { get; set; }
        public Guid guid { get; set; }
        public Guid tokenGuid { get; set; }
        public User? user { get; set; }
        public string? ipAddress { get; set; }
        public int forcedLogin { get; set; }
        public string? browser { get; set; }
    }
}
