﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAlertStatisticsPendingAlertsResponse
    {
        public int alertId { get; set; }
        public string? name { get; set; }
        public string? role { get; set; }
        public DateTime pendingSince { get; set; }
        public long pendingSinceEpoch { get; set; }

        public double? cumulativeLostOpportunity { get; set; }

    }
}
