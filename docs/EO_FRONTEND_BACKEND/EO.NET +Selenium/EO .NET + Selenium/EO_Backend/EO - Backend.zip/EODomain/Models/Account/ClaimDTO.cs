﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class ClaimDto
    {
        public int claimId { get; set; }
        public string? claimType { get; set; }
        public string? claimValue { get; set; }

    }
}
