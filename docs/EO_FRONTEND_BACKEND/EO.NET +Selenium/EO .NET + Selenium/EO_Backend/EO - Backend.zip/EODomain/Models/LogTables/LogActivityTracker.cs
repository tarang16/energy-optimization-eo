﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class LogActivityTracker
    {
        public string? RoleID { get; set; }
        public int? UserID { get; set; }
        public string? IpAddress { get; set; }
        public string? ClientID { get; set; }
        public string? UserAgent { get; set; }
        public string? BrowserName { get; set; }
        public string? SessionID { get; set; }
        public string? SessionStartTimestamp { get; set; }
        public string? SessionEndTimestamp { get; set; }
        public int? ApplicationID { get; set; }
        public int? ScreenID { get; set; }
        public int? FunctionalityID { get; set; }
        public int? UserActionID { get; set; }
        public int? IsOnline { get; set; }
        public int? CreatedBy { get; set; }
        public string? CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        public string? UpdatedOn { get; set; }
        public string? BrowserVersion { get; set; }
        public string? BrowserLanguage { get; set;}
    }
}
