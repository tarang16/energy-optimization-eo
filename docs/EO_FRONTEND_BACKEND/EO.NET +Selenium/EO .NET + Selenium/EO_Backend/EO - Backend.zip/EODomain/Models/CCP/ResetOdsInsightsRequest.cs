﻿using EOUtility;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class ResetOdsInsightsRequest
    {
        [Range(0, 100000000)]
        public int caseID { get; set; }

        [SwaggerIgnore]
        [Range(0, 100000000)]
        public int updatedBy { get; set; }
    }
}
