﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class GetAllPiTagsByCategoryRequest
    {
        public string? databaseWebId { get; set; }
        public string? category { get; set; }
        public int maxCount { get; set; }
        public int totalItems { get; set; }
    }
}
