﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowMetaDataAndDetails
    {
        public GetOdsAssigneeStoredProcedureResponse? metaData { get; set; }
        public GetOdsDataServiceLayerResponse? details { get; set; }
    }
}
