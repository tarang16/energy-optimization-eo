﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class AffiliateIdListClaimTypeRequest
    {
        [Required]
        public string? affiliateIDList { get; set; }
        [Required]
        public string? claimType { get; set; }
    }
}
