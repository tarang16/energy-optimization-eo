﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetPiAfConstantsRequest
    {
        [Required]
        public int? caseID { get; set; }
    }
}
