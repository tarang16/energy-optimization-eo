﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class GetPiDataValidationResponse
    {
        public int status { get; set; }
        public string? piTagName { get; set; }
        public string? value { get; set; }
        public string? timeStamp { get; set; }
        public string? uom { get; set; } = null;
    }
}
