﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetTopTileReconciledDataResponse
    {
        public decimal? reconciledEnergy { get; set; }
        public decimal? reconciledEnergyCostIndex { get; set; }
        public decimal? reconciledEnergyConsumedElectricity { get; set; }
        public decimal? reconciledEnergyConsumedFuel { get; set; }
        public decimal? reconciledEnergyConsumedCrudeOil { get; set; }
    }
}
