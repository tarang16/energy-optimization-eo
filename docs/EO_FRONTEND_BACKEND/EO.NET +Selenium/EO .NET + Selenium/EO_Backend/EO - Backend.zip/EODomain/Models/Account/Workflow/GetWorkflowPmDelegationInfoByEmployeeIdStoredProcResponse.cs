﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowPmDelegationInfoByEmployeeIdStoredProcResponse
    {
        public string? processEngineerId {  get; set; }
        public string? employeeId { get; set; }
        public string? employeeName { get; set; }
        public int? affiliateId {  get; set; }
        public string? affiliate { get; set; }
        public string? assignedTo { get; set; }
        public string? assignedToEmployeeName { get; set; }
        public int? delegatedAfterDays { get; set; }
        public DateTime? immediateAutoDelegateTill { get; set; }
        public long? immediateAutoDelegateTillEpoch { get; set; }
        public int? isActive { get; set; }
    }
}
