﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class GetInfraMonitoringResponse
    {
        public int? infraId { get; set; }
        public string? ServiceUrl { get; set; }
        public string? Route { get; set; }
        public string? ServiceType { get; set; }
        public int? responseCode { get; set; }
        public string? response { get; set; }
        public int? Value { get; set; }
        public int? IsActive { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? timeEpoch { get; set; }
    }
}
