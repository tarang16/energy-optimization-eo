﻿using EODomain.Models.Account.Workflow;
using EODomain.Models.LogTables;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetDataForAuthenticationByUserIdStoredProcedureResponse
    {
        public GetRolesRoleIdByUserIdStoredProcResponse? userRole { get; set; }
        public GetLatestLoginSessionByUserStoredProcedureResponse? sessionData { get; set; }
        public List<ClaimDto>? claims { get; set; }
        public List<GetPlantBasedClaimsByUserIdStoredProcedureResponse>? plantClaims { get; set; }
        public List<GetWorkflowUserRoleByUserId>? workflowData { get; set; }
    }
}
