﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class PostAddValueCreationSpanDataStoredProcedureRequest : PostAddValueCreationSpanDataRequest
    {
        public int isActive { get; set; }
        public int createdBy { get; set; }
    }
}
