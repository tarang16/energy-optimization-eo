﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class OptimizerParameterIdRequest
    {
        public int modelTagId { get; set; }
    }
}
