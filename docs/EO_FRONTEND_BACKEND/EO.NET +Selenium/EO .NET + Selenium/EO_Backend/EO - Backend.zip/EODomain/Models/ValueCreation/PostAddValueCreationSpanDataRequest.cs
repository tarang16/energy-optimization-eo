﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;


namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class PostAddValueCreationSpanDataRequest
    {
        [Range(0, 100000000)]
        public int? vCSpanID { get; set; }

        [Range(0, 100000000)]
        public int caseID { get; set; }

        [Range(0, 1000000000)]
        public float baseLineObjFn { get; set; }

        [Range(0, 1000000000)]
        public int vcCaseInfoID { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime? sTime { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime? eTime { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [MaxLength(500)]
        public string? remarks { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [MaxLength(500)]
        public string? changes { get; set; }

        public string? vcactionID { get; set; }
    }
}
