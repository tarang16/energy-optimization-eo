﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Current
{
    [ExcludeFromCodeCoverage]
    public class GetMonitoringDataStoredProcedurePaginatedResponse
    {
        public List<GetMonitoringDataStoredProcedureResponse>? GetMonitoringDataStoredProcedureResponse { get; set; }
        public int pageCount { get; set; }
    }
}
