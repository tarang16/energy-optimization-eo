﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class PostAddRoleToUsersStoredProcedureResponse
    {
        public int userID { get; set; }
        public string? roleID { get; set; }
    }
}
