﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowHistoricalDataForAllUsersStoredProcedureResponse
    {
        public int alertId { get; set; }
        public DateTime time { get; set; }
        public long timeEpoch { get; set; }
        public string? empName { get; set; }
        public string? comments { get; set; } = null;
        public string? considerSuggestion { get; set; }
        public string? suggestion { get; set; }
        public double? actual { get; set; }
        public double? optimum { get; set; }
        public DateTime deviationTime { get; set; }
        public long deviationTimeEpoch { get; set; }
        public DateTime lastOccurrence { get; set; }
        public long lastOccurrenceEpoch { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
    }
}
