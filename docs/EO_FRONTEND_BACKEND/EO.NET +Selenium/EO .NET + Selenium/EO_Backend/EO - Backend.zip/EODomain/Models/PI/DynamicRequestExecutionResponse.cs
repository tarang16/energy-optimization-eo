﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class DynamicRequestExecutionResponse
    {
        public int status { get; set; }
        public string? data { get; set; }
    }
}
