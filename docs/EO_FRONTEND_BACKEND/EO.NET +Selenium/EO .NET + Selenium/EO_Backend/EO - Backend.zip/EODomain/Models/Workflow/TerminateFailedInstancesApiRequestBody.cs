﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class TerminateFailedInstancesApiRequestBody
    {
        public string? assignedBy { get; set; }
    }
}
