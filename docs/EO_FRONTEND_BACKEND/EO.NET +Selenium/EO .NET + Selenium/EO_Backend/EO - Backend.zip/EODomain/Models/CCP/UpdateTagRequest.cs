﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdateTagRequest
    {
        public int caseID { get; set; }
        public int tagID { get; set; }
        public string? tagName { get;set;}    
        public string? tagType {get;set;}    
        public string? inferredExpression {get;set;}    
        public string? piName {get;set;}    
        public string? dataType {get;set;}    
        public string? uiDisplayName { get;set;}    
        public string? description {get;set;}    
        public int? modelId {get;set;}    
        public int? uomID {get;set;}    
        public bool? flagMA {get;set;}
        public bool? flagMAFilter {get;set;}    
        public bool? flagDataAvailableCheck {get;set;}
        public bool? flagOutput {get;set;}    
        public bool? flagOutputRunAlways {get;set;}
        public string? polarityExpression {get;set;}    
        public string? designExpression {get;set;}    
        public int? blockId { get;set;}    
    }
}
