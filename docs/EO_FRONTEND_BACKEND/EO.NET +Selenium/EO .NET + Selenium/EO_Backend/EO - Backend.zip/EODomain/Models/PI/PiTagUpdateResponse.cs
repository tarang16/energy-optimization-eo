﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class PiTagUpdateResponse
    {
        public int? Status { get; set; }
    }
}
