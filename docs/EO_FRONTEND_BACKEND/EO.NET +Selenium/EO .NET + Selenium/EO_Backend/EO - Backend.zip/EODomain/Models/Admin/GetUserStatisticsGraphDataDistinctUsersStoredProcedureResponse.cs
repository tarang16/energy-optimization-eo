﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsGraphDataDistinctUsersStoredProcedureResponse
    {
        public DateTime? timeWise {  get; set; }    
        public long? timeWiseEpoch {  get; set; }    
        public string? affiliateName {  get; set; }    
        public int? distinctUsers { get; set; }
    }
}
