﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetLoginActivitityDataResponse : GetLoginActivityDataStoredProcedureResponse
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
    }
}
