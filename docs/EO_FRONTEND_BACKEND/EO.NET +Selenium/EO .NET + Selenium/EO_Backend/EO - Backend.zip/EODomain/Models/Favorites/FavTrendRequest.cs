﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class FavTrendRequest
    {
        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public Guid FavTrendGUID { get; set;}
    }
}
