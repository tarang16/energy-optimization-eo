﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdateCleanDataRangeRequest
    {
        public int rangeID { get; set; }
        [AllowNull]
        public int modelID { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [AllowNull]
        public string? packetType { get; set; }

        [AllowNull]
        public string? startTime { get; set; }

        [AllowNull]
        public string? startTimeRef { get; set; }

        [AllowNull]
        public string? endTime { get; set; }

        [AllowNull]
        public string? endTimeRef { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [AllowNull]
        public string? modelType { get; set; }

        [AllowNull]
        public int? lbmVersionID { get; set; }

        [AllowNull]
        public int? modelVersionID { get; set; }

        public byte active { get; set; }

        [AllowNull]
        public int? runLength { get; set; }
    }
}
