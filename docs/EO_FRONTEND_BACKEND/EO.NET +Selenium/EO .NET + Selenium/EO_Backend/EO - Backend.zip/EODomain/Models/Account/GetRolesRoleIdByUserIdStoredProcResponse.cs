﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetRolesRoleIdByUserIdStoredProcResponse
    {
        public string? name {  get; set; }
        public string? roleId { get; set;}
    }
}
