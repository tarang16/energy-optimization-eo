﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class MuteAlertsLogRequest
    {
        public int affiliateId { get; set; }
        public bool active { get; set; }
    }
}
