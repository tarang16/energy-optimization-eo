﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetVCByCaseIDListResponse
    {
        public int? caseID { get; set; }
        public string? caseName { get; set; }
        public string? category { get; set; }
        public double? realizedvalue { get; set; }
        public double? lostvalue { get; set; }
    }
}
