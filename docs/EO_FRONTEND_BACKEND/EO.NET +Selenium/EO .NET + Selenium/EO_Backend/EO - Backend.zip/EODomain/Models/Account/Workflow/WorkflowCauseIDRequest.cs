﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class WorkflowCauseIDRequest
    {
        [Required]
        [Range(0,1000000000)]
        public int reqID { get; set; }
    }
}
