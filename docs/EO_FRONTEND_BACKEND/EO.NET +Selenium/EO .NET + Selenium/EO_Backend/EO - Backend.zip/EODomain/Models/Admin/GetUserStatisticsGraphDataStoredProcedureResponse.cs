﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsGraphDataStoredProcedureResponse
    {
        public DateTime? timeWise {  get; set; }   
        public long? timeWiseEpoch {  get; set; }   
        public string? affiliateName { get; set; }
        public double? avgScreenTimeInMin { get; set; }
    }
}
