﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetUserActivityDataStoredProcedureResponse
    {
        public string? Role { get; set; }
        public int? UpdatedBy { get; set; }
        public string? Browser { get; set; }
        public int? EmployeeID { get; set; }
        public string? ClientID { get; set; }
        public string? SessionID { get; set; }
        public string? UserAgent { get; set; }
        public string? IpAddress { get; set; }
        public string? UserAction { get; set; }
        public string? ScreenName { get; set; }
        public DateTime? CreatedOn { get; set; }        
        public DateTime? UpdatedOn { get; set; }
        public string? BrowserVersion { get; set; }
        public string? BrowserLanguage { get; set; }
        public string? ApplicationName { get; set; }
        public string? FunctionalityID { get; set; }
        public DateTime? SessionEndTimestamp { get; set; }
        public DateTime? SessionStartTimestamp { get; set; }
    }
}
