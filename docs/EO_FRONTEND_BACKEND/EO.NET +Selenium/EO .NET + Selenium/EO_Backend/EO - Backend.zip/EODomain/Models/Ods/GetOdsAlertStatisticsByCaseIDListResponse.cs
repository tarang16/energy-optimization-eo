﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAlertStatisticsByCaseIDListResponse
    {

        public int pending { get; set; }
        public int inProgress { get; set; }
        public int overdue { get; set; }
        public int totalActive { get; set; }
        public int closedImplemented { get; set; }
        public int closedRejected { get; set; }
        public int closedSystem { get; set; }
        public int closedTotal { get; set; }
        public int total { get; set; }
        public int overdueSince { get; set; }
        public int targetDateModified { get; set; }

    }
}
