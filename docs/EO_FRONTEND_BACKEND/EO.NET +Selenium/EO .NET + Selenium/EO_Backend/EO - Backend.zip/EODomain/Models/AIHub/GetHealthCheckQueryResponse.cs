﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.AIHub
{
    [ExcludeFromCodeCoverage]
    public class GetHealthCheckQueryResponse
    {
        public bool healthy { get; set; }
    }
}
