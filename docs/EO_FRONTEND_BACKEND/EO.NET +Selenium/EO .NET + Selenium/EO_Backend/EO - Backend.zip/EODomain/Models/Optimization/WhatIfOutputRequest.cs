﻿using EOUtility;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class WhatIfOutputRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }

        public int modelID { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime time { get; set; }
        public string? scenarioName { get; set; }

        [SwaggerIgnore]
        public int userID { get; set; }

        public List<WhatIfOutputRequestModel>? data { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfOutputRequestModel
    {
        public string? category { get; set; }
        public string? modelTagId { get; set; }
        public string? value { get; set; }
        public string? bias { get; set; }
        public string? availability { get; set; }
        public string? mustRun { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfOutputRMRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }

        public int modelID { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime time { get; set; }
        public string? scenarioName { get; set; }

        [SwaggerIgnore]
        public int userID { get; set; }
        public List<WhatIfOutputRMRequestModel>? data { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfOutputRMRequestModel
    {
        public string? category { get; set; }
        public string? model_tag_id { get; set; }
        public string? tag_value { get; set; }
        public string? bias { get; set; }
        public string? availability { get; set; }
        public string? must_run { get; set; }
    }

}
