﻿using EODomain.Common;
using EOUtility;
using Microsoft.AspNetCore.Http.HttpResults;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class AddOptimizerVariableRequest
    {
        [Range(0, 100000000)]
        public int? variableId { get; set; }

        public int modelTagId { get; set; }

        public float lowerBound { get; set; }

        public float upperBound { get; set; }

        public bool flagInteger { get; set; }

        public int lowerBoundSwitch { get; set; }

        public int upperBoundSwitch { get; set; }

        public int initialValueSwitch { get; set; }

        public string? lowerBoundExpression { get; set; }

        public string? upperBoundExpression { get; set; }
    }
}
