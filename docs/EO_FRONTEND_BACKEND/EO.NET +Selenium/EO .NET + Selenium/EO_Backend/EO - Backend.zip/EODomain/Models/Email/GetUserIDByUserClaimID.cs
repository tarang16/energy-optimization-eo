﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]    
    public class GetUserIDByUserClaimID
    {
        public int userID { get; set; }
        public string? claimType { get; set; }
        public string? affiliate { get; set; }
        public string? plant { get; set; }
    }
}
