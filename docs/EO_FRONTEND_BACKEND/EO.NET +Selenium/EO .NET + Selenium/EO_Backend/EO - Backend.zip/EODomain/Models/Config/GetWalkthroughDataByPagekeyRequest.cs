﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetWalkthroughDataByPagekeyRequest
    {
        public required string pageKey { get; set; }
    }
}
