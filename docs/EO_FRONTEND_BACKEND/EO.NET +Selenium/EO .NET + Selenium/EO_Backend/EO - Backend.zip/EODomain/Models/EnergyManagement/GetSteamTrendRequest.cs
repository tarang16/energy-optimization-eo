﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetSteamTrendRequest
    {
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }
        [AllowNull]
        public int? affiliateID { get; set; }
        [AllowNull]
        public string? plantNameList { get; set; }
        [AllowNull]
        public string? groupBy { get; set; } = "plantview";
    }
}
