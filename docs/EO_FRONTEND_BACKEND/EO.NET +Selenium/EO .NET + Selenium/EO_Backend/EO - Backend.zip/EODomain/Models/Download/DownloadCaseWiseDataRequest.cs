﻿using EOUtility;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Download
{
    [ExcludeFromCodeCoverage]
    public class DownloadCaseWiseDataRequest
    {
       public string? tagIdList { get; set; }
       public int? caseId { get; set; }
       public DateTime? sTime { get; set; }
       public DateTime? eTime { get; set; }

        [SwaggerIgnore]
        public int chunkSize { get; set; }
    }
}
