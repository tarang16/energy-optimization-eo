﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetValueCreationSpanDataStoredProcedureResponse
    {
        public int? vCSpanID { get; set; }
        public int? caseID { get; set; }
        public double? baseLineObjFn { get; set; }
        public string? category { get; set; }
        public string? tagName { get; set; }
        public string? displayName { get; set; }
        public string? displayUom { get; set; }
        public double? realizedValue { get; set; }
        public double? lostValue { get; set; }
        public int? vCActionID { get; set; }
        public string? actionTitle { get; set; }
        public string? actionDescription { get; set; }
        public string? potentialPeriod { get; set; }
        public DateTime? startTime { get; set; }
        public DateTime? endTime { get; set; }
        public int? vCCaseInfoID { get; set; }
        public List<GetValueCreationSpanActionResponse?>? Actions { get; set; }
    }
}
