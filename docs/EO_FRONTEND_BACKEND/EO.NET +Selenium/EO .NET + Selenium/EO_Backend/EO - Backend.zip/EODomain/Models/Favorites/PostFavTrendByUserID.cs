﻿using EODomain.Common;
using System.Text.Json.Serialization;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class PostFavTrendByUserID
    {
        
        public Guid ID { get; set; }

        [RegularExpression(Constants.ENGLISH_DESCRIPTION_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? url { get; set; }

        [DynamicMaxLength]
        public string? title { get; set; }

        [DynamicMaxLength]
        public string? subTitle { get; set; }
        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime sTime { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime eTime { get; set; }


        [RegularExpression(Constants.ENGLISH_DESCRIPTION_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? chartType { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [JsonPropertyName("xAxisTagDetail")]
        public string? xAxisTagDetail { get; set; }

        [RegularExpression(Constants.ENGLISH_DESCRIPTION_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? timeParameter { get; set; }

        public bool skipModel { get; set; }

        public bool isMonitoringXY { get; set; }

        [Range(1, 100000000)]
        public int? caseID { get; set; }

        public List<string>? TagDetails { get; set; }

    }

}
