﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class CauseIdTimeInputRequest
    {
        [NotNull]
        public int causeId { get; set; }

        [AllowNull]
        public DateTime? pastDate { get; set; }
    }
}
