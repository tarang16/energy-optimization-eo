﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetVCSpanAlertRequest
    {
        public string? caseIDList { get; set; }
        public DateTime sTime { get; set; }
        public DateTime eTime { get; set; }
    }
}
