﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetErrorTrackingRepositoryLayerResponse
    {
        public int? pageCount { get; set; }
        public List<GetErrorTrackingStoredProcedureResponse>? data { get; set; }
    }
}
