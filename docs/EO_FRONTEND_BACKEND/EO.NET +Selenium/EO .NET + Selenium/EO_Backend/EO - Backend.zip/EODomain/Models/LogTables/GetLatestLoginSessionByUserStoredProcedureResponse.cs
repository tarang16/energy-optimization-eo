﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetLatestLoginSessionByUserStoredProcedureResponse
    {
        public int? userId { get; set; }
        public Guid? loginGuid { get; set; }
        public Guid? sessionGuid { get; set; }
        public string? ipAddress { get; set; }
        public string? browserName { get; set; }
        public string? browserVersion { get; set; }
        public DateTime? loginTime { get; set; }
        public DateTime? logoutTime { get; set; }
        public DateTime? startTime { get; set; }
        public DateTime? endTime { get; set; }
        public byte isOnline { get; set; }
    }
}
