﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsTrendDataByRequestIdAndTimeRangeStoredProcedureResponse
    {
        public double? causeValueActual { get; set; }
        public double? causeValueOptimum { get; set; }
        public double? gap { get; set; }
        public DateTime? timeStamp { get; set; }
        public long? timeEpoch { get; set; }
    }
}
