﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetPeOdsDetailsByOdsIdListTimeStoredProcResponse
    {
        public int? odsID { get; set; }
        public int? causeID { get;set; }
        public int? effectID { get; set; }
        public string? causeMessage { get; set; }
        public string? causeUom { get; set; }
        public string? effectMessage { get; set; }
        public string? category { get; set; }
        public string? causeValueActual { get; set; }
        public string? causeValueOptimum { get; set; }
        public string? suggestion { get; set; }
        public string? requestID { get; set; }
        public int? seuID { get; set; }
        public string? seuName { get; set; }
        public string? seuCategory { get; set; }
        public string? seuDisplayName { get; set; }
        public string? energySource { get; set; }
        public string? solution { get; set; }
        public string? plantName { get; set; }
        public string? effectAbsoluteDiff { get; set; }
        public DateTime? mutedTill { get; set; }

        public DateTime? mutedOn { get; set; }

        public string? mutedByRole { get; set; }

        public string? mutedBy { get; set; }

        public string? comment { get; set; }

        public string? reason { get; set; }

        


    }
}
