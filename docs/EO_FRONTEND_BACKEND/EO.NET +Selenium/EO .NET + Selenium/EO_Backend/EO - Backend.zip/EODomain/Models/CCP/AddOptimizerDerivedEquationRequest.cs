﻿using EODomain.Common;
using EOUtility;
using Microsoft.AspNetCore.Http.HttpResults;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class AddOptimizerDerivedEquationRequest
    {
        [Range(0, 100000000)]
        public int? derivedEquationId { get; set; }

        public int modelTagId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? formula { get; set; }
    }
}
