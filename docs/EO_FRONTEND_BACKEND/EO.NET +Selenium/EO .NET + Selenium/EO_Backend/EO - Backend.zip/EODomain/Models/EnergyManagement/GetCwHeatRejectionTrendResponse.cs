﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetCwHeatRejectionTrendResponse
    {
        public DateTime? date {  get; set; }
        public decimal? cwHeatRejection {  get; set; }
    }
}
