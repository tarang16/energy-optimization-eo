﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetPipelineMacrosByCaseIdRequest
    {
        public int? caseID { get; set; }
    }
}
