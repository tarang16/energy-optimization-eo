﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetUniquePipelineParameterByColumnNameResponse
    {
        public string? distinctValues { get; set; }
    }
}
