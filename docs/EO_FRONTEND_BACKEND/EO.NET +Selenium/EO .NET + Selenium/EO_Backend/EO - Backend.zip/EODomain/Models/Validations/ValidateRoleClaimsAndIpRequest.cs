﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValidationModels
{
    [ExcludeFromCodeCoverage]
    public class ValidateRoleClaimsAndIpRequest
    {
        public int? userID { get; set; }
        public string? tokenGuid { get; set; }
        public string? tokenIp { get; set; }
        public string? requestIp { get; set; }
        public string? tokenRole { get; set; }
    }
}
