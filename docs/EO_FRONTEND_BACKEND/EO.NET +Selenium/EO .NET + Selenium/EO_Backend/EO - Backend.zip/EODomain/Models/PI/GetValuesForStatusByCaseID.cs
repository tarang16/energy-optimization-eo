﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class GetValuesForStatusByCaseID
    {
        public Dictionary<string, string>? Links { get; set; }
        public List<ItemValuesForStatusByCaseID>? Items { get; set; }
    }
}
