﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetValueCreationSpanActionResponse
    {
        public int? vCActionID { get; set; }
        public string? actionTitle { get; set; }
        public string? actionDescription { get; set; }
        public int? potentialPeriod { get; set; }
        public byte? isActive { get; set; }
        public int? createdBy { get; set; }
        public DateTime? createdOn { get; set; }
        public int? updatedBy { get; set; }
        public DateTime? updatedOn { get; set; }
    }
}
