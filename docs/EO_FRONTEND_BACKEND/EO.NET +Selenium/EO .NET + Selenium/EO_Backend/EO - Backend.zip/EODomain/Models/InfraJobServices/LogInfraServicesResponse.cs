﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.InfraJobServices
{
    [ExcludeFromCodeCoverage]
    public class LogInfraServicesResponse
    {
        public string? ServiceUrl { get; set; }
        public string? Route { get; set; }
        public string? ServiceType { get; set; }        
        public int? ResponseCode { get; set; }
        public string? Response { get; set; }
        public string? Value { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class LogPiTagDataServicesResponse
    {
        public string? ServiceUrl { get; set; }
        public string? ServiceType { get; set; }
        public int? Case_id { get; set; }
        public string? PiTag { get; set; }
        public int? ResponseCode { get; set; }
        public string? Response { get; set; }
        public double? Value { get; set; }
        public DateTime? Timestamp { get; set; }
    }
}
