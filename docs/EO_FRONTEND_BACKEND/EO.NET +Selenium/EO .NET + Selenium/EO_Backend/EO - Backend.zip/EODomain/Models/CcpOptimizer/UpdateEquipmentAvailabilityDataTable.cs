﻿using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;

namespace EODomain.Models.CcpOptimizer
{
    [ExcludeFromCodeCoverage]
    public static class UpdateEquipmentAvailabilityDataTable
    {
        public static DataTable ConvertToDataTable<T>(this IEnumerable<T> items)
        {
            // Create a new DataTable to store the data
            DataTable dataTable = new DataTable(typeof(T).Name);

            // Get properties of the type T (the class of the object)
            PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            // Create columns for the DataTable based on the properties of the object
            foreach (var property in properties)
            {
                dataTable.Columns.Add(property.Name, Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType);
            }

            // Add rows to the DataTable
            foreach (var item in items)
            {
                var row = dataTable.NewRow();
                foreach (var property in properties)
                {
                    row[property.Name] = property.GetValue(item) ?? DBNull.Value;
                }
                dataTable.Rows.Add(row);
            }

            return dataTable;
        }
    }
}
