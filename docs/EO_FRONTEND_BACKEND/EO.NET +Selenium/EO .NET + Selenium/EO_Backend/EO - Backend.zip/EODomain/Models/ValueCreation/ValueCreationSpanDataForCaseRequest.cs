﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class ValueCreationCalcTimeSeriesRequest
    {
        [Required]
        [Range(0, 100000000)]
        public int caseID { get; set; }

        [Required]
        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? category { get; set; }

        [Required]
        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime sTime { get; set; }
        [Required]
        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime eTime { get; set; }
    }
}
