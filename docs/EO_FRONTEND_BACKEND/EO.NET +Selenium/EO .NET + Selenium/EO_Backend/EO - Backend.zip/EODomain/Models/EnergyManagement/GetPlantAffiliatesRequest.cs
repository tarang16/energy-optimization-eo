﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public  class GetPlantAffiliatesRequest
    {
        [AllowNull]
        public int? affiliateID { get; set; } = null;

        [AllowNull]
        public string? plantName { get; set; } = null;
    }
}
