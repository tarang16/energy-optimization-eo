﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class GetUserPreferencesRequest
    {
        [AllowNull]
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? key { get; set; }

        [AllowNull]
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? parameter { get; set; }
    }
}
