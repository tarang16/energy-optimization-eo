﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetStartEoWorkflowRequest
    {
        public int requestID { get; set; }
    }
}
