﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetPerformanceLogsStoredProcedureResponse
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public int? EmployeeID { get; set; }
        public string? Role { get; set; }
        public string? SessionID { get; set; }
        public string? ComponentName { get; set; }
        public string? ActionName { get; set; }
        public DateTime? StartTime { get; set; }
        public long? StartTimeEpoch { get; set; } = null;
        public DateTime? EndTime { get; set; }
        public long? EndTimeEpoch { get; set; } = null;
        public string? Duration { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? CreatedOnEpoch { get; set; } = null;
    }
}
