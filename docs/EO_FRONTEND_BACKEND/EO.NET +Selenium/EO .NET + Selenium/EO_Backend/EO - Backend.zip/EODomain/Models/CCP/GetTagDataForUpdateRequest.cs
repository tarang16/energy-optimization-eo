﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagDataForUpdateRequest
    {
        [Required]
        public int? tagID { get; set; }
    }
}
