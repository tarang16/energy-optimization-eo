﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAlertStatisticsInProgressAlertsResponse
    {
        public int alertId { get; set; }
        public string? system { get; set; }
        public string? name { get; set; }
        public string? role { get; set; }
        public DateTime inProgressSince { get; set; }
        public long inProgressSinceEpoch { get; set; }
        public long dueDateEpoch { get; set; }
        public double? cumulativeLostOpportunity { get; set; }

    }
}
