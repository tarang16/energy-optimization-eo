﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagsDataByCaseIDResponse : GetTagsDataCommon
    {
        public int? caseID { get; set; }
        public string? modelName { get; set; }
        public string? modelDescription { get; set; }
        public string? modelType { get; set; }
        public string? tagType { get; set; }
        public string? formula { get; set; }
        public string? dataType { get; set; }
    }
}
