﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class GetCalendarDataStoredProcResponse
    {
        public DateTime time { get; set; }
        public string? timeEpoch { get; set; }
        public int? status { get; set; }
    }
}
