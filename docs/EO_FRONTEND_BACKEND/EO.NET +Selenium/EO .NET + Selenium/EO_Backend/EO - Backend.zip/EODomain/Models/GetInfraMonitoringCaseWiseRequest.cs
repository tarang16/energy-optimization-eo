﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public  class GetInfraMonitoringCaseWiseRequest
    {
        public int? caseIDList { get; set; }
    }
}
