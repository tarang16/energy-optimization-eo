﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.WinAuth
{
    [ExcludeFromCodeCoverage]
    public class GetTokenRequest
    {
        public int forcedLogin { get; set; } = 0;
    }
}
