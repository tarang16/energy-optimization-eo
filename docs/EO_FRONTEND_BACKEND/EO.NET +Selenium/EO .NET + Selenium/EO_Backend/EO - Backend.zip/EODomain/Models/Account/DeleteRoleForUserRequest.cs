﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;
using EOUtility;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class DeleteRoleForUserRequest
    {
        [Range(0,1000000000)]
        public int userID { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? role { get; set; }

        [SwaggerIgnore]
        [Range(0, 1000000000)]
        public int updatedByUserID { get; set; }
    }
}
