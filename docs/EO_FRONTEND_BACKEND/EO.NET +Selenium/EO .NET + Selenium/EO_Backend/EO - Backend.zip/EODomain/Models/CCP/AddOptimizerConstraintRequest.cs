﻿using EODomain.Common;
using EOUtility;
using Microsoft.AspNetCore.Http.HttpResults;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class AddOptimizerConstraintRequest
    {
        [Range(0, 100000000)]
        public int? constraintId { get; set; }

        public int modelId { get; set; }
        
        public int constraintCategoryId { get; set; }

        public string? system { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? expression { get; set; }
    }
}
