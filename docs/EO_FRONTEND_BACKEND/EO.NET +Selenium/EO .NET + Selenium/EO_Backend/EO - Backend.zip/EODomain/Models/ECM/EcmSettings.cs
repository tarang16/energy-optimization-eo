﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class EcmSettings
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
        public string? Api { get; set; }
        public string? ApiBaseURL { get; set; }
        public string? FolderId { get; set; }
        public string? Page { get; set; }
        public string? Limit { get; set; }
    }
}
