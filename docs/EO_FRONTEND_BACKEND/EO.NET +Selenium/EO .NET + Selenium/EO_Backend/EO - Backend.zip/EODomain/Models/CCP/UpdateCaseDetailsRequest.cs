﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdateCaseDetailsRequest
    {
        public int caseID { get; set; }

        [AllowNull]
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? caseName { get; set; }

        [AllowNull]
        public int? plantID { get; set; }

        [AllowNull]
        public int? processFrequency { get; set; }

        [AllowNull]
        public int? slot { get; set; }

        [AllowNull]
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? referenceDocUrl { get; set; }

        [AllowNull]
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? description { get; set; }
    }
}
