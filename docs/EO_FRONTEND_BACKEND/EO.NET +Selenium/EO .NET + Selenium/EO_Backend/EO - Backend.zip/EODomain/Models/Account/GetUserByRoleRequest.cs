﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetUserByRoleRequest
    {
        [DynamicMaxLength]
        public string? role { get; set; }
    }
}
