﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CcpOptimizer
{
    [ExcludeFromCodeCoverage]
    public class CaseIdSeuInputRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }
    }
}
