﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;


namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class UpdateEmailListRequest
    {
        public int id { get; set; }
        [RegularExpression(Constants.EMAIL_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? toEmail { get; set; }

        [RegularExpression(Constants.EMAIL_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? fromEmail { get; set; }

        [RegularExpression(Constants.EMAIL_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? ccEmail { get; set; }
    }
}
