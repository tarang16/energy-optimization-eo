﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class GetPlantDetailsByIds
    {
        public string? plantName { get; set; }
        public string? affiliateName { get; set; }
    }
}
