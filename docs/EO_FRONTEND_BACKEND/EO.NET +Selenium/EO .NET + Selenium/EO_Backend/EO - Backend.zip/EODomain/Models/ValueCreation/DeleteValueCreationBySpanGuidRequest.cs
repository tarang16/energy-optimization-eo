﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using EOUtility;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class DeleteRequestUsingGuid
    {
        public int ID { get; set; }
        [SwaggerIgnore]
        public int userID { get; set; }
    }
}
