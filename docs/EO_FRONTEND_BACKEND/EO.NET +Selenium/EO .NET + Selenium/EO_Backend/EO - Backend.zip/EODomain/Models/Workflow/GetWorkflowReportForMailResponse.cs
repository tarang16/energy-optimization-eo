﻿
using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowReportForMailResponse
    {
        public int? plantId { get; set; }
        public int? affiliate_id { get; set; }
        public string? plant_name { get; set; }
        public string? affiliate_name { get; set; }
        public string? emailBody { get; set; }
        public string? emailSubject { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class GetCombinedWorkflowReportForMailResponse
    {
        public Guid? id { get; set; }
        public int? plantID { get; set; }
        public int? affiliate_id { get; set; }
        public string? plantName { get; set; }
        public string? affiliateName { get; set; }
        public string? emailBody { get; set; }
        public string? emailSubject { get; set; }
        public string? projectCode { get; set; }
        public string? emailTo { get; set; }
        public string? emailFrom { get; set; }
        public DateTime? lastTriggeredTime { get; set; }
        public int? minuteFrequency { get; set; }
    }
}
