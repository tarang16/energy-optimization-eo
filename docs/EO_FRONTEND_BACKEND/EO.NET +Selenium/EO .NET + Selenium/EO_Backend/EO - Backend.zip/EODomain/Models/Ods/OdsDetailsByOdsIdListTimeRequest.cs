﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class OdsDetailsByOdsIdListTimeRequest
    {
        public string? OdsIdList { get; set; }

        
        public DateTime? time { get; set; }
    }
}
