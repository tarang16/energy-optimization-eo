﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetAllAddTrnValueCreationCaseInfoDataResponse
    {

        [Range(0, 100000000)]
        public int vCCaseInfoID { get; set; }

        [Range(0, 100000000)]
        public int caseID { get; set; }


        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? objectFunction { get; set; }


        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? category { get; set; }


        [Range(0, 100000000)]
        public double? factorRealized { get; set; }

        [Range(0, 100000000)]
        public double? factorLost { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? displayName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? displayUom { get; set; }

        [Range(0, 100000000)]
        public int? isActive { get; set; }

        public int? createdBy { get; set; }
        public DateTime? createdOn { get; set; }

        public int? updatedBy { get; set; }
        public DateTime? updatedOn { get; set; }
    }
}
