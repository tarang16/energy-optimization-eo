﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetLandingCorporateResponse
    {
        public string? regionName { get; set; }
        public string? regionShortName { get; set; }
        public int affiliateCount { get; set; }
        public decimal? opportunityEnergyBills { get; set; }
        public decimal? seecGain { get; set; }
        public decimal? opportunityCo2 { get; set; }
        public List<CorporateResponseAffiliate>? affiliates { get; set; }

    }
}
