﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetQueryTrackerLogsRepositoryLayerResponse
    {
        public int? pageCount { get; set; }
        public List<GetQueryTrackerLogsStoredProcedureResponse>? data { get; set; }
    }
}
