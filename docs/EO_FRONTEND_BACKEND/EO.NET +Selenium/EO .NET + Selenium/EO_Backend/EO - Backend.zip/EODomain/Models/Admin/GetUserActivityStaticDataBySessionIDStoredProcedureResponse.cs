﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserActivityStaticDataBySessionIDStoredProcedureResponse
    {
        public int? employeeId { get; set; }
        public string? role { get; set; }
        public string? userAgent { get; set; }
        public string? browser { get; set; }
        public string? browserVersion { get; set; }
        public string? browserLanguage { get; set; }
        public DateTime? sessionStartTimeStamp { get; set; }
        public long? sessionStartTimeStampEpoch { get; set; } = null;
        public DateTime? sessionEndTimeStamp { get; set; }
        public long? sessionEndTimeStampEpoch { get; set; } = null;
        public string? ipAddress { get; set; }
        public string? applicationName { get; set; }
    }
}
