﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Network
{
    [ExcludeFromCodeCoverage]
    public class PostMstNetworkPagesRequest
    {
        public int caseid { get; set; }
        public string? pagename { get; set; }
        public int createdby { get; set; } = 1;
    }
}
