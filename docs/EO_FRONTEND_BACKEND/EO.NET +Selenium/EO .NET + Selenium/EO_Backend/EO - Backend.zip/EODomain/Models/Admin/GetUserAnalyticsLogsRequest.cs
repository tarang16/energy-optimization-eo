﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserAnalyticsLogsRequest
    {
        [AllowNull]
        public DateTime? sTime { get; set; }

        [AllowNull]
        public DateTime? eTime { get; set; }
        public byte ascOrder { get; set; } = 0;
        public int? employeeID { get; set; }

        public int pageNumber { get; set; } = 1;
        public int pageSize { get; set; } = 20;
    }
}
