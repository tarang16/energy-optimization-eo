﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Current
{
    [ExcludeFromCodeCoverage]
    public class CaseIdDateTimeApiMonitoringRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime time { get; set; }

        public string? category { get; set; }
        public string? searchField { get; set; }
        public int pageNumber { get; set; }

        public int pageSize { get; set; }
    }
}
