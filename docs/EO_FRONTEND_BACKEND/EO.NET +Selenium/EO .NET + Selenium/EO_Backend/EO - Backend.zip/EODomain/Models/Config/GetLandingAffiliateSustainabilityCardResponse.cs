﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetLandingAffiliateSustainabilityCardResponse
    {
        public int caseId { get; set; }
        public int affiliateId { get; set; }
        public int affiliateSapId { get; set; }
        public string? affiliateName { get; set; }
        public decimal? opportunityEnergyBills { get; set; }
        public decimal? seecGain{ get; set; }
        public decimal? opportunityCo2 { get; set; }
        public int active { get; set; }
    }
}
