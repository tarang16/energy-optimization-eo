﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTrnOdsSuggestionByCaseidProcedureResponse
    {
        public int? caseId { get; set; }
        public string? causeFormula { get; set; }
        public string? causeFormulaDefault { get; set; }
        public int? causeTagId { get; set; }
        public string? causeMessage { get; set; }
        public string? causeSuggestion { get; set; }
        public string? causeMessageDefault { get; set; }
        public string? causeSuggestionDefault { get; set; }
        public bool? isDefault { get; set; }
    }
}
