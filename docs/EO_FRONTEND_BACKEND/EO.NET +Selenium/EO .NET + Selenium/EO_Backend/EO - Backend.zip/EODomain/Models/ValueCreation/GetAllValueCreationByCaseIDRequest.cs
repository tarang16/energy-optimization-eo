﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetAllValueCreationByCaseIDRequest
    {
        [Range(0, 100000000)]
        public int caseID { get; set; }
    }
}
