﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class UpdateSeuDetailsRequest
    {
        public int caseID { get; set; }
        public int seuID { get; set; }
        public string? seuName { get; set; }
        public string? baselineDutyExpression { get; set; }
        public string? actualDutyExpression { get; set; }
        public string? targetDutyExpression { get; set; }
        public string? seuCategory { get; set; }
        public string? seuDisplayName { get; set; }    
        public string? baselineDutyExpressionGjph { get; set; }    
        public string? actualDutyExpressionGjph { get; set; }    
        public string? targetDutyExpressionGjph { get; set; }    


    }
}
