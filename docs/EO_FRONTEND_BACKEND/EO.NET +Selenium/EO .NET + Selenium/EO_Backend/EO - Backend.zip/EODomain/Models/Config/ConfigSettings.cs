﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class ConfigSettings
    {
        public int chunkSize { get; set; }
        public int cacheDuration { get; set; }
    }
}
