﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class CaseIdTimeRangeDayDiffRequest
    {
        [Required]
        public int? caseID { get; set; }

        [AllowNull]
        public DateTime? sTime { get; set; } = null;

        [AllowNull]
        public DateTime? eTime { get; set; } = null;

        [AllowNull]
        public int dayDiff { get; set; } = 2;
        [Range(1, 1000000)]
        public int pageNumber { get; set; } = 1;

        [Range(1, 1000000)]
        public int pageSize { get; set; } = 50;
    }
}
