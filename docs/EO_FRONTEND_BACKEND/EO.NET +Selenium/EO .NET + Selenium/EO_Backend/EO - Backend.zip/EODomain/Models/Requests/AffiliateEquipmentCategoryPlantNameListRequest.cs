﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class AffiliateEquipmentCategoryPlantNameListRequest
    {
        public string? affiliateIdList { get; set; }
        public string? equipmentcategoryList { get; set; }
        public string? plantNameList { get; set; }
    }
}
