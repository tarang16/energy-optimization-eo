﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class CaseIdTimeRangeGroupByRequest
    {
        [Required]
        public int? caseID { get; set; }
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }
        public string? groupBy { get; set; }
    }
}
