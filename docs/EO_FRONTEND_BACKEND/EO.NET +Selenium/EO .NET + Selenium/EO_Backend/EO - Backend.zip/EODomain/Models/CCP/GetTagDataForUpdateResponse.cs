﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagDataForUpdateResponse : GetTagsDataCommon
    {
        public string? type { get; set; }
        public string? formula { get; set; }
        public string? dataType { get; set; }
        public bool? active { get; set; }
    }
}
