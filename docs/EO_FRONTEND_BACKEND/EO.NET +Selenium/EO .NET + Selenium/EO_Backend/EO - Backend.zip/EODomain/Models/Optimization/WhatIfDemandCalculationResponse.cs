﻿using System.Net;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class WhatIfDemandCalculationResponse
    {
        public List<WhatIfDemandJsonResponse>? data { get; set; }
        public HttpStatusCode status { get; set; }
        public BadRequestModel? message { get; set; } = null;
        public string? url { get; set; }
    }


    [ExcludeFromCodeCoverage]
    public class BadRequestModel
    {
        public string? code { get; set; }
        public string? message { get; set; }       
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfDemandJsonResponse
    {
        [JsonProperty("tag_name")]
        public string? tagName { get; set; }

        [JsonProperty("model_tag_id")]
        public decimal modelTagId { get; set; }

        [JsonProperty("value")]
        public decimal tagValue { get; set; }
    }
}
