﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetSteamTrendResponse
    {
        public int? dateformat { get; set; }
        public decimal? steamLetDownLosses { get; set; }
        public decimal? steamVentsLosses { get; set; }
        public decimal? steamDumpedLosses { get; set; }
        public decimal? steamLossTarget { get; set; }
    }
}
