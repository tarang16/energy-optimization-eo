﻿using Azure.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Ods
{
    public class UpdatePeOdsAlertDetails
    {
        public int? requestID { get; set; }
        public string? modifiedBy { get; set; }
        public string? status { get; set; }
        public string? assignedTo { get; set; }
        public int? stageID { get; set; }
        public int? targetDate { get; set; }
        public int? actionID { get; set; }
    }
}
