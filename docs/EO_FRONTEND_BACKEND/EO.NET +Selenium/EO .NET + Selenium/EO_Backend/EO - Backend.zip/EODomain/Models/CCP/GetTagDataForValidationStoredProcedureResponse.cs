﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagDataForValidationStoredProcedureResponse
    {
        [JsonPropertyName("nameShort")]
        public string? name_short { get; set; }

        [JsonPropertyName("value")]
        public string? Value { get; set; }
    }
}
