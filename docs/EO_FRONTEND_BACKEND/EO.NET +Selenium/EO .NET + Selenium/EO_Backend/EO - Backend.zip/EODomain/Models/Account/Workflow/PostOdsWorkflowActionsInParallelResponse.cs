﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class PostOdsWorkflowActionsInParallelResponse
    {
        public List<int>? successfulRequests { get; set; }
        public List<int>? failedRequests { get; set;} 
        public List<int>? validateRequests { get; set; }
        public List<int>? sendEmailRequests { get; set; }
    }
}
