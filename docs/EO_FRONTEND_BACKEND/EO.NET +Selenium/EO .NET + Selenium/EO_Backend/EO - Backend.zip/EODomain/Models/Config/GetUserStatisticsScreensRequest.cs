﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsScreensRequest
    {
        [AllowNull]
        public string? screenName { get; set; }

        [AllowNull]
        public string? affiliateIDs { get; set; }
    }
}
