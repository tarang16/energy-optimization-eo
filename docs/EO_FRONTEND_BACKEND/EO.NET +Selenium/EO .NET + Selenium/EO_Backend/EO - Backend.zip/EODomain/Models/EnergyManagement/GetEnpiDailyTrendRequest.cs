﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetEnpiDailyTrendRequest
    {
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }

        [AllowNull]
        public int? affiliateID { get; set; }

        [AllowNull]
        public string? plantNameList { get; set; }
        public string? equipmentList { get; set; }  
        public string? equipmentCategoryList { get; set; }
        public string? groupBy { get; set; }
    }
}
