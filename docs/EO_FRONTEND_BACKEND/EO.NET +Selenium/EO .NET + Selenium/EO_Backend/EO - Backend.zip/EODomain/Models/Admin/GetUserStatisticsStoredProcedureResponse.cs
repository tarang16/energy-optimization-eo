﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsStoredProcedureResponse
    {
        public int totalActiveUsers { get; set; }
        public int totalusersonline { get; set; }
        public int avgScreenTimeInMin { get; set; }
    }
}
