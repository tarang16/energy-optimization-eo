﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class LandingSustainabiltyDurationResponse
    {
        public string? upto { get; set; }
        public List<LandingSustainabiltyAffiliate>? landingSustainabiltyAffiliates { get; set; }
    }
}
