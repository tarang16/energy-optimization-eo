﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PITags
{
    [ExcludeFromCodeCoverage]
    public class GetValuesForChildAttributes
    {
        public ContentValue? Content { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class ContentValue
    {
        public decimal Value { get; set; }
    }
}
