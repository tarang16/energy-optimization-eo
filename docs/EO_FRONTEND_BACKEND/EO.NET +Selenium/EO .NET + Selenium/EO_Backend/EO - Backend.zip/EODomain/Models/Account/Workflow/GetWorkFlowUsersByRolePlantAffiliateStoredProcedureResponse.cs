﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkFlowUsersByRolePlantAffiliateStoredProcedureResponse
    {
        public string? employeeID { get; set; } 
        public string? employeeName { get; set; }    
        public string? role { get; set;}
        public int? roleId { get; set; }
        public string? email { get; set; }
        public string? managerName { get; set; }
        public string? managerEmail { get; set; }
    }
}
