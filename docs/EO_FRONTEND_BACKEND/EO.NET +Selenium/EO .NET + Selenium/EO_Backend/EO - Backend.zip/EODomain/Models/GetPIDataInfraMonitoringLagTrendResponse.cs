﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class GetPIDataInfraMonitoringLagTrendResponse
    {
        public int? caseID { get; set; }
        public int? infraId { get; set; }
        public string? piTag { get; set; }
        public int? responseCode { get; set; }
        public string? response { get; set; }
        public double? value { get; set; }
        public DateTime? timeStampUTC { get; set; }
        public DateTime? createdOn { get; set; }
        public long? timestampEpoch { get; set; }
        public long? createdOnEpoch { get; set; }
        public int? diffInMinute { get; set; }
        public int? affiliateId { get; set; }
        public string? affiliateName { get; set; }
        public string? affiliateSapId { get; set; }
        public string? systemName { get; set; }       
    }    
}
