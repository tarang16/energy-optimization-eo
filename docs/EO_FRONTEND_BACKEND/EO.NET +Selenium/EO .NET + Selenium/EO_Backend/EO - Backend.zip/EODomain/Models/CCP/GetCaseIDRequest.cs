﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetCaseIDRequest
    {
        [Range(0, 99999, ErrorMessage = "Invalid format")]
        public int caseID { get; set; }
        public string? searchField { get; set; }
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
    }
}
