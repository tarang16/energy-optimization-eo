﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAssigneeListStoredProcedureResponse
    {
        public string? employeeId { get; set; }
		public string? name { get; set; }
        public string? email { get; set; }
        public string? role { get; set; }
        public int? stageId { get; set; }
    }
}
