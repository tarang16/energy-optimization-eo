﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class ActivityTrackerRequest
    {
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? ApplicationName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? ScreenName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? FunctionalityName { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? UserActionName { get; set; }

        [Range(0, 1)]
        public int IsOnline { get; set; }

        [AllowNull]
        public int? AffiliateID { get; set; }

        [AllowNull]
        public int? CaseID { get; set; }
    }
}
