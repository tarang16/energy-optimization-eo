﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetCWSpecificCostTrendRequest
    {
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }
        public int affiliateID { get; set; }
        public string? plantName { get; set; }
    }
}
