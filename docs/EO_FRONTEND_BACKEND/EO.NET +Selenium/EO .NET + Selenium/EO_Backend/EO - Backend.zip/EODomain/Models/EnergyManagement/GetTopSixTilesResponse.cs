﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetTopSixTilesResponse
    {
        public decimal? energyConsumedElectricity { get; set; }
        public decimal? energyConsumedFuel { get; set; }
        public decimal? energyConsumedSteam { get; set; }        
        public decimal? totalPurchasedEnergyConsumption { get; set; }
        public decimal? energyConsumptionTarget { get; set; }
        public decimal? energyCostIndex { get; set; }
        public decimal? energyCostIndexTarget { get; set; }
        public decimal? seuEnpiNet { get; set; }
        public decimal? improvementPotential { get; set; }
        public decimal? opportunity { get; set; }
        public decimal? airSystemPerformance { get; set; }
        public decimal? airSystemPerformanceGj { get; set; }
        public decimal? motorsEnpiDollar { get; set; }
        public decimal? turbinesENPIDollar { get; set; }
        public decimal? motorsConsumptionGJ { get; set; }
        public decimal? turbineConsumptionGJ { get; set; }
        public decimal? airTargetDollar { get; set; }
        public decimal? airTargetGJ { get; set; }
        public decimal? coolingWaterPerformance { get; set; }
        public decimal? coolingWaterTarget { get; set; }
        public decimal? coolingWaterLoad { get; set; }
        public decimal? cwENPI { get; set; }
        public decimal? cwCost { get; set; }
        public decimal? cwEnergy { get; set; }
        public decimal? steamSystemLosses { get; set; }
        public decimal? steamSystemLossesGJ { get; set; }
        public decimal? steamLetDownDollar { get; set; }
        public decimal? steamVentsDollar { get; set; }
        public decimal? steamDumpedDollar { get; set; }
        public decimal? steamLetDownGJ { get; set; }
        public decimal? steamVentGJ { get; set; }
        public decimal? steamDumpedGJ { get; set; }
        public decimal? steamLossTargetDollar { get; set; }
        public decimal? steamLossTargetGJ { get; set; }
    }
}
