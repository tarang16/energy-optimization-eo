﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class LogApiPerformanceLogs
    {
        public string? Createdby { get; set; }
        public string? EndPointName { get; set; }
        public string? ElapsedTime { get; set; }
        public string? customMessage { get; set; }
        public string? RoleID { get; set; }
        public string? SessionID { get; set; }
        public int? LayerID { get; set; }
        public string? HttpMethod { get; set; }
        public int? StatusCode { get; set; }
        public string? RequestBody { get; set; }
        public DateTime? RequestTimeStamp { get; set; }
        public string? ResponseBody { get; set; }
        public DateTime? ResponseTimeStamp { get; set; }
        public string? LayerName { get; set; }
    }
}
