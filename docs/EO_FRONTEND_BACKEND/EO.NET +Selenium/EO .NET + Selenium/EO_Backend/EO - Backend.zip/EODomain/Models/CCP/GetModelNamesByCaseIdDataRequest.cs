﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]

    public class GetModelNamesByCaseIdDataRequest
    {
        public int caseID { get; set; }
    }
}
