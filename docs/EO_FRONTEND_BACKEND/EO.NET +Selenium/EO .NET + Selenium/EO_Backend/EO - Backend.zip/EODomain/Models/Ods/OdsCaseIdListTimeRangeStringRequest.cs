﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class OdsCaseIdListTimeRangeStringRequest
    {
        [Required]
        public string? caseIDList { get; set; }

        [AllowNull]
        public string? sTime { get; set; } = null;

        [AllowNull]
        public string? eTime { get; set; } = null;
    }
}
