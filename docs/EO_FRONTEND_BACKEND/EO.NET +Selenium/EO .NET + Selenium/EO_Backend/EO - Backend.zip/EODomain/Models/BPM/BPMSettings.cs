﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.BPM
{
    [ExcludeFromCodeCoverage]
    public class BpmSettings
    {
        public string? URL { get; set; }
    }
}
