﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    public class GetWorkflowConfigurationsRequest
    {
        [AllowNull]
        public int? affiliateID { get; set; } = null;
    }
}
