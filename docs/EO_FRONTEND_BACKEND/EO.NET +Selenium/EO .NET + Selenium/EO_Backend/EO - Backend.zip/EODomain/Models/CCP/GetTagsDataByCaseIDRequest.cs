﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagsDataByCaseIDRequest
    {
        public int caseId { get; set; }

        public string? searchField { get; set; }
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
    }
}
