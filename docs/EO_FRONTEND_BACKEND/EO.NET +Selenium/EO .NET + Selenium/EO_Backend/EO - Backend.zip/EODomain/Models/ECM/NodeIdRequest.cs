﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class NodeIdRequest
    {
        public int nodeId { get; set; }
    }
}
