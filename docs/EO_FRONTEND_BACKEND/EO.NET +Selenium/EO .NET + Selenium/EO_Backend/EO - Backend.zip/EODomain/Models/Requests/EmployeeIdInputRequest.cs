﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.RequestModels
{
    [ExcludeFromCodeCoverage]
    public class EmployeeIdInputRequest
    {
        public string? employeeID { get; set; }
    }
}
