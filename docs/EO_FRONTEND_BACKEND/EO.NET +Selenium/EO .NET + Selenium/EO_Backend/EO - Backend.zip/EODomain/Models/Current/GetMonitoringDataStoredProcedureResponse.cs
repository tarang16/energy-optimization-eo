﻿
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Current
{
    [ExcludeFromCodeCoverage]
    public class GetMonitoringDataStoredProcedureResponse
    {
        public string? category { get; set; }
        public string? tagName { get; set; }
        public string? tagNameAlias { get; set; }
        public string? parameter { get; set; }
        public string? uom { get; set; }
        public int? sortID { get; set; }
        public double? design { get; set; }
        public double? optimum { get; set; }
        public double? actual { get; set; }
        public int? state { get; set; }
        public string? displayFormula { get; set; }
        public string? displayDescription { get; set; }
        public int? valueDecimal { get; set; }
        public int? tagID { get; set; }
        public string? piName { get; set; }

    }
}
