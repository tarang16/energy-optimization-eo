﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkflowUserRoleByUserId
    {
        public string? roleName { get; set; }
        public int? roleId { get; set; }
        public int? affiliateId { get; set; }
    }
}
