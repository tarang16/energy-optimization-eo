﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Search
{
    [ExcludeFromCodeCoverage]
    public class PaginatedSearch
    {
        public Dictionary<string, object>? searchKey { get; set; }
        public int pageNumber { get; set; } = 1;
        public int pageSize { get; set; } = 20;
        public int commandTime { get; set; } = 30;
        public string? query { get; set; }

     
    }
}
