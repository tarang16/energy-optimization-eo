﻿using EOUtility;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class UpdateMuteAlertsLogByCauseId
    {
        [AllowNull]
        public string? CauseIdList { get; set; }

        [SwaggerIgnore]
        public int? updatedBy { get; set; }
    }
}
