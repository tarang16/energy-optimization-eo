﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public  class GetWhatIfPlantParametersRequest
    {
        public int caseID { get; set; }
        public DateTime timeStamp { get; set; }
    }
}
