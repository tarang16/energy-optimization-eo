﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class ModifyErrorStatusByErrorIDRequest
    {
        [RegularExpression(Constants.ENGLISH_DESCRIPTION_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? errorID { get; set; }
            
        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? status { get; set; }

        [RegularExpression(Constants.ENGLISH_ARABIC_DESCRIPTION_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? assignedTo { get; set; }
    }
}
