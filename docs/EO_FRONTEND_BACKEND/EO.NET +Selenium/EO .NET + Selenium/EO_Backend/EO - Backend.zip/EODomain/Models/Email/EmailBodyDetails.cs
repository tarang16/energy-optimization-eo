﻿using Newtonsoft.Json;
using System.Net.Mail;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class EmailBodyDetails
    {
        [JsonProperty("sendEmailNotificationInput")]
        public SendEmailNotificationInput? SendEmailNotificationInput { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class SendEmailNotificationInput
    {
        [JsonIgnore]
        public int? Id { get; set; }
        [JsonIgnore]
        public int? PlantID { get; set; }
        public int? AffliateID { get; set; }
        [JsonIgnore]
        public string? Plant_name { get; set; }
        [JsonIgnore]
        public string? Affiliate_name { get; set; }

        [JsonProperty("emailSubject")]
        public string? EmailSubject { get; set; }

        [JsonProperty("emailBody")]
        public string? EmailBody { get; set; }

        [JsonProperty("fromEmail")]
        public string? FromEmail { get; set; }

        [JsonProperty("toEmail")]
        public string? ToEmail { get; set; }

        [JsonProperty("ccEmail")]
        public string? CcEmail { get; set; }

        [JsonProperty("projectCode")]
        public string? ProjectCode { get; set; }

        [JsonIgnore]
        public DateTime? LastTriggeredTime { get; set; }

        [JsonIgnore]
        public int? MinuteFrequency { get; set; }
        [JsonIgnore]
        public int? CreatedBy { get; set; }
        [JsonIgnore]
        public int? UpdatedBy { get; set; }

        [JsonProperty(nameof(Attachment))]
        public Attachment? Attachment { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Attachment
    {
     
        [JsonProperty(nameof(attachmentFileName))]
        public string? attachmentFileName { get; set; }
        [JsonProperty(nameof(attachmentBody))]
        public string? attachmentBody { get; set; }
        [JsonProperty(nameof(attachmentContentType))]
        public string? attachmentContentType { get; set; }
    }
}
