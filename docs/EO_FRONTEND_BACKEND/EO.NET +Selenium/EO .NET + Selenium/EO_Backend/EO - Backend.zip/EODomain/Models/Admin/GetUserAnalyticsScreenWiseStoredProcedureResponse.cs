﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserAnalyticsScreenWiseStoredProcedureResponse
    {
        public List<ScreenNameWiseAccess>? screenWiseAccess {  get; set; }    
        public List<DayWiseScreenAccess>? dayWiseScreenAccess {  get; set; }

    }

    [ExcludeFromCodeCoverage]
    public class ScreenNameWiseAccess
    {
        public string? screenName { get; set; }
        public int screenAccessedTimeInSec { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class DayWiseScreenAccess
    {
        public string? dayWise { get; set; }
        public long? dayWiseEpoch { get; set; }
        public int screenAccessedTimeInSec { get; set; }
    }


}
