﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserStatisticsGraphDataCombinedResponse
    {
        public List<GetUserStatisticsGraphDataStoredProcedureResponse>? timeWiseData {  get; set; }  
        public List<GetUserStatisticsGraphDataDistinctUsersStoredProcedureResponse>? distinctUsersData { get; set; }    

    }
}
