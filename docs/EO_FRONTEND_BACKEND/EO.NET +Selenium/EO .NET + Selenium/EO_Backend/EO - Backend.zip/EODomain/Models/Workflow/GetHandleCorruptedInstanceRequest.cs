﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetHandleCorruptedInstanceRequest
    {
        public string? processInstanceID { get; set; }
        public string? assignedBy { get; set; }
    }
}
