﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class OdsCheckSendEmailRequest
    {
        public int? requestId { get; set; }
        public int? affiliateId { get; set; }
    }
}
