﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class RequestIdInputRequest
    {
        [Range(0, 1000000000)]
        public int requestId { get; set; }

        public bool connectionFlag { get; set; }
    }
}
