﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class UpdateWorkflowConfigurationsRequest
    {
        public List<WorkflowConfigurationType>? WorkflowConfigurationType { get; set; }

        public int? updatedBy { get; set; }
        public int? affiliateId { get; set; }

        public int? createdBy { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WorkflowConfigurationType
    { 
         public string? configurationName { get; set; }
        public string? configurationValue { get; set; }

    }
}
