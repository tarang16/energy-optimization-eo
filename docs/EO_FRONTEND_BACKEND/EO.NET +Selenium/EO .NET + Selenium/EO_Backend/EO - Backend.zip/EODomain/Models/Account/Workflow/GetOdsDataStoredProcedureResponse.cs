﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetOdsDataStoredProcedureResponse
    {
        public int odsCauseTagId { get; set; }
        public string? plant { get; set; }
        public string? system { get; set; }
        public string? causeUom { get; set; }
        public string? affiliate { get; set; }
        public string? effectUom { get; set; }
        public string? suggestion { get; set; }
        public string? causeMessage { get; set; }
        public string? effectMessage { get; set; }
        public string? odsCauseTagName { get; set; }
        public string? odsEffectTagName { get; set; }
        public long? targetDate { get; set; }
        public long? deviationTimeEpoch { get; set; }
        public long? lastOccuranceTimeEpoch { get; set; }
        public double? causeValueActual { get; set; }
        public double? causeValueOptimum { get; set; }
        public double? effectValueActual { get; set; }
        public double? effectValueOptimum { get; set; }
        public int bpmInitiated { get; set; }
        public long? bpmSubmissionTimeEpoch { get; set; }
        public int stageId { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
        public int? processOperationRejection {get;set;}

    }
}
