﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.PI
{
    [ExcludeFromCodeCoverage]
    public class GetChildAttributesForTags
    {
        public AttributeContent? Content { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class AttributeContent
    {
        public List<AttributeItem>? Items { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class AttributeItem
    {
        public string? WebId { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
    }
}
