﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class UpdateWorkflowPmDelegationInfoRequest
    {
        public int? affiliateId { get; set; }
        [AllowNull]
        public string? assignedTo { get; set; } = null;
        
       
        [AllowNull]
        public DateTime? immediateAutoDelegateTill { get; set; } = null!;
        public int isActive { get; set; }
        public string? actionBy { get; set; }
    }
}
