﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class AdmUserLoginInsert
    {
        public int UserID {get; set;}
        public string? IpAddress { get; set; }
        public string? BrowserName { get; set; }
        public string? ServerIp {get; set;}
        public string? UserAgent { get; set; }
        public string? BrowserVersion { get; set; }
        public string? BrowserLanguage { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
    }
}
