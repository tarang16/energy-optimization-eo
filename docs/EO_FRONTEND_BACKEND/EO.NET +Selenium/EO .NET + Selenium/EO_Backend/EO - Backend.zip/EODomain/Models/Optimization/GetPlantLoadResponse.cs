﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class GetPlantLoadResponse
    {
        public dynamic? plantData { get; set; }
        public dynamic? processData { get; set; }
    }
}
