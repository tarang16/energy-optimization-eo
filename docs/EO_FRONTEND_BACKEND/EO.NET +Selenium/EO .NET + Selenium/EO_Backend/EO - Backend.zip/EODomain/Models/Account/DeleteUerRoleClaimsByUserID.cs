﻿using EODomain.Common;
using EOUtility;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class DeleteUerRoleClaimsByUserID
    {
        [Range(0, 1000000000)]
        public int userID { get; set; }

        [SwaggerIgnore]
        [Range(0, 1000000000)]
        public int updatedByUserID { get; set; }
    }
}
