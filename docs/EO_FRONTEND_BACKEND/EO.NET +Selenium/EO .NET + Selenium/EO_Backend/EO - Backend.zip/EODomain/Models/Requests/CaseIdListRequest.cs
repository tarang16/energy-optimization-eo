﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class CaseIdListRequest
    {
        public string? caseIdList {  get; set; }
    }
}
