﻿using System.Diagnostics.CodeAnalysis;


namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class NullableCaseIdRequest
    {
        [AllowNull]
        public int? caseID { get; set; }
    }
}
