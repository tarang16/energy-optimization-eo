﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class WorkflowConfigurations
    {
        public string? configurationName { get; set; }
        public string? configurationValue { get; set; }
    }
}
