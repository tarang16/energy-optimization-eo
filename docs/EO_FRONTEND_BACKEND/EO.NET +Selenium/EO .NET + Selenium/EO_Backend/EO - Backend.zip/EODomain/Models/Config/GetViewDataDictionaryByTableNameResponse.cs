﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetViewDataDictionaryByTableNameResponse
    {
        public string? tableName { get; set; }
        public string? columnName { get; set; }
        public string? description { get; set; }
        public string? expectedOutputFormatExample { get; set; }
        public string? dataTypeName { get; set; }
        public int? maxLength { get; set; }
        public bool? isNullable { get; set; }
        public string? constraintName { get; set; }
        public string? constraintType { get; set; }
        public string? indexName { get; set; }
        public string? typeDesc { get; set; }
        public bool? isUnique { get; set; }
    }
}
