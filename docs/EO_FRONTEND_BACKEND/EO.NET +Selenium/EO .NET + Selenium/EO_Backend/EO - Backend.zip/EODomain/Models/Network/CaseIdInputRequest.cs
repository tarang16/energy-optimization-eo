﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Network
{
    [ExcludeFromCodeCoverage]
    public class CaseIdInputRequest
    {

        [Range(0, 1000000000)]
        public int caseID { get; set; }
    }
}
