﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class AffiliatePlantEquipmentAndCategoryTimeRangeRequest
    {
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }

        [AllowNull]
        public int? affiliateID { get; set; }

        [AllowNull]
        public string? plantNameList { get; set; }

        [AllowNull]
        public string? equipment { get; set; }

        [AllowNull]
        public string? equipmentCategory { get; set; }

        [AllowNull]
        public string? groupby { get; set; } = "date";
    }
}
