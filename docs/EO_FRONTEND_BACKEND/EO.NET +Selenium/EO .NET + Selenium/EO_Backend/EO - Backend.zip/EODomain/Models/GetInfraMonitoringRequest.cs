﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public  class GetInfraMonitoringRequest
    {
        public string? serviceType { get; set; }
        public DateTime? stime {get; set;}
        public DateTime? etime { get; set; }
    }
}
