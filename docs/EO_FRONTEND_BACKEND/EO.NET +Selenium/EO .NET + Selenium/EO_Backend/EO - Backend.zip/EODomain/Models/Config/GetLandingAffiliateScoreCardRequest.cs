﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetLandingAffiliateScoreCardRequest
    {
        public int affiliateID { get; set; }
        public string? upto { get; set; }
    }
}
