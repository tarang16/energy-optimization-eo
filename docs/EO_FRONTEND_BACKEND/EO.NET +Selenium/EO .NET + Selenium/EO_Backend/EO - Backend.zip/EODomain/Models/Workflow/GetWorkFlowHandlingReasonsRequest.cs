﻿
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class GetWorkFlowHandlingReasonsRequest
    {
        public int? roleID { get; set; }
    }
}
