﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class UploadToEcmResponse
    {
        public string? Id { get; set; }
        public string? Message { get; set; }
    }
}
