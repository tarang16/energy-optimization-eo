﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class GetInfraMonitoringCaseWiseTrendResponse
    {
        public int? caseID { get; set; }
        public string? plantName { get; set; }
        public int? affiliateId { get; set; }
        public string? affiliateName { get; set; }
        public int? affiliateSapId { get; set; }
        public string? systemName { get; set; }
        public DateTime? lastruntime { get; set; }
        public long? lastruntimeEpoch { get; set; }
        public int? infraID { get; set; }
        public string? piTag { get; set; }
        public int? responseCode { get; set; }
        public string? response { get; set; }
        public decimal? value { get; set; }
        public DateTime? timeStampUTC { get; set; }
        public DateTime? createdOn { get; set; }
        public long? timeStampEpoch { get; set; }
        public long? createdOnEpoch { get; set; }
        public int? diffInMinute { get; set; }
    }
}
