﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class CaseIdListTimeRangeStringRequest
    {
        [Required]
        public string? caseIDList { get; set; }

        [AllowNull]
        public DateTime? sTime { get; set; } = null;

        [AllowNull]
        public DateTime? eTime { get; set; } = null;
    }
}
