﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.HistoricalData
{
    [ExcludeFromCodeCoverage]
    public class GetDataModelSkipServiceLayerPaginatedResponse
    {
        public List<GetDataModelSkipServiceLayerResponse>? data { get; set; }
        public int pageCount { get; set; }
    }
}
