﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Network
{
    [ExcludeFromCodeCoverage]
    public class GetMstNetworkPagesRequest
    {
        public int caseId { get; set; }
    }
}
