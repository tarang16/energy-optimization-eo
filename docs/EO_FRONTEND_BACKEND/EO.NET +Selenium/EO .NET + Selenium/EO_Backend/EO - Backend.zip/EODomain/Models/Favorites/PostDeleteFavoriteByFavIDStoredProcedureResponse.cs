﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class PostDeleteFavoriteByFavIDStoredProcedureResponse
    {
        public int ID { get; set; }
        public int isActive { get; set; }  
        public string? token { get; set; }
    }
}
