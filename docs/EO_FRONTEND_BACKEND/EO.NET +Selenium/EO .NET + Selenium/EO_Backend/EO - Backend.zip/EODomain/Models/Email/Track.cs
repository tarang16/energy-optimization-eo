﻿using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Email
{
    [ExcludeFromCodeCoverage]
    public class Track
    {
        [JsonProperty(nameof(track))]
        public int? track { get; set; }
        [JsonProperty(nameof(query))]
        public string? query { get; set; }
        [JsonProperty(nameof(totalRecords))]
        public string? totalRecords { get; set; }
        [JsonProperty(nameof(totalTime))]
        public TimeSpan totalTime { get; set; }

        [JsonProperty(nameof(user))]
        public int? user { get; set; }
        [JsonProperty(nameof(createdDate))]
        public DateTime createdDate { get; set; }
        [JsonProperty(nameof(webServer))]
        public string? webServer { get; set; }
        [JsonProperty(nameof(actionUrl))]
        public string? actionUrl { get; set; }
        [JsonProperty(nameof(errorMessage))]
        public string? errorMessage { get; set; }

    }
}
