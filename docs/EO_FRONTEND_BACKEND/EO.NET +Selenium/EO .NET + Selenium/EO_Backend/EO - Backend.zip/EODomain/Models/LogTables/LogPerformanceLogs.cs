﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class LogPerformanceLogs : UpsertLogPerformanceLogs
    {
        public string? SessionID { get; set; }
        public string? RoleID { get; set; }
        public string? Duration { get; set; }
        public int? CreatedBY { get; set; }
        public string? CreatedOn { get; set; }
        public int? UpdatedBY { get; set; }
        public string? UpdatedOn { get; set; }
    }
}
