﻿using EOUtility;
using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class DeleteWorkflowUserRoleRequest
    {
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        [Required]

        public string? userId { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        [AllowNull]
        public string? role { get; set; }

        [AllowNull]
        [Range(0,10000)]
        public int? affiliateId { get; set; }

        [Range(0, 100000000)]
        [SwaggerIgnore]
        public string? updatedBy { get; set; }
    }
}
