﻿
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagsDataFlags
    {
        public bool? flagMA { get; set; }
        public bool? flagClean { get; set; }
        public bool? flagActual { get; set; }
        public bool? flagMAFilter { get; set; }
        public bool? flagBenchmark { get; set; }
        public string? designValue { get; set; }
        public bool? flagInputCheckNan { get; set; }
        public bool? flagDataCleanFilter { get; set; }
        public bool? flagActualRunAlways { get; set; }
    }
}
