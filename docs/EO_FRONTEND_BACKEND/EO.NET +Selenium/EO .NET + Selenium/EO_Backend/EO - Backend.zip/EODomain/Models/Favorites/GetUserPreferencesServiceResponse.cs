﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class GetUserPreferencesServiceResponse
    {
        public int id { get; set; }
        public object? preferences { get; set; }
    }
}
