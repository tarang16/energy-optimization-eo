﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class CaseIdInputRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }
    }
}
