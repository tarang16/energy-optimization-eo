﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class OdsCaseIdListRequest
    {
        public DateTime? fromDate { get; set; }
        public string? caseIdList {  get; set; }
    }
}
