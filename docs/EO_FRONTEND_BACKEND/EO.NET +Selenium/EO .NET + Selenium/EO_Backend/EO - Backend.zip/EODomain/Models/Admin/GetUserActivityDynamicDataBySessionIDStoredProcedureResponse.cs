﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserActivityDynamicDataBySessionIDStoredProcedureResponse
    { 

        public string? plant { get; set; } = string.Empty;
        public long? createdOnEpoch { get; set; } = null;
        public string? system { get; set; } = string.Empty;
        public string? affiliate { get; set; } = string.Empty;
        public string? clientIpAdress { get; set; }
        public long? updatedOnEpoch { get; set; } = null;
        public string? screenName { get; set; }
        public string? actionName { get; set; }
        public DateTime? updatedOn { get; set; }
        public int? updatedBy { get; set; }
        public DateTime? createdOn { get; set; }
        public string? functionality { get; set; }
    }
}
