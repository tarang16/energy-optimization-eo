﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsDataForPlantByCaseIDListTimeRangeApiResponse
    {
        public string? kpi { get; set; }
        public string? category { get; set; }
        public string? systemName { get; set; }
        public long? sTimeEpoch { get; set; }
        public long? eTimeEpoch { get; set; }
        public List<OdsCauses>? causes {get; set;} 
    }

    [ExcludeFromCodeCoverage]
    public class OdsCauses
    {
        public int? requestId { get; set; }
        public double? actual { get; set; }
        public double? optimum { get; set; }
        public string? suggestion { get; set; }
        public string? causeMessage { get; set; }
        public string? status { get; set; }
        public string? currentAssignee { get; set; }
        public string? deviationStatus { get; set; }
        public string? actionUrl { get; set; }
        public DateTime? dueDate { get; set; }
        public long? dueDateEpoch { get; set; }
        public DateTime? lastOccurence { get; set; }
        public DateTime? deviationTimestamp { get; set; }
        public string? lastActionTakenBy { get; set; }
        public string? comments { get; set; }
        public long? deviationTimestampEpoch { get; set; }
        public long? lastOccurenceEpoch { get; set; }
        public double? cumulativeLostOpportunity { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class OdsTimeSeries
    {
        public long? tEpoch { get; set; }
        public double? a { get; set; }
        public double? o { get; set; }
        public double? g { get; set; }
        public DateTime? tStamp { get; set; }
    }

}
