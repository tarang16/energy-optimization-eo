﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTagDataForCcpAndPIByModelIDStoredProcedureResponse
    {
        public int tagID { get; set; }
        public string? nameShort { get; set; }
        public string? fullName { get; set; }
        public string? uom { get; set; }
        public string? description { get; set; }
        public string? piName { get; set; }
        public string? type { get; set; }
        public string? elementName { get; set; }
        public float? max { get; set; }
        public float? refMax { get; set; }
        public float? refMin { get; set; }
        public float? min { get; set; }
        public int? defaultSwitch { get; set; }
        public int? defaultValue { get; set; }
        public int? tagOutOfBoundSwitch { get; set; }
        public int? tagStuckSwitch { get; set; }
        public int? tagBoundAtLimitsSwitch { get; set; }
        public int? piAfTag { get; set; }
    }
   }
