﻿using EODomain.Models.Email;
using EOUtility;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EODomain.Models.Optimization
{
    [ExcludeFromCodeCoverage]
    public class WhatIfDemandCalculationModel
    {
        [JsonProperty(nameof(modelTagId))]
        public int modelTagId { get; set; }

        [JsonProperty(nameof(value))]
        public decimal value { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfDemandCalculationRequest
    {
    
        [JsonProperty(nameof(data))]
        public List<WhatIfDemandCalculationModel>? data { get; set; }

        [Range(0, 1000000000)]
        public int caseID { get; set; }

        public int modelID { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime time { get; set; }
        public string? scenarioName { get; set; }

        [SwaggerIgnore]
        public int userID { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfDemandCalculationRMModel
    {
        [JsonProperty(nameof(model_tag_id))]
        public int model_tag_id { get; set; }

        [JsonProperty(nameof(value))]
        public decimal value { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class WhatIfDemandCalculationRMRequest
    {
       
        [JsonProperty(nameof(data))]
        public List<WhatIfDemandCalculationRMModel>? data { get; set; }

        [Range(0, 1000000000)]
        public int caseID { get; set; }

        public int modelID { get; set; }

        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime time { get; set; }
        public string? scenarioName { get; set; }

        [SwaggerIgnore]
        public int userID { get; set; }
    }
}
