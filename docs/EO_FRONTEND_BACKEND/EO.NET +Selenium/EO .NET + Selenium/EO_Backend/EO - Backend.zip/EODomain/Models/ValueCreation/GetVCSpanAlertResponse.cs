﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetVCSpanAlertResponse
    {
        public int? caseID { get; set; }
        public int? odsCauseTagID { get; set; }
        public string? odsCauseTagName { get; set; }
        public string? causeMessage { get; set; }
        public string? category { get; set; }
        public string? odsEffectTagName { get; set; }
        public string? effectMessage { get; set; }
        public string? causeUom { get; set; }
        public string? suggestion { get; set; }
        public string? systemName { get; set; }
        public int? occurrence { get; set; }
    }
}
