﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetViewDataDictionaryByTableNameRequest
    {
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? TableNameList { get; set; }
    }
}
