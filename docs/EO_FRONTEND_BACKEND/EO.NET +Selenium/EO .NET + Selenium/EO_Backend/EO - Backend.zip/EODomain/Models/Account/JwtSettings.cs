﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class JwtSettings
    {
        public string? Key { get; set; }
        public string? Issuer { get; set; }
        public string? Audience { get; set; }
        public double DurationInMinutes { get; set; }
        public string? AesKey { get; set; }
    }
}
