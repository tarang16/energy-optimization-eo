﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ECM
{
    
   [ExcludeFromCodeCoverage]
    public class GetWalkthroughDataByPagekeyGrpEcmResponse
    {
        public string? pageKey { get; set; }
        public List<PageKeyEcmDetails>? pageKeyDetails { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class PageKeyEcmDetails
    {
        public string? tutID { get; set; }
        public string? title { get; set; }
        public string? staticId { get; set; }
        public string? subText { get; set; }
        public long? imageNodeID { get; set; }
        public long? audioNodeID { get; set; }
        public string? audioFileName { get; set; }
        public string? imageFileName { get; set; }
        public int? sortkey { get; set; }
    }
}
