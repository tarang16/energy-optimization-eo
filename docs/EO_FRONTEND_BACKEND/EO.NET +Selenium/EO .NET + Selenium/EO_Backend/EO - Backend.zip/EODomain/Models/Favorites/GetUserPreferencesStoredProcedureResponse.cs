﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class GetUserPreferencesStoredProcedureResponse
    {
        public int id { get; set; }
        public string? preferences { get; set; }
    }
}
