﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class GetReconciledEnergyRequest
    {
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }

        [AllowNull]
        public int? affiliateID { get; set; } = null;
    }
}
