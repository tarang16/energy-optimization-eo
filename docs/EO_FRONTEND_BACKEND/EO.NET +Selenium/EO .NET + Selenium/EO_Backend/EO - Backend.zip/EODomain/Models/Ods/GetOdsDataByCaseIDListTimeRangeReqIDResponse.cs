﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsDataByCaseIDListTimeRangeReqIDResponse
    {
        public int? odsId { get; set; }
        public int? caseId { get; set; }
        public int? requestId { get; set; }
        public string? affiliate { get; set; }
        public string? system { get; set; }
        public string? currentAssignee { get; set; }
        public int? odsCauseTagId { get; set; }
        public string? odsCauseTagName { get; set; }
        public string? causeMessage { get; set; }
        public string? category { get; set; }
        public string? effactCauseTagName { get; set; }
        public string? effectMessage { get; set; }
        public double? causeValueActual { get; set; }
        public double? causeValueOptimum { get; set; }
        public string? causeUom { get; set; }
        public string? suggestion { get; set; }
        public double? gap { get; set; }
        public DateTime? timeStamp { get; set; }
        public long? timeEpoch { get; set; }
        public long? dueDateEpoch { get; set; }
        public DateTime? dueDate { get; set; }
        public DateTime? deviationTimestamp { get; set; }
        public DateTime? lastOccurencetime { get; set; }
        public long? deviationTimestampEpoch { get; set; }
        public long? lastOccurencetimeEpoch { get; set; }
        public string? deviationStatus { get; set; }
        public int? stageId { get; set; }
        public string? stageName { get; set; }
        public string? actionUrl { get; set; }
        public string? lastActionTakenBy { get; set; }
        public string? comments { get; set; }
        public long? sTimeEpoch { get; set; }
        public long? eTimeEpoch { get; set; }
        public double? cumulativeLostOpportunity { get; set; }        
    }
}


