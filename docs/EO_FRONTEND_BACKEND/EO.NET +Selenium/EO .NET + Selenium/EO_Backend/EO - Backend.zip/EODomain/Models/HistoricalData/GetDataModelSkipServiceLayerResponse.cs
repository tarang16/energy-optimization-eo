﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.HistoricalData
{
    [ExcludeFromCodeCoverage]
    public class GetDataModelSkipServiceLayerResponse
    {
        public DateTime? timeStamp { get; set; }
        public long timeEpoch { get; set; }
        public string? status { get; set; }
        public List<Model>? models { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class Model
    {
        public int modelID { get; set; }
        public string? modelName { get; set; }
        public string? status { get; set; }
        public List<TagDetail>? details { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class TagDetail
    {
        public int? tagID { get; set; }
        public string? piName { get; set; }
        public string? tagName { get; set; }
        public string? uiDisplayName { get; set; }
        public string? tagType { get; set; }
        public string? status { get; set; }
        public string? rawValue { get; set; }
        public string? actual { get; set; }
        public string? current { get; set; }
        public string? min { get; set; }
        public string? max { get; set; }
        public string? logic { get; set; }
        public string? description { get; set; }
    }
}
