﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public class GetUserActivityDataBySessionIDRequest
    {

         [Range(0, 99999, ErrorMessage = "Invalid format")]
       
        public int pageNumber { get; set; }

        [Range(0, 99999, ErrorMessage = "Invalid format")]
        public int pageSize { get; set; }

        [RegularExpression(Constants.ENGLISH_DESCRIPTION_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? sessionId { get; set; }
    }
}