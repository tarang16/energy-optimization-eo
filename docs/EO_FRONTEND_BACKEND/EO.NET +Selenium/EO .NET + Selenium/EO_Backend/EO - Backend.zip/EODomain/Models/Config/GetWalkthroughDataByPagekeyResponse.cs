﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetWalkthroughDataByPagekeyResponse
    {
        public string? pageKey { get; set; }
        public string? tutID { get; set; }
        public string? title { get; set; }
        public string? subText { get; set; }
        public long? imageNodeID { get; set; }
        public long? audioNodeID { get; set; }
        public string? audioFileName { get; set; }
        public string? imageFileName { get; set; }
    }
}
