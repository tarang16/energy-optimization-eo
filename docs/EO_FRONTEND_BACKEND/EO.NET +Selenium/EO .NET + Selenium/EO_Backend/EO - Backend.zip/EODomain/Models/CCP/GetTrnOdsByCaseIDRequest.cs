﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetTrnOdsByCaseIDRequest
    {
        public int caseID { get; set; }
        public byte? defaultValue { get;set; }
    }
}
