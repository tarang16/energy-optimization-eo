﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public class OverallSignificanceEnergyResponse
    {
            public string? equipmentCategory { get; set; }
            public string? plantName { get; set; }
            public string? energySource { get; set; }
            public string? equipment { get; set; }
            public string? equipmentDescription { get; set; }
            public int? equipmentOperationDays { get; set; }
            public decimal? energyConsumed { get; set; }
            public decimal? targetEnergy { get; set; }
            public decimal? enpiGj { get; set; }
            public decimal? enpiDollars { get; set; }
            public decimal? processFlow { get; set; }
            public decimal? efficiency { get; set; }
            public string? opportunity { get; set; }
            public decimal? specificEnergyConsumption { get; set; }
        }
    }

