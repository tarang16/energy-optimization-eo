﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Config
{
    [ExcludeFromCodeCoverage]
    public class GetWalkthroughDataByPagekeyGrpResponse
    {
        public string? pageKey { get; set; }
        public List<PageKeyDetails>? pageKeyDetails { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class PageKeyDetails
    {
        public string? tutID { get; set; }
        public string? title { get; set; }
        public string? subText { get; set; }
        public long? imageNodeID { get; set; }
        public long? audioNodeID { get; set; }
        public string? audioFileName { get; set; }
        public string? imageFileName { get; set; }
        public int? sortKey { get; set; }
    }
}
