﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetPeOdsIdDetailsByCaseIdTimeStoredProcResponse
    {
        public int? caseID { get; set; }
        public int? modelId { get; set; }
        public int? peOdsId { get; set; }
        public DateTime? odsTimeStamp { get; set; }
        public int? seuId { get; set; }
        public string? seuName { get; set; }
        public string? seuCategory { get; set; }
        public string? seuDisplayName { get; set; }
        public string? energySource { get; set; }
        public string? solution { get; set; }
        public string? plantName { get; set; }

        public DateTime? mutedTill { get; set; }

        public DateTime? mutedOn { get; set; }

        public string? mutedByRole { get; set; }

        public string? mutedBy { get; set; }

        public string? reason { get; set; }

        public string? comment { get; set; }
    }
}
