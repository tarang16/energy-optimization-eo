﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;


namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class AffiliateIdInputRequest
    {
        [Range(0, 1000000000)]
        public int affiliateId { get; set; }
    }
}
