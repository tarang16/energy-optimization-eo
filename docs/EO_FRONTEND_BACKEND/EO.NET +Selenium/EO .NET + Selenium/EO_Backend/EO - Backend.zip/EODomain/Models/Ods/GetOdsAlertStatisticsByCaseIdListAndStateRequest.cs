﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;
using EODomain.Common;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class GetOdsAlertStatisticsByCaseIdListAndStateRequest
    {
        public string? caseIDList { get; set; }

        public DateTime? fromDate { get; set; }

        [RegularExpression(Constants.ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        [AllowNull]
        public string? status { get; set; }
    }
}
