﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class GetPlantDetailsResponse
    {
        public int? plantID { get; set; }
        public string? plantName { get; set; }
        public string? regionName { get; set; }
        public string? regionNameShort { get; set; }
        public string? countryName { get; set; }
        public string? affiliateName { get; set; }
        public string? affiliateNameShort { get; set; }
        public int? affiliateSapID { get; set; }
        public string? image { get; set; }
    }
}
