﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.AIHub
{
    [ExcludeFromCodeCoverage]
    public class GetSchedulesQueryResponse
    {
        public List<Content>? content { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Job
    {
        public string? location { get; set; }
        public string? queueName { get; set; }
        public int revision { get; set; }
        public Context? context { get; set; }
        public int maxTTL { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Context
    {
        public List<string>? inputLocations { get; set; }
        public List<string>? outputLocations { get; set; }
        public Macros? macros { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Macros
    {
        public string? additionalProp1 { get; set; }
        public string? additionalProp2 { get; set; }
        public string? additionalProp3 { get; set; }
    }

}