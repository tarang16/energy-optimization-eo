﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.EnergyManagement
{
    [ExcludeFromCodeCoverage]
    public  class GetPlantEnergyEciAirWaterSteamRequest
    {
        public DateTime? sDate { get; set; }
        public DateTime? eDate { get; set; }

        [AllowNull]
        public int? affiliateID { get; set; } = null;

        [AllowNull]
        public string? plantNameList { get; set; } = null;

        [AllowNull]
        public string? groupBy { get; set; } = "plantview";
    }
}
