﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class GetPlantBasedClaimsByUserIdStoredProcedureResponse
    {
        public int caseClaimID { get; set; }
        public int plantClaimID { get; set; }
        public int affiliateClaimID { get; set; }

    }
}
