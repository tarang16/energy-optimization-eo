﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class AIHubSettings
    {
        public string? ClientId { get; set; }
        public string? ClientSecret { get; set; }
        public string? RefreshToken { get; set; }
        public string? GrantType { get; set; }
    }
}
