﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetActivityTrackerLogsRepositoryLayerResponse
    {
        public int? pageCount { get; set; }
        public List<GetActivityTrackerLogsStoredProcedureResponse>? data { get; set; }
    }
}
