﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class AddUserToCustomUserTableRequest
    {
        [Range(1,100000000)]
        public int? employeeID { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? employeeName { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? firstName { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? lastName { get; set; }

        [DynamicMaxLength]
        [RegularExpression(Constants.ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? domainLoginID { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? affiliateCode { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? affiliateName { get; set; }

        [RegularExpression(Constants.EMAIL_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? email { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? country { get; set; }

        [RegularExpression(Constants.AlphaNumeric_regex, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? region { get; set; }
    }
}
