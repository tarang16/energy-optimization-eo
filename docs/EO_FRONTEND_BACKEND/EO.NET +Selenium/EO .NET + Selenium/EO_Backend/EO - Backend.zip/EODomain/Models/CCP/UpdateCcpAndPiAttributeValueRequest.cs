﻿using EOUtility;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdateCcpAndPiAttributeValueRequest
    {
        [Required]
        public int? modelID { get; set; }

        [Required]
        public int? tagID { get; set; }

        [Required]
        public int? piAfTag { get; set; }

        public string? tagName { get; set; }
        public string? piTagName { get; set; }
        public string? equipmentName { get; set; }

        public string? type { get; set; }

        [AllowNull]
        public decimal? min { get; set; }

        [AllowNull]
        public decimal? max { get; set; }

        [AllowNull]
        public decimal? defaultValue { get; set; }

        [AllowNull]
        public int? defaultSwitch { get; set; }


        [AllowNull]
        public byte? defaultSwitch_Pi_Af { get; set; }

        [AllowNull]
        public int? tagOutOfBoundSwitch { get; set; }

        [AllowNull]
        public int? tagStuckSwitch { get; set; }

        [AllowNull]
        public int? tagBoundAtLimitsSwitch { get; set; }

        [AllowNull]
        public int? tagNanSwitch { get; set; }
        [SwaggerIgnore]
        public string? elementName { get; set; } = null;
        [SwaggerIgnore]
        public string? attributeName { get; set; } = null;
        public dynamic? elementNameAttributeName { get; set; } = null;
        [SwaggerIgnore]
        public int? createdBy { get; set; }
    }
}
