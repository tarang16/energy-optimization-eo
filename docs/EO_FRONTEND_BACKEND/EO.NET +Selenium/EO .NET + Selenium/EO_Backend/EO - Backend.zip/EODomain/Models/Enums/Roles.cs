﻿namespace EODomain.Models.Enums
{
    public enum Roles
    {
        non_user,
        user,
        partial_corporate,
        corporate,
        admin
    }
}
