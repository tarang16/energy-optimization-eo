﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Workflow
{
    [ExcludeFromCodeCoverage]
    public class OdsCheckAutoClosureByReqIdRequest
    {
        public int? requestID { get; set; }
    }
}
