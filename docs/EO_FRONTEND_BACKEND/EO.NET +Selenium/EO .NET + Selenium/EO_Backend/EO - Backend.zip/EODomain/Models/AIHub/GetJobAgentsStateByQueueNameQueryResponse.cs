﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.AIHub
{
    [ExcludeFromCodeCoverage]
    public class GetJobAgentsStateByQueueNameQueryResponse
    {
        public string? name { get; set; }
        public int totalPendingJobs { get; set; }
        public int totalRunningJobs { get; set; }
        public List<Jobagent>? jobAgents { get; set; }
        public List<Permission>? permissions { get; set; }
        public bool permanent { get; set; }
        public bool purgeInProgress { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Jobagent
    {
        public string? id { get; set; }
        public string? name { get; set; }
        public string? state { get; set; }
        public int numberOfJobContainers { get; set; }
        public int maxMemoryPerContainer { get; set; }
        public string? agentVersion { get; set; }
        public string? rmCoreVersion { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Permission
    {
        public string? groupName { get; set; }
        public string? privilege { get; set; }
    }

}
