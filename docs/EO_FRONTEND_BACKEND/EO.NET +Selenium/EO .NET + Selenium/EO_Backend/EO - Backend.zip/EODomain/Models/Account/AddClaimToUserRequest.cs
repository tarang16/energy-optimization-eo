﻿using EODomain.Common;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class AddClaimToUserRequest
    {
        [Required(ErrorMessage = ResponseConstants.REQUIRED_USER_ID)]
        public string? UserId { get; set; }

        [Required(ErrorMessage = ResponseConstants.REQUIRED_CLAIMS)]
        public Dictionary<string, string>? Claims { get; set; }
    }
}
