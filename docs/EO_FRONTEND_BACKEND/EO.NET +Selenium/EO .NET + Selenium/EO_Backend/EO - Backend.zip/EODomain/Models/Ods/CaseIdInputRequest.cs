﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class OdsCaseIdInputRequest
    {
       
       
        [Range(0, 1000000000)]
        public int caseId { get; set; }
    }
}
