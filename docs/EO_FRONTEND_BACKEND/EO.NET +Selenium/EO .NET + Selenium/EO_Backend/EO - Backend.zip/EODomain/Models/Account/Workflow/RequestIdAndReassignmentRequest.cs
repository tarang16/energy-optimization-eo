﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Account.Workflow
{
    [ExcludeFromCodeCoverage]
    public class RequestIdAndReassignmentRequest
    {
        [Range(0, 1000000000)]
        public int requestId { get; set; }

        [Range(0,1)]
        public byte isReassignment { get; set; }
    }
}
