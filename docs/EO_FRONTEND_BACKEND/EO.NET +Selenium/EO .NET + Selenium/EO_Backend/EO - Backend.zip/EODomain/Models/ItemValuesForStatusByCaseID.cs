﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class ItemValuesForStatusByCaseID
    {
        public string? WebId { get; set; }
        public string? Name { get; set; }
        public string? Path { get; set; }
        public Dictionary<string, string>? Links { get; set; }
        public GetInterpolatedItemResponse? Value { get; set; }
    }
}
