﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models
{
    [ExcludeFromCodeCoverage]
    public class PISettings
    {
        public string? UserName { get; set; }
        public string? Password { get; set; }
    }
}
