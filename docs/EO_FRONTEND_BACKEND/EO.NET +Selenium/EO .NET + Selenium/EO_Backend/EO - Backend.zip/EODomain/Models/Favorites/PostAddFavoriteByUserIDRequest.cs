﻿using EODomain.Common;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.Favorites
{
    [ExcludeFromCodeCoverage]
    public class PostAddFavoriteByUserIDRequest
    {
        [Range(0, 100000000)]
        public int userID { get; set; }

        [DynamicMaxLength]
        public string? url { get; set; }

        [RegularExpression(Constants.ENGLISH_DESCRIPTION_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        [DynamicMaxLength]
        public string? title { get; set; }
    }
}
