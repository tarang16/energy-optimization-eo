﻿using EOUtility;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class DeleteClaimFromUserRequest
    {
        [Required]
        public string? claimIDList { get; set; }
        [SwaggerIgnore]
        public int updatedByUserID { get; set; }
    }
}
