﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class GetVCByCaseIDListRequest
    {
        [Required]
        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]
        public string? caseIDList { get; set; }

        [Required]
        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime sTime { get; set; }

        [Required]
        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime etime { get; set; }
    }
}
