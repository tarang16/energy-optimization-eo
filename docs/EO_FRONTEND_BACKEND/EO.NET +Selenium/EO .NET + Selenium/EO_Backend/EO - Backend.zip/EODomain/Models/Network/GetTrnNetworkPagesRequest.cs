﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Network
{
    [ExcludeFromCodeCoverage]
    public class GetTrnNetworkPagesRequest
    {
        public int caseId { get; set; }
        public int pageId { get; set; }
    }
}
