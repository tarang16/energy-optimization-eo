﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.ValueCreation
{
    [ExcludeFromCodeCoverage]
    public class PostAddValueCreationDataRequestStoredProcedureRequest : PostAddValueCreationDataRequest
    {
        public int isActive { get; set; }
        public int createdBy { get; set; }
        public int updatedBy { get; set; }
        public DateTime? updatedOn { get; set; }
    }
}
