﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class GetApiRequestLogsStoredProcedureResponse
    {
        public string? EmailID { get; set; }
        public string? UserName { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public int? EmployeeID { get; set; }
        public string? Role { get; set; }
        public string? SessionID { get; set; }
        public string? LayerName { get; set; }
        public string? ApiEndPoint { get; set; }
        public string? HttpMethod { get; set; }
        public int? StatusCode { get; set; }
        public string? RequestBody { get; set; }
        public string? Duration { get; set; }
        public DateTime? CreatedOn { get; set; }
        public long? CreatedOnEpoch { get; set; } = null;
    }
}
