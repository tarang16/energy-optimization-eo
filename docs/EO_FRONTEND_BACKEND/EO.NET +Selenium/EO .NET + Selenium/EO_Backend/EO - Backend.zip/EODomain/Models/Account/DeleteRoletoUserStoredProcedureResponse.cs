﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Account
{
    [ExcludeFromCodeCoverage]
    public class DeleteRoletoUserStoredProcedureResponse
    {
        public string? roleID { get; set; }
        public int isActive { get; set; }
    }
}
