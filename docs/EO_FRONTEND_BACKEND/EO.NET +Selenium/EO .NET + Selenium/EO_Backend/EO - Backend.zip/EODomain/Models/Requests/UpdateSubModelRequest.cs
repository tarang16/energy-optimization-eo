﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class UpdateSubModelRequest
    {
        public int caseID { get; set; }
        public int subModelID { get; set; }
        public string? subModelName { get; set; }
        public string? subModelType { get; set; }
        public int order { get; set; }
        public bool responseOutput { get; set; }
        public string? subModelExpression { get; set; }
    }
}
