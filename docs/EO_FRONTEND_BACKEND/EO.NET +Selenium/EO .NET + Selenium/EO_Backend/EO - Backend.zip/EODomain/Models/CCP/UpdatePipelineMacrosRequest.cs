﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.CCP
{
    [ExcludeFromCodeCoverage]
    public class UpdatePipelineMacrosRequest
    {
        public int pipelineMacroID { get; set; }
        public string? value { get; set; }
        public int? mstPipelineMacroID { get; set; }
    }
}
