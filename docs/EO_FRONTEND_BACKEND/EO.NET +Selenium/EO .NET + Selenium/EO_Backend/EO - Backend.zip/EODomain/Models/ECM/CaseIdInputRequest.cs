﻿using System.Diagnostics.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace EODomain.Models.ECM
{
    [ExcludeFromCodeCoverage]
    public class CaseIdInputRequest
    {
        [Range(0, 1000000000)]
        public int caseID { get; set; }
    }

    [ExcludeFromCodeCoverage]

    public class EcmCaseIdInputRequest
    {        
        public int caseID { get; set; }
    }
}
