﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.LogTables
{
    [ExcludeFromCodeCoverage]
    public class ErrorLogRequest
    {
        public string? ErrorId { get; set; } = null;
        public string? EmployeeId { get; set; } = null;
        public string? Email { get; set; } = null;
        public DateTime? CreatedOn { get; set; } = null;
        public string? ApplicationName { get; set; } = null;
        public string? HostName { get; set; } = null;
        public string? LayerName { get; set; } = null;
        public string? ScreenName { get; set; } = null;
        public string? ModuleName { get; set; } = null;
        public string? API { get; set; } = null;
        public string? StoredProcedure { get; set; } = null;
        public string? Functionality { get; set; } = null;
        public string? ErrorNumber { get; set; } = null;
        public string? ErrorState { get; set; } = null;
        public string? ErrorSeverity { get; set; } = null;
        public string? StackTraceId { get; set; } = null;
        public string? StackTrace { get; set; } = null;
        public string? ErrorMessage { get; set; } = null;
        public string? SessionId { get; set; } = null;
        public string? RequestBody { get; set; } = null;
        public DateTime? UpdatedOn { get; set; } = null;
        public Nullable<int> StatusCode { get; set; } = null;
        public string? WebServer { get; set; } = null;
        public string? Status { get; set; } = null;
        public string? AssignedTo { get; set; } = null;
        public Nullable<int> CreatedBy { get; set; } = null;
        public Nullable<int> UpdatedBy { get; set; } = null;
        public string? EmployeeName { get; set; } = null;
        public string? FirstName { get; set; } = null;
        public string? LastName { get; set; } = null;
        public string? Rolename { get; set; } = null;
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
    }
}
