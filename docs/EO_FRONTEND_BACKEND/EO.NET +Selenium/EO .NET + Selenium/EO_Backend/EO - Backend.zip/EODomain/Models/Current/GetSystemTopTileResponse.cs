﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Models.Current
{
    [ExcludeFromCodeCoverage]
    public class GetSystemTopTileResponse
    {
        public int? deviationActive { get; set; }
        public int? deviationOverdue { get; set; }

        public double? energyBillEfficiency { get; set; }
        public string? energyBillEfficiencyUom { get; set; }
        public double? opportunityEnergyBills { get; set; }
        public string? opportunityEnergyBillsUom { get; set; }
        public double? energyEfficiency { get; set; }
        public string? energyEfficiencyUom { get; set; }
        public double? opportunityTotalEnergyConsumption { get; set; }
        public string? opportunityTotalEnergyConsumptionUom { get; set; }
        public double? carbonNeutralityIndex { get; set; }
        public string? carbonNeutralityIndexUom { get; set; }
        public double? opportunityCo2 { get; set; }
        public string? opportunityCo2Uom { get; set; }
        public double? seecGain { get; set; }
        public string? seecGainUom { get; set; }
        public double? seecEnpi { get; set; }
        public string? seecEnpiUom { get; set; }
    }
}
