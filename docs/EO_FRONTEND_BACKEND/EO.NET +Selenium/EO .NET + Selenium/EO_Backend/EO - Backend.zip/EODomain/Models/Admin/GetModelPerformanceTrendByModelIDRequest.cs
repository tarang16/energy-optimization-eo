﻿using EODomain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EODomain.Models.Admin
{
    [ExcludeFromCodeCoverage]
    public  class GetModelPerformanceTrendByModelIDRequest
    {
        [Required]
        [Range(0, 100000000)]
        public int modelID { get; set; }

        [Required]
        [RegularExpression(Constants.ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION, ErrorMessage = "Invalid format")]        
        public string? parameter { get; set; }

        [Required]
        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime sTime { get; set; }

        [Required]
        [Range(typeof(DateTime), "1/1/2020", "1/1/2099")]
        public DateTime eTime { get; set; }
    }
}
