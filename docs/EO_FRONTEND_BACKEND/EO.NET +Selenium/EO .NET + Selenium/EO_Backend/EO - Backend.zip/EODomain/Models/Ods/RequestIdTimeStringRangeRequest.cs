﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Ods
{
    [ExcludeFromCodeCoverage]
    public class RequestIdTimeStringRangeRequest
    {
        [Required]
        public int? requestId { get; set; }

        [DynamicMaxLength]
        [AllowNull]
        public string? sTime { get; set; } = null;

        [DynamicMaxLength]
        [AllowNull]
        public string? eTime { get; set; } = null;
    }
}
