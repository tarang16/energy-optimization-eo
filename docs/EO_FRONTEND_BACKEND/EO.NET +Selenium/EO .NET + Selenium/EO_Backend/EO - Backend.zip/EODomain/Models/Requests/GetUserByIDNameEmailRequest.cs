﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using EODomain.Common;

namespace EODomain.Models.Requests
{
    [ExcludeFromCodeCoverage]
    public class GetUserByIDNameEmailRequest
    {
        [DynamicMaxLength]
        public string? keyword { get; set; }
    }
}
