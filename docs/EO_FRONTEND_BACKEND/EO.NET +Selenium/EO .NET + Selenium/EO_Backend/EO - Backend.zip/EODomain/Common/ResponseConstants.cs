﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Common
{
    [ExcludeFromCodeCoverage]
    public static class ResponseConstants
    {
        public const int OK = 200;
        public const int CREATED = 201;
        public const int EMPTYOK = 204;
        public const int PARTIAL_CONTENT = 206;
        public const int CUSTOMERROR = 400;
        public const int NOTAUTHENTICATED = 401;
        public const int NOTAUTHORIZED = 403;
        public const int NOTFOUND = 404;
        public const int CONFLICT = 409;
        public const int SERVERERROR = 500;
        public const int GATEWAY_TIMEOUT = 504;
        public const int BAD_GATEWAY = 502;
        public const int RM_API_ERROR = 421;

        public const string SUCCESS_MESSAGE = "Success";
        public const string INVALID_ID_TYPE = "ID(s) should be of type INT";
        public const string EMPTYOK_MESSAGE = "No data found";
        public const string RMAPI_ERRORMESSAGE = "API is not running at this moment";
        public const string DATA_WAS_PARTIALLY_UPDATED = "Data was partially updated, refresh to check";
        public const string DATA_WAS_PARTIALLY_INSERTED = "Data was partially inserted, refresh to check";
        public const string NOTAUTHENTICATED_MESSAGE = "You are not authenticated";
        public const string WORKLFOW_NOTAUTHORIZED_MESSAGE = "You are not authorized";
        public const string NOTAUTHORIZED_MESSAGE = "You are not authorized to view this case or plant. Please contact Admin.";
        public const string NOT_AUTHORIZED_TO_VIEW_PAGE_MESSAGE = "You are not authorized to view this page. Please contact Admin.";
        public const string NOT_AUTHORIZED_TO_TAKE_THIS_ACTION = "You are not authorized to take this action. Please contact Admin.";
        public const string NOTFOUND_MESSAGE = "Not Found";
        public const string ACCESSCHANGED_MESSAGE = "Access Changed";
        public const string DELETED_MESSAGE = "Deleted";
        public const string INVALID_INPUT = "Invalid inputs";
        public const string CONFLICT_MESSAGE = "User is already logged in, logout from other devices to proceed.";
        public const string CONTACT_TALABI = "Kindly contact the Sabic BPM Administrator through Talabi.";
        public const string COULD_NOT_TRIGGER_WORKFLOW = "Could not trigger workflow service for requestID:";
        public const string COULD_NOT_UPDATE_DATA = "Could not update data";
        public const string COULD_NOT_INSERT_DATA = "Could not insert data";
        public const string COULD_NOT_VALIDATE_ASSIGNEE = "Could not validate assignee for requestID:";
        public const string COULD_NOT_SEND_EMAIL = "Could not send email for requestID:";
        public const string COULD_NOT_RUN_WORKFLOW = "Could not run workflow service for requestID:";
        // AI Hub && Health Status
        public const string LASTRUNTIMENOTFOUND = "Last run time not found for caseID: ";
        public const string SOLUTIONRUNNING= "Solution is live";
        public const string SOLUTIONNOTRUNNING = "Solution is not live";
        public const string JOBNOTFOUNDINAIHUB = "Model is paused (job not found in AI Hub)";
        public const string AIHUBTOKENNOTGENERATED = "Unable to connect to AI HUB";
        public const string JOBIDNOTFOUNDINDB = "Job ID not found in database";
        public const string MODELINPENDINGSTATE = "Model in PENDING state";
        public const string MODELINSTOPPEDSTATE = "Model in STOPPED state";
        public const string MODELINERRORSTATE = "Model in ERROR state";
        public const string MODELSTATENOTFOUND = "Model STATE not found";
        public const string JOBNOTFOUND = "Model data not found";
        public const string JOBNOTSUBMITTEDINAIHUB = "Model is paused (job not submitted in AI Hub)";
        public const string MODELINBACKFILLINGMODE = "Model in backfilling mode";

        public const string DATABASECONNECTED = "Database connected";
        public const string DATABASENOTCONNECTED = "Could not connect with database";
        public const string FAILEDTOCONNECTWITHDATABASE = "Failed to connect with database";

        // PI Services Status
        public const string PISERVICEISUPANDRUNNING = "PI service is up and running";
        public const string PIDATANOTFOUND = "No PI data found for caseID: ";
        public const string PISERVICEISDOWN = "PI Service is down";
        public const string UNABLE_TO_CONNECT_TO_PI = "Unable to connect to PI service";
        public const string PI_SERVICE_IS_DOWN = "PI service is down";
        public const string PI_DATA_LAGGING = "PI data lagging";
        public const string PI_DATA_BAD_VALUE = "PI data: Bad Value";
        public const string PI_WEB_ID_NOT_FOUND = "PI web-id not found";
        public const string NO_WRITE_ACCESS_PI_ATTRIBUTES = "There is no write access for the following PI Attributes. Kindly connect with Admin.";
        public const string NO_READ_ACCESS_PI_ATTRIBUTES = "There is no read access for the following PI Attributes. Kindly connect with Admin.";
        public const string COULD_NOT_UPDATE_PI_ATTRIBUTES = "Could not update following PI Attributes";
        public const string UPDATED_ATTRIBUTES_SUCCESSFULLY = "Tag updated successfully";
        public const string COULD_NOT_UPDATE_PI_CONSTANT = "Could not update following PI Constant";
        public const string UPDATED_PI_ELEMENT_CONSTANT = "Constant updated successfully";
        public const string ATTRIBUTES_UPDATE_BAD_PAYLOAD = "Could not update following PI Attributes. Please provide valid payload.";
        public const string PIAF_SERVER_HAS_REJECTED_CLIENT_CREDENTIALS = "The Server has rejected client credentials, it seems you do not have access to PI-AF Database. Kindly connect with Admin.";
        public const string INVALIAD_ELEMENT_NAME = "Invalid element name";
        public const string INVALIAD_ATTRIBUTE_NAME = "Invalid attribute name";
        public const string FAILED_TO_FETCH_PI_TAG = "Failed to fetch pi tags";

        public const string AIHUBISUPANDRUNNING = "AI Hub is up and running";
        public const string AIHUBHEALTHCHECKFAILED = "AI Hub health check failed";
        public const string AIHUBJOBAGENTNOTACTIVE = "AI Hub job agent is not active: ";
        public const string AIHUBJOBAGENTACTIVE = "AI Hub job agent is active";
        public const string AIHUBJOBAGENTSNOTFOUND = "AI Hub job agents not found queue: ";

        public const string CASEIDCOLUMNNOTFOUND = "'case_id' column not found for the table";
        public const string IDCOLUMNNOTFOUND = "'ID' column not found for the table";

        public const string WEBIDNOTFOUND = "PI webID not found";
        public const string PIERRORSTATUS = "PI status: error";
        public const string PIWORKINGSTATUS = "Pi status: working";

        public const string AIHUBHEALTHSERVICE = "AI Hub";
        public const string DATABASEHEALTHSERVICE = "Database";
        public const string MODELHEALTHSERVICE = "Model";
        public const string CASEHEALTHSERVICE = "Case";
        public const string PIHEALTHSERVICE = "PI";

        public const string VALIDATION_ERROR = "Could not validate input";
        public const string ROLE_VALIDATION_ERROR = "Invalid role";
        public const string CREATEDBY_VALIDATION_ERROR = "Invalid created by userID";
        public const string USERID_VALIDATION_ERROR = "Invalid userID";
        public const string INT_DATATYPE_VALIDATION_ERROR = "Expected INT type userIDs";
        public const string CAN_ADD_ONLY_ONE_USER_TO_ROLE = "Can add only one user to role";
        public const string COULD_NOT_SIMULATE_REQUESTED_DATA = "Gateway Timed Out. Could Not Simulate Requested Data";
        public const string COULD_NOT_FIND_FILES_IN_ECM = "No nodeID found for the system";
        public const string SignalRMethod = "ReceiveNotification";
        public const string NotificationMessage = "Records updated successfully!";
        public const string SignalRError = "ReceiveError";
        public const string SignalRErrorMessage = "An error occurred during query execution";

        // Workflow
        public const string COULD_NOT_UPDATE_WORKFLOW_CONFIGURATIONS = "Could not update workflow configurations";
        public const string COULD_NOT_UPDATE_PM_DELEGATION_INFORMATION = "Could not update Process Manager delegation information";
        public const string COULD_NOT_UPDATE_MUTE_STATUS = "Could not mute notifications for causeID: ";

        private static readonly string[] emptyData = Array.Empty<string>();
        public static string[] EMPTYDATA => emptyData;

        //Account
        public const string REQUIRED_USER_ID = "UserId cannot be null or empty.";
        public const string REQUIRED_CLAIMS = "Claims cannot be null or empty.";
        public const string SINGLE_CLAIM_REQUIRED = "Expected only one key-value pair in claims.";
        public const string CLAIM_TYPE_REQUIRED = "Claim type cannot be null or empty.";
        public const string CLAIM_VALUE_REQUIRED = "Claim value cannot be null or empty.";
        public const string UNEXPECTED_CLAIM_TYPE = "Unexpected claimType: {0}";
        public const string INVALID_USER_ID = "Expected INT type userIDs.";
        public const string INVALID_CLAIM_VALUE = "Expected INT type claimValues.";
        public const string USER_HAS_ADMIN_ACCESS = "User has Admin Access";
        public const string USER_HAS_ADMIN_COR_ACCESS = "User has Admin/Corporate Access";
        public const string USER_HAS_ACCESS = "User already has Access";
        public const string SKIP_MAIL = "Email not sent since the sending criteria were not met.";

    }
}
