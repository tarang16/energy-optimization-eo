﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Common
{
    [ExcludeFromCodeCoverage]
    public static class SPConstant
    {

        // Config
        public const string USP_GET_CASE_WISE_DOWNLOAD_DATA = "[dbo].[usp_ui_get_casewise_download_data]";
        public const string GET_CASE_INFO_BY_CASE_ID_LIST = "[dbo].[get_case_info_by_case_id_list]";
        public const string USP_EO_EM_GET_UOM = "[dbo].[usp_eo_em_get_uom]";
        public const string UI_GET_LANDING_AFFILIATE_SCORECARD = "[dbo].[usp_ui_get_landing_affiliate_score_card]";
        public const string UI_GET_USER_STATISTICS_SCREEN_NAMES = "[dbo].[usp_ui_get_users_statistics_screens]";
        public const string USP_UI_GET_AFFILIATE_ID_BY_CASE_ID = "[dbo].[usp_ui_get_affiliate_id_by_case_id]";
        public const string USP_UI_GET_AFFILIATE_ID_BY_DERIVED_EQUATION_ID = "[dbo].[usp_ui_get_affiliate_id_by_derived_equation_id]";
        public const string USP_UI_GET_AFFILIATE_ID_BY_VARIABLE_ID = "[dbo].[usp_ui_get_affiliate_id_by_variable_id]";
        public const string USP_UI_GET_AFFILIATE_ID_BY_CONSTRAINT_Id = "[dbo].[usp_ui_get_affiliate_id_by_constraint_id]";
        public const string USP_UI_GET_AFFILIATE_ID_BY_MODEL_TAG_Id = "[dbo].[usp_ui_get_affiliate_id_by_modeltag_id]";
        public const string USP_UI_GET_AFFILIATE_ID_BY_OBJECTIVE_ID = "[dbo].[usp_ui_get_affiliate_id_by_objective_id]";
        public const string USP_UI_GET_AFFILIATE_ID_BY_MODEL_Id = "[dbo].[usp_ui_get_affiliate_id_by_model_id]";
        public const string USP_UI_GET_WALKTHROUGH_DATA_BY_PAGEKEY = "[dbo].[usp_ui_get_walkthrough_data_by_pagekey]";

        // Energy Management        
        public const string GET_ENERGY_COST_INDEX_ENERGY_GAP_MONTHLY_INDEX = "[dbo].[usp_eo_em_get_energy_cost_index_energy_gap_monthly_trend]";
        public const string GET_ENPI_DAILY_TREND = "[dbo].[usp_eo_em_get_enpi_daily_trend]";
        public const string GET_AIR_WATER_STEAM_TREND = "[dbo].[usp_eo_em_get_air_water_steam_trend]";
        public const string GET_OVERALL_SIGNIFICANCE_ENERGY = "[dbo].[usp_eo_em_get_overall_significance_energy]";
        public const string GET_CW_ENERGY_COST_TREND = "[dbo].[usp_eo_em_get_cw_energy_cost_trend]";
        public const string GET_CW_FLOW_RATE_TREND = "[dbo].[usp_eo_em_get_cw_flow_rate_trend]";
        public const string GET_STEAM_TREND = "[dbo].[usp_eo_em_get_steam_trend]";
        public const string GET_AIR_TREND = "[dbo].[usp_eo_em_get_air_trend]";
        public const string GET_TOP_SIX_TILE = "[dbo].[usp_eo_em_get_top_six_tiles]";
        public const string GET_RECONCILED_DATA = "[dbo].[usp_eo_em_get_reconciled_data]";
        public const string GET_PLANT_AFFILIATES = "[dbo].[usp_eo_em_get_plant_affiliates]";
        public const string GET_PLANT_ENERGY_ECI_AIR_WATER_STEAM = "[dbo].[usp_eo_em_get_plant_energy_eci_air_water_steam]";

        public const string GET_CW_COST_PER_UNIT_TREND = "[dbo].[usp_eo_em_get_cw_cost_per_unit_trend]";
        public const string GET_CW_LOAD_HEAT_REJECTION_TREND = "[dbo].[usp_eo_em_get_cw_load_heat_rejection_trend]";
        public const string GET_ECI_TREND = "[dbo].[usp_eo_em_get_eci_trend]";
        public const string GET_SPECIFIC_ENERGY_CATEGORY = "[dbo].[usp_eo_em_get_specific_energy_category]";
        public const string GET_SPECIFIC_ENERGY_CATEGORY_EQUIPMENT = "[dbo].[usp_eo_em_get_specific_energy_category_equipment]";
        public const string GET_SPECIFIC_ENERGY_CATEGORY_EQUIPMENT_TREND = "[dbo].[usp_eo_em_get_specific_energy_category_trend]";
        public const string GET_TOP_TILE_PLANTS = "[dbo].[usp_eo_em_get_top_six_tiles_plants]";
        public const string GET_ENERGY_CONSUMED_SPECIFIC_ENERGY = "[dbo].[usp_eo_em_get_energy_consumed_specific_energy]";
        public const string GET_EM_ENERGY_GAP = "[dbo].[usp_eo_em_get_energy_gap]";
        public const string GET_EM_KEV_STATE_UOM = "[dbo].[usp_eo_em_get_kev_state_uom]";
        public const string GET_EQUIPMENT_DESIGN_CAPACITY = "[dbo].[usp_eo_em_get_equipment_design_capacity]";
        public const string GET_EO_EM_GET_EQUIPMENT_LIST = "[dbo].[usp_eo_em_get_equipment_list]";

        // Network
        public const string GET_MST_NETWORK_PAGES = "[dbo].[usp_ui_eo_get_mst_network_pages]";
        public const string GET_TRN_NETWORK_PAGES = "[dbo].[usp_ui_eo_get_trn_network_pages]";
        public const string GET_ADD_MST_NETWORK_PAGES = "[dbo].[usp_ui_eo_add_mst_network_pages]";
        public const string GET_ADD_TRN_NETWORK_PAGES = "[dbo].[usp_ui_eo_add_trn_network_pages]";
        public const string GET_ALL_TAGS_BY_CASE_ID = "[dbo].[usp_ui_eo_get_all_tags_by_case_id]";
        public const string GET_ALL_TAGS_DATA_BY_CASE_ID = "[dbo].[usp_ui_eo_get_all_tags_data_by_case_id]";

        //Historical
        public const string EO_UI_GET_CALENDER_DATA = "[dbo].[usp_ui_get_calenderdata]";
        public const string EO_UI_GET_ACTUAL_OPTIMUM_TREND = "[dbo].[usp_ui_get_actualoptimum_trend]";
        public const string EO_UI_GET_OPPORTUNITY_TREND = "[dbo].[usp_ui_get_opportunity_trend_by_case_id_list]";
        public const string EO_UI_GET_DATA_MODEL_SKIP_MONITORING = "[dbo].[usp_ui_eo_get_data_model_skip_monitoring]";
        public const string EO_UI_GET_DATA_MODEL_SKIP = "[dbo].[usp_ui_eo_get_datamodelskip]";

        // Current
        public const string EO_UI_GET_KPI_OUTPUT = "[dbo].[usp_ui_get_kpi_output]";
        public const string EO_UI_GET_SYSTEM_TOP_TILE_OUTPUT = "[dbo].[usp_ui_get_system_tiledata]";
        public const string EO_UI_GET_TIME_ACTUAL = "[dbo].[usp_ui_get_timeactual]";
        public const string EO_UI_GET_MONITORING_DATA = "[dbo].[usp_ui_get_monitoring_data]";
        public const string EO_UI_GET_TREE_DIAGRAM = "[dbo].[usp_ui_eo_get_tree_diagram_by_case_id]";
        public const string EO_UI_GET_OVERVIEW_TREND_DATA = "[dbo].[usp_ui_eo_get_overview_trend_data]";
        public const string USP_UI_GET_SEU_OUTPUT_DATA = "[dbo].[usp_ui_get_seu_output_data]";
        public const string USP_EO_EM_GET_SEEC_TREND = "[dbo].[usp_eo_em_get_seec_trend]";
        public const string USP_UI_EO_GET_SEU_DETAILS = "[dbo].[usp_ui_eo_get_seu_details]";
        public const string USP_UI_EO_GET_SUB_MODEL = "[dbo].[usp_ui_eo_get_sub_model]";
        public const string USP_UI_EO_UPDATE_SEU_DETAILS = "[dbo].[usp_ui_eo_update_seu_details]";
        public const string USP_UI_EO_UPDATE_SUB_MODEL = "[dbo].[usp_ui_eo_update_sub_model]";
        public const string USP_UI_GET_ENERGY_DISTRIBUTION = "[dbo].[usp_ui_get_enegry_distribution]";
        public const string USP_UI_EO_GET_KEVS_OUTPUT = "[dbo].[usp_ui_eo_get_kevs_output]";
        public const string EO_UI_GET_MONITORING_CATEGORIES = "[dbo].[usp_ui_get_monitoring_categories]";
        public const string USP_UI_EO_GET_SUB_MODEL_PARAMETER = "[dbo].[usp_ui_eo_get_sub_model_parameter]";
        public const string USP_UI_EO_UPDATE_SUB_MODEL_PARAMETER = "[dbo].[usp_ui_eo_update_sub_model_parameter]";

        // Optimization
        public const string USP_UI_EO_GET_ASSET_AVAILAIBILITY = "[dbo].[usp_ui_eo_get_equipment_availability]";
        public const string USP_UI_EO_GET_PLANT_LOAD = "[dbo].[usp_ui_eo_get_plant_load]";
        public const string USP_UI_EO_GET_DEMAND_INPUTS = "[dbo].[usp_ui_eo_get_demand]";
        public const string USP_UI_EO_GET_OUTPUT_MAPPINTGS = "[dbo].[usp_ui_eo_get_optimizer_output]";
        public const string USP_GET_OPTIMIZATION_PRICE_INPUT = "[dbo].[usp_get_optimization_price_input]";
        public const string USP_UI_EO_GET_WHAT_IF_PLANT_PARAMETERS = "[dbo].[usp_ui_eo_get_what_if_plant_parameters]";

        // Favorites
        public const string UI_GET_FAVORITE_BY_USER_ID = "[dbo].[usp_ui_get_favorite_by_user_id]";
        public const string UI_ADD_FAVORITE_BY_USER_ID = "[dbo].[usp_ui_add_favorite_by_user_id]";
        public const string UI_DELETE_FAVORITE_BY_FAV_ID = "[dbo].[usp_ui_delete_favorite_by_fav_id]";
        public const string UI_ADD_FAVTREND_BY_CASE_ID = "[dbo].[usp_ui_add_favorite_trend_by_user_id]";
        public const string UI_GET_FAVTREND_BY_CASE_ID = "[dbo].[usp_ui_get_favorite_trend_by_user_id]";
        public const string UI_DELETE_FAVTREND_BY_CASE_ID = "[dbo].[usp_ui_delete_favorite_trend_by_case_id]";
        public const string UI_GET_ALL_FAVTREND_BY_CASE_ID = "[dbo].[usp_ui_get_all_favorite_trend_by_user_id]";
        public const string USP_UI_ADD_USER_PREFERENCES = "[dbo].[usp_ui_add_user_preferences]";
        public const string USP_UI_GET_USER_PREFERENCES_BY_USER_ID = "[dbo].[usp_ui_get_user_preferences_by_user_id]";
        public const string USP_UI_DELETE_USER_PREFERENCES = "[dbo].[usp_ui_delete_user_preferences]";


        //Admin
        // Admin User Statistics
        public const string USP_UI_GET_USERS_STATISTICS_COUNT = "[dbo].[usp_ui_get_users_statistics_count]";
        public const string USP_UI_GET_USER_STATISTICS_LOGS = "[dbo].[usp_ui_get_users_statistics_logs]";
        public const string USP_UI_GET_USER_ANALYTICS_LOGS = "[dbo].[usp_ui_get_user_analytics_logs]";
        public const string USP_UI_GET_USERS_STATISTICS_GRAPH = "[dbo].[usp_ui_get_users_statistics_graph]";
        public const string USP_UI_GET_USER_ANALYTICS_BY_SCREEN_WISE = "[dbo].[usp_ui_get_user_analytics_by_screenwise]";
        public const string USP_UI_GET_USER_STATISTICS_SCREENS = "[dbo].[usp_ui_get_users_statistics_screens]";
        public const string USP_UI_GET_USER_STATISTICS_ONLINE_USERS = "[dbo].[usp_ui_get_users_statistics_OnlineUsers]";


        //Email
        public const string ADM_GET_DATA_STATUS_REPORT = "[dbo].[usp_adm_get_data_status_report]";
        public const string ADM_GET_EMAIL_BY_PROJECT_CODE = "[dbo].[usp_adm_get_email_by_project_code]";
        public const string ADM_ADD_EMAIL_LIST_BY_EMAIL_ID = "[dbo].[usp_adm_add_email_list_by_emailid]";
        public const string ADM_GET_ALL_EMAILS = "[dbo].[usp_adm_get_all_emails]";
        public const string ADM_ADD_Add_EMAIL = "[dbo].[usp_adm_add_emails]";
        public const string USP_UI_GET_WF_REPORT_MAIL = "[dbo].[usp_ui_get_wf_report_mail]";
        public const string USP_UI_GET_WF_MAILIDS_FOR_REPORT_MAIL = "[dbo].[usp_ui_get_wf_mailids_for_report_mail]";
        public const string USP_UI_GET_WF_ESCALATION_REPORT_MAIL = "[dbo].[usp_ui_get_wf_escalation_report_mail]";
        public const string USP_UI_GET_WF_LAST_TRIGGERED_INFO = "[dbo].[usp_ui_get_wf_last_triggered_info]";
        public const string USP_UI_Update_WF_LAST_TRIGGERED_INFO = "[dbo].[usp_ui_update_wf_last_triggered_info]";
        public const string USP_ADM_GET_GLOBAL_SETTING = "[dbo].[usp_adm_get_global_setting]";
        public const string USP_ADM_GET_USERID_BY_USERCLAIMID = "[dbo].[usp_adm_get_userid_by_userclaimid]";
        public const string GET_HTML_DATA_FOR_EMAIL_BY_PROJECT_CODE = "[dbo].[usp_adm_get_html_data_for_email_by_project_code]";
        public const string ADM_GET_UM_USER_BY_EMPLOYEE_ID = "[dbo].[usp_adm_get_user_by_employee_id]";

        // ODS
        public const string GET_ODS_OVERVIEW_BY_CASE_ID_TIME= "[dbo].[usp_ui_get_ods_overview_by_case_id_time]";
        public const string GET_PE_ODS_ID_Details_BY_CASE_ID_TIME = "[dbo].[usp_get_peeo_ods_ids_by_caseid_time]";
        public const string GET_PE_ODS_Details_BY_ODS_ID_LIST_TIME = "[dbo].[usp_ui_get_ods_details_by_odsidlist_time]";

        // Account
        public const string GET_USER_ACCESS_BY_EMPLOYEE_ID = "[dbo].[usp_adm_get_user_access_by_employee_id]";
        public const string GET_USER_FEATURE_ACCESS_BY_EMPLOYEE_ID = "[dbo].[usp_adm_get_user_feature_access_by_employee_id]";
        public const string GET_UM_ROLE_BY_AFFILIATE_ID = "[dbo].[usp_adm_get_um_role_by_affiliate_id]";


        //CCP
        public const string UI_GET_CCPDATA_ORG = "[dbo].[usp_get_ccp_data]";
        public const string UI_GET_CCPDATA = "[dbo].[usp_get_ccp_with_pi_af_data_by_case_id]";
        public const string USP_UI_GET_TRN_ODS_SUGGESTION_BY_CASE_ID = "[dbo].[usp_ui_get_trn_ods_suggestion_by_case_id]";
        public const string USP_UI_ADD_TRN_ODS_SUGGESTION = "[dbo].[usp_ui_add_trn_ods_suggestion]";
        public const string USP_UI_DELETE_TRN_ODS_SUGGESTION = "[dbo].[usp_ui_delete_trn_ods_suggestion]";
        public const string USP_CCP_UPDATE_ALL_DATA = "[dbo].[usp_ccp_update_all_data]";
        public const string USP_ADM_GET_PLANT_DETAILS_BY_USER = "[usp_adm_get_plant_details_by_user]";
        public const string USP_GET_CCP_AFFECTED_MODEL_IDS_BY_TAG_ID = "[dbo].[usp_get_ccp_affected_model_ids_by_tag_id]";
        public const string USP_ADM_CCP_INFO = "[dbo].[usp_adm_ccp_info]";//not in use as it returns json so created usp_ui_get_ccp_info
        public const string USP_UI_GET_CCP_INFO = "[dbo].[usp_ui_get_ccp_info]";
        public const string USP_UI_GET_PIPELINE_MACROS_BY_CASE_ID = "[dbo].[usp_ui_get_pipeline_macros_by_case_id]";
        public const string USP_UI_GET_MST_PIPELINE_MACROS = "[dbo].[usp_ui_get_mst_pipeline_macros]";
        public const string USP_UI_UPDATE_PIPELINE_MACROS = "[dbo].[usp_ui_update_pipeline_macros]";
        public const string USP_UI_GET_SWITCH_CONFIGURATIONS = "[dbo].[usp_ui_get_switch_configurations]";

        // CCP Update CCP Tag Data
        public const string USP_ADM_UPSERT_CCP_DATA = "[dbo].[usp_ui_upsert_ccp_data]";
        //CCP --> CaseDetails 
        public const string USP_UI_GET_CASE_CASEDETAILS_BY_USER = "[dbo].[usp_ui_get_case_casedetails_by_user]";
        public const string USP_UI_UPDATE_CASE_CASEDETAILS = "[dbo].[usp_ui_update_case_casedetails]";
        public const string USP_UI_DELETE_CASE_CASEDETAILS = "[dbo].[usp_ui_delete_case_casedetails]";
        public const string USP_UI_ADD_CASE_CASEDETAILS = "[dbo].[usp_ui_add_case_casedetails]";
        public const string USP_UI_EO_GET_TAGS_DATA_BY_CASEID = "[dbo].[usp_ui_eo_get_tags_data_by_caseid]";
        public const string USP_UI_EO_GET_TAGS_DATA_FOR_VALIDATION = "[dbo].[usp_ui_eo_get_tag_data_for_validation]";

        //CCP EO
        public const string USP_UI_GET_OPTIMIZER_VARIABLES = "[dbo].[usp_ui_eo_get_optimizer_variables]";
        public const string USP_UI_GET_OPTIMIZER_PRAMETERS = "[dbo].[usp_ui_eo_get_optimizer_parameter]";
        public const string USP_UI_EO_ADD_OPTIMIZER_OBJECTIVE_FUNCTION = "[dbo].[usp_ui_eo_add_optimizer_objective_function]";
        public const string USP_UI_EO_ADD_OPTIMIZER_DERIVED_EQUATION = "[dbo].[usp_ui_eo_add_optimizer_derived_equations]";
        public const string USP_UI_EO_ADD_OPTIMIZER_VARIABLE = "[dbo].[usp_ui_eo_add_optimizer_variables]";
        public const string USP_UI_EO_ADD_OPTIMIZER_CONSTRAINT = "[dbo].[usp_ui_eo_add_optimizer_constraints]";
        public const string USP_UI_EO_UPDATE_OPTIMIZER_PARAMETER = "[dbo].[usp_ui_eo_update_optimizer_parameter]";
        public const string USP_UI_EO_ADD_TAG = "[dbo].[usp_ui_eo_add_tag]";
        public const string USP_UI_EO_UPDATE_TAG = "[dbo].[usp_ui_eo_update_tag]";

        public const string USP_UI_EO_DELETE_OPTIMIZER_DERIVED_EQUATIONS = "[dbo].[usp_ui_eo_delete_optimizer_derived_equations]";
        public const string USP_UI_EO_DELETE_OPTIMIZER_VARIABLE = "[dbo].[usp_ui_eo_delete_optimizer_variable]";
        public const string USP_UI_EO_DELETE_OPTIMIZER_CONSTRAINT = "[dbo].[usp_ui_eo_delete_optimizer_constraint]";
        public const string USP_UI_EO_DELETE_OPTIMIZER_PARAMETER = "[dbo].[usp_ui_eo_delete_optimizer_parameter]";
        public const string USP_UI_EO_GET_OPTIMIZER_CONSTRAINTS_CATEGORY = "[dbo].[usp_ui_eo_get_optimizer_Constraints_Category]";
        public const string USP_UI_EO_GET_BLOCKS = "[dbo].[usp_ui_eo_get_block_details]";
        //Optimizer
        public const string USP_UI_EO_GET_MODEL_NAMES_BY_CASE_ID = "[dbo].[usp_ui_eo_get_model_names_by_case_id]";
        public const string USP_UI_EO_DELETE_TAG = "[dbo].[usp_ui_eo_delete_tag]";
        public const string USP_UI_EO_UPDATE_EQUIPMENTAVAILIABILITY = "[dbo].[usp_ui_eo_update_config_equipment_availability]";
        public const string USP_UI_EO_GET_EQUIPMENTAVAILIABILITY = "[dbo].[usp_ui_eo_get_config_equipment_availability]";
        public const string USP_UI_EO_UPDATE_OPTIMIZATION_PRICE_INPUT = "[dbo].[usp_ui_eo_update_optimization_price_input]";

        #region Old Solution Stored Procedures
        //Config
        public const string UI_GET_CASEHIERACHY = "[dbo].[usp_ui_get_casehierachy]";
        public const string USP_GET_MST_UOM = "[dbo].[usp_get_mst_uom]";

        public const string UI_GET_LANDINGAFFILIATE = "[dbo].[usp_ui_get_landing_affiliate]";
        public const string UI_GET_LANDINGCORPORATE = "[dbo].[usp_ui_get_landing_corporate]";
        public const string UI_GET_PLANT_SCORE_CARD_DATA = "[dbo].[usp_ui_get_plant_score_card_data]";
        public const string USP_UI_GET_DOWNLOAD_TAG_LIST = "usp_ui_get_download_tag_list";
        public const string USP_UI_GET_DOWNLOAD_DATA = "usp_ui_get_download_data";
        public const string USP_UI_GET_SOP_GRADE_CHANGE = "[dbo].[usp_ui_get_sop_grade_change]";
        public const string USP_UI_GET_SOP_GRADE_CHANGE_BY_CASEID = "[dbo].[usp_ui_get_sop_grade_change_by_caseid]";
        public const string USP_UI_GET_PLANT_ID_BY_CASE_ID = "[dbo].[usp_ui_get_plantID_by_caseID]";
        public const string USP_UI_GET_PLANT_ID_BY_VC_SPAN_ID = "[usp_ui_get_plant_id_for_vc_span_id]";
        public const string USP_UI_GET_PLANT_ID_BY_CAUSETAG_ID = "[dbo].[usp_ui_get_plantID_by_causeTagID]";
        public const string USP_UI_GET_PLANT_ID_BY_TAG_ID = "[dbo].[usp_ui_get_plant_id_by_tag_id]";
        public const string USP_UI_GET_PLANT_ID_BY_MODEL_ID = "[dbo].[usp_ui_get_plant_id_by_model_id]";
        public const string USP_UI_GET_TAG_DATA_FOR_UPDATE = "[dbo].[usp_adm_get_tag_data_for_update]";
        public const string USP_UPDATE_TAG_DATA_DETAILS = "[dbo].[usp_adm_update_tag_details]";
        public const string USP_UI_GET_TAGS_DATA_BY_CASE_ID = "[dbo].[usp_ui_get_tags_data_by_caseid]";
        public const string USP_UI_GET_VIEW_DATA_DICTIONARY_BY_TABLENAME = "[dbo].[usp_ui_get_view_data_dictionary_by_tablename]";
        public const string USP_UI_GET_PIPELINE_LOCATIONS = "[dbo].[usp_ui_get_pipeline_locations]";
        public const string USP_UI_GET_PACKET_TYPES_BY_CASE_ID = "[dbo].[usp_ui_get_clean_data_ranges_packet_types_by_caseid]";

        //Accounts
        // Authentication Related Data
        public const string USP_ADM_GET_DATA_FOR_AUTHENTICATION = "[dbo].[usp_adm_get_data_for_authentication_by_user_id]";
        public const string USP_ADM_GET_VALIDATION_DATA_FOR_ROLE_ADDITION = "[dbo].[usp_adm_get_validation_data_for_role_addition]";
        public const string USP_ADM_GET_TOKEN_AUTHORIZATION_DATA = "[dbo].[usp_adm_get_token_authorization_data]";

        //Accounts.Claims
        public const string ADM_GET_CLAIMSBYUSERID = "[dbo].[usp_adm_get_claims_by_user_id]";
        public const string UI_GET_VALIDCASEIDSCOUNT = "[dbo].[usp_ui_get_valid_case_ids]";

        //Accounts For Plant Based Access:
        public const string USP_ADM_GET_PLANT_BASED_CLAIMS = "[dbo].[usp_adm_get_claims_data_by_user_id]";

        //Accounts.Claims New Requirement
        public const string ADM_ADD_CLAIMS_TO_USERS = "[dbo].[usp_adm_add_claim_to_users]";
        public const string ADM_DELETE_CLAIMBYUSERID = "[dbo].[usp_adm_delete_user_claims]";
        public const string ADM_GET_VALID_CLAIMS = "[dbo].[usp_adm_get_valid_claims]";

        //Accounts.Roles
        public const string UI_POST_ADDROLETOUSERS = "[dbo].[usp_adm_add_role_to_users]";
        public const string UI_GET_ROLEDETAILS = "[dbo].[usp_adm_get_role_details]";
        public const string ADM_ADD_ROLEBYUSERID = "[dbo].[usp_adm_add_user_role]";
        public const string ADM_DELETEUSERROLE = "[dbo].[usp_adm_delete_user_role]";
        public const string ADM_DELETEUSERROLEANDCLAIMS = "[dbo].[usp_adm_delete_user_role_claims]";
        public const string UI_GET_VALIDROLE = "[dbo].[usp_ui_get_valid_role]";

        //Accounts Validation
        public const string UI_GET_VALID_MODEL_IDs_BY_CASEID = "[dbo].[usp_ui_get_valid_model_ids_by_case_id]";

        //Accounts.UserData
        public const string ADM_GET_ROLESBYUSERID = "[dbo].[usp_adm_get_role_by_user_id]";
        public const string ADM_GET_ROLEROLEIDSBYUSERID = "[dbo].[usp_adm_get_role_role_id_by_user_id]";
        public const string ADM_GET_STATIC_DATA_BY_SESSION_ID = "[dbo].[usp_adm_get_static_data_by_session_id]";
        public const string ADM_GET_DYNAMIC_DATA_BY_SESSION_ID = "[dbo].[usp_adm_get_dynamic_data_by_session_id]";

        //Admin.ErrorLogging
        public const string ADM_MODIFY_STATUS_IN_ERROR_LOGGING = "[dbo].[usp_adm_modify_status_in_error_logging]";
        public const string USP_UI_VALID_ERROR_STATUS = "[dbo].[usp_ui_get_valid_error_status]";

        //Accounts.New.Login.Session
        public const string ADM_GET_LATEST_LOGIN_SESSION_BY_USER = "[dbo].[usp_adm_get_latest_login_session_by_user]";
        //Accounts.New.Login.Session
        public const string ADM_GET_LATEST_LOGIN_SESSION_BY_SESSION = "[dbo].[usp_adm_get_latest_login_session_by_session]";
        //Accounts.New.Login.Session
        public const string ADM_GET_LATEST_TOKEN = "[dbo].[usp_adm_get_latest_token]";
        //Accounts.New.Logout.EndSession
        public const string ADM_LOGOUT_AND_END_SESSION_BY_USER = "[dbo].[usp_adm_logout_and_end_session_by_user]";
        //Accounts.New.EndAllSessions
        public const string ADM_END_ALL_PREVIOUS_SESSIONS_BY_USER = "[dbo].[usp_adm_end_all_sessions_by_user]";
        //Accounts.New.DeactivateAllTokens
        public const string ADM_DEACTIVATE_ALL_TOKENS_BY_USER = "[dbo].[usp_adm_cancel_all_tokens_by_user]";
        //Accounts.New.AddUserInCustomTable
        public const string ADM_ADD_USER_IN_CUSTOM_USER_TABLE = "[dbo].[usp_adm_add_user_in_custom_user_details]";
        //Accounts.New.FetchUsers
        public const string ADM_GET_USER_BY_DOMAIN_LOGIN_ID = "[dbo].[usp_adm_get_user_by_domain_login_id]";
        public const string ADM_GET_USER_BY_EMPLOYEE_ID = "[dbo].[usp_adm_get_user_by_employee_id]";
        public const string ADM_SEARCH_USER_BY_KEYWORD = "[dbo].[usp_adm_search_user_by_keyword]";
        public const string ADM_GET_USER_BY_EMPLOYEE_ID_LIST = "[dbo].[usp_adm_get_user_details_by_employeeIdList]";
        public const string ADM_GET_USER_COUNT_BY_EMPLOYEE_ID_LIST = "[dbo].[usp_adm_get_user_count_by_employeeIdList]";
        public const string ADM_GET_USERS_BY_ROLE = "[dbo].[usp_adm_get_user_by_role]";
        public const string ADM_GET_MODEL_DETAILS_BY_CASE_ID_LIST = "[dbo].[usp_ds_get_model_details_by_caseid_list]";
        public const string ADM_GET_MODEL_PERFORMANCE_TREND_BY_MODEL_ID = "[dbo].[usp_ds_get_model_performance_trend_by_model_id]";
        public const string ADM_GET_TAG_DATA_FOR_VALIDATION = "[dbo].[usp_adm_get_tag_data_for_validation]";
        public const string ADM_GET_DATA_LBM_ITERATIONS = "[dbo].[usp_adm_get_data_lbm_iterations]";
        public const string ADM_UPDATE_LBM_ITERATIONS = "[dbo].[usp_adm_update_lbm_iteration]";
        //Accounts Workflow User Manangement
        public const string ADM_GET_WORKFLOW_USERS_BY_ROLE = "[dbo].[usp_adm_workflow_get_users_by_role]";
        public const string ADM_ADD_WORKFLOW_USER_TO_ROLE = "[dbo].[usp_adm_workflow_add_role_to_users]";
        public const string ADM_DELETE_WORKFLOW_USER_BY_ROLE = "[dbo].[usp_adm_workflow_delete_user_role]";


        //CURRENT
        public const string UI_GET_DATATRENDTAGNAME = "[dbo].[usp_ui_get_data_datatrend_tag_name]";
        public const string UI_GET_CONTRIBUTOROUTPUT = "[dbo].[usp_ui_get_contributor_output]";
        public const string UI_GET_KPIOUTPUT = "[dbo].[usp_ui_get_kpi_output]";
        public const string UI_GET_INSIGHTSOUTPUT = "[dbo].[usp_ui_get_insights_output]";
        public const string UI_GET_SYSTEMTOPTILEOUTPUT = "[dbo].[usp_ui_get_system_tiledata]";
        public const string UI_GET_TIMEOPTIMUMACTUAL = "[dbo].[usp_ui_get_timeoptimumactual]";
        public const string UI_GET_MONITORINGDATA = "[dbo].[usp_ui_get_monitoring_data]";
        public const string UI_GET_OVERVIEWTREND = "[dbo].[usp_ui_get_overview_trend_data]";
        public const string UI_GET_STATUSOPTIMUMBYACTUALTIME = "[dbo].[usp_ui_get_status_optimum_by_actual_time]";
        public const string UI_GET_ASSETSTATUS = "[dbo].[usp_ui_get_asset_status]";
        public const string UI_GET_TIME_ACTUAL_FOR_ALL_CASES = "[dbo].[usp_ui_get_time_actual_for_all_cases]";
        public const string UI_GET_TREEDIAGRAMBYCASEID = "[dbo].[usp_ui_get_tree_diagram_by_case_id]";
        public const string UI_GET_TIME_ACTUAL_BY_CASE_ID_LIST = "[dbo].[usp_ui_get_time_actual_by_case_id_list]";

        //LOGGING.ADD
        public const string ADM_ADD_APIPERFORMANCELOG = "[dbo].[usp_adm_add_api_performance_log]";
        public const string ADM_ADD_ACTIVITY_TRACKER_DATA = "[dbo].[usp_adm_add_activity_tracker]";
        public const string ADM_ADD_PERFORMANCE_LOG_DATA = "[dbo].[usp_adm_add_performance_logs]";
        public const string ADM_ADD_ERROR_LOG_DATA = "[dbo].[usp_adm_add_error_logs]";
        public const string ADM_ADD_USER_ACTIVITY_DATA = "[dbo].[usp_adm_add_Log_useractivitytracker]";

        //LOGGING.INSERT REWIRED
        public const string ADM_ADD_USER_SESSION = "[dbo].[usp_adm_add_user_session]";
        public const string ADM_ADD_USER_LOGIN = "[dbo].[usp_adm_add_user_login]";
        public const string ADM_ADD_USER_TOKEN = "[dbo].[usp_adm_add_user_token]";

        //LOGGING.GET REWIRED
        public const string ADM_GET_ERROR_TRACKING_LOGS = "[dbo].[usp_adm_get_log_trackingerrorlogs]";
        public const string ADM_GET_LOGIN_ACTIVITY_LOGS = "[dbo].[usp_adm_get_log_loginactivity]";
        public const string ADM_GET_QUERY_TRACKER_LOGS = "[dbo].[usp_adm_get_log_querytracker]";
        public const string ADM_GET_ACTIVITY_TRACKER_LOGS = "[dbo].[usp_adm_get_log_activitytracker]";
        public const string ADM_GET_PERFORMANCE_LOGS = "[dbo].[usp_adm_get_log_performance]";
        public const string ADM_GET_API_REQUEST_LOGS = "[dbo].[usp_adm_get_log_apirequest]";
        public const string ADM_GET_ADM_SLOWNESS_DATA = "[dbo].[usp_adm_get_slowness_data]";
        public const string ADM_GET_ADM_FAILURE_DATA = "[dbo].[usp_adm_get_failure_data]";
        public const string ADM_GET_AUDIT_LOGS = "[dbo].[usp_adm_get_log_auditlog]";
        public const string USP_UI_GET_AUDIT_TYPE = "[dbo].[usp_ui_get_all_audit_activity_type]";
        public const string USP_ADM_ADD_AUDIT_LOG = "[dbo].[usp_adm_add_audit_log]";
        public const string USP_ADM_GET_DEFAULT_VALUE = "[dbo].[usp_adm_get_default_value]";

        //ODS
        public const string USP_UI_GET_ODS_ALERT_STATISTICS_DOWNLOAD_DATA_COMMENTS = "[dbo].[usp_ui_get_ods_alert_statistics_download_data_comments]";
        public const string USP_UI_GET_ODS_DATA_BY_CASE_ID_LIST_TIME_RANGE_REQ_ID = "[dbo].[usp_ui_get_ods_data_by_case_id_list_time_range_req_id]";
        public const string UI_GET_GETODSKPITAGBYCASEID = "[dbo].[usp_ui_get_ods_kpi_tag_by_case_id]";
        public const string UI_GET_ODS_ALERT_STATISTICS_BY_CASE_ID_LIST = "[dbo].[usp_ui_get_ods_alert_statistics_by_case_id_list]";
        public const string UI_GET_ODS_ALERT_STATISTICS_FOR_ROLE = "[dbo].[usp_ui_get_ods_alert_statistics_for_role]";
        public const string USP_UI_GET_ODS_ALERT_STATISTICS_PENDING_ALERTS = "[dbo].[usp_ui_get_ods_alert_statistics_pending_alerts]";
        public const string USP_UI_GET_ODS_ALERT_STATISTICS_OVERDUE_ALERTS = "[dbo].[usp_ui_get_ods_alert_statistics_overdue_alerts]";
        public const string USP_UI_GET_ODS_ALERT_STATISTICS_INPROGRESS_ALERTS = "[dbo].[usp_ui_get_ods_alert_statistics_inprogress_alerts]";
        public const string USP_UI_GET_ODS_ALERT_STATISTICS_UTILIZATION_REPORT = "[dbo].[usp_ui_get_ods_alert_statistics_utilization_report]";
        public const string USP_UI_GET_ODS_ALERT_STATISTICS_TARGETMODIFIED_ALERTS = "[dbo].[usp_ui_get_ods_alert_statistics_targetModified_alerts]";
        public const string USP_UI_GET_ODS_ALERT_STATITICS_CLOSED_ALERTS = "[dbo].[usp_ui_get_ods_alert_statistics_closed_alerts]";
        public const string USP_UI_GET_ODS_TREND_DATA_BY_REQUEST_ID = "[dbo].[usp_ui_get_ods_trend_data_by_request_id]";
        public const string USP_UI_GET_ODS_ALERT_STATISTICS_DOWNLOAD_DATA = "[dbo].[usp_ui_get_ods_alert_statistics_download_data]";
        public const string USP_UI_GET_ODS_OVERVIEW_BY_CASE_ID_TIME = "[dbo].[usp_ui_get_ods_overview_by_case_id_time]";
        public const string USP_UI_UPDATE_MUTE_ALERTS_LOGS_BY_CAUSEID = "[dbo].[usp_ui_update_mutealertslog_by_causeid]";
        public const string USP_UI_GET_MUTE_ALERTS_LOGS = "[dbo].[usp_ui_get_mutealertslog]";
        public const string USP_ODS_UPDATE_PEODSAlertDetails = "[workflow].[usp_ods_update_PEODSAlertDetails]";
        public const string USP_ODS_GET_NEW_EMAIL = "[workflow].[usp_ods_get_email]";
        public const string USP_ODS_UPDATE_EMAIL_LOGS = "[dbo].[usp_ods_update_email_logs]";

        //AIHUB
        public const string UI_GET_AIHUBCASEJOBDATA = "[dbo].[usp_ui_get_aihub_case_job_data]";
        public const string UI_GET_AIHUB_ERROR_DETAILS = "[dbo].[usp_ui_get_aihub_error_log_by_caseID]";

        public const string UI_GET_GetAvailablePITimeTag = "[dbo].[usp_ui_get_available_pi_time_tag]";
        public const string UI_GET_GetAllAvailablePITimeTag = "[dbo].[usp_ui_get_all_available_pi_time_tag]";

        //QueryTracker
        public const string ADM_ADD_QUERY_TRACKER = "[dbo].[usp_adm_add_query_tracker]";

        //Value Creation
        public const string USP_UI_GET_ALL_MST_VALUE_CREATION_ACTION_BY_CASEID = "[dbo].[usp_ui_get_all_mst_vc_action_by_caseid]";
        public const string USP_UI_ADD_MST_VALUE_CREATION_ACTION_DATA = "[dbo].[usp_ui_add_mst_vc_action]"; // Not referred        
        public const string USP_UI_ADD_VALUE_CREATION_SPAN_DATA = "[dbo].[usp_ui_add_vc_span]";
        public const string USP_UI_GET_VALUE_CREATION_SPAN_DATA_BY_CASE_ID = "[dbo].[usp_ui_get_all_vc_span_by_caseid]";
        public const string USP_UI_GET_VALUE_CREATION_SPAN_CALC_TIMESERIES = "[dbo].[usp_ui_get_vc_calc_timeseries]";
        public const string USP_UI_DELETE_VALUE_CREATION_SPAN_ACTION_ID = "[dbo].[usp_ui_delete_vc_span_by_id]";
        public const string USP_UI_ADD_TRN_VALUE_CREATION_SPAN_ACTION_DATA = "[dbo].[usp_ui_add_trn_vc_spanaction]"; // Not referred
        public const string USP_UI_GET_ALL_TRN_VALUE_CREATION_SPAN_ACTION_DATA = "[dbo].[usp_ui_get_all_trn_vc_spanaction]"; // Not referred
        public const string USP_UI_DELETE_TRN_VALUE_CREATION_SPAN_ACTION = "[dbo].[usp_ui_delete_trn_vc_spanaction]"; // Not referred
        public const string USP_UI_GET_ALL_MST_VALUE_CREATION_CASE_INFO_ACTION_DATA = "[dbo].[usp_ui_get_all_mst_vc_caseInfo]";
        public const string USP_UI_GET_VC_BY_CASE_ID_LIST = "[dbo].[usp_ui_get_vc_by_case_Id_list]";
        public const string USP_UI_GET_VC_SPAN_ALERTS = "[dbo].[usp_ui_get_vc_span_alerts]";
        public const string USP_UI_GET_CASE_ID_FOR_VC_SPAN_ID = "[dbo].[usp_ui_get_case_id_for_vc_span_id]";

        // Workflow
        public const string USP_UI_GET_WORKFLOW_ROLES = "[dbo].[usp_adm_get_workflow_roles]";
        public const string USP_ADM_GET_VALID_WORKFLOW_ROLES = "[dbo].[usp_adm_get_valid_workflow_roles]";
        public const string USP_UI_GET_WF_PROCESS_INSTANCE_ERRORS_MAIL = "[dbo].[usp_ui_get_wf_process_instance_errors_mail]";
        public const string USP_ADM_WORKFLOW_ADD_MUTE_ALERTS_INFO = "[dbo].[usp_adm_workflow_add_mute_alerts_info]";
        public const string USP_ADM_WORKFLOW_GET_MUTE_ALERTS_INFO = "[dbo].[usp_adm_workflow_get_mute_alerts_info]";
        public const string USP_UI_GET_ODS_WORKFLOW_ACTION_LOGS = "[dbo].[usp_ui_get_wf_action_logs_by_req_id]";
        public const string USP_UI_GET_WF_ASSIGNED_ALERT_LIST_BY_USERID = "[dbo].[usp_ui_get_wf_assigned_alert_list_by_userid]";
        public const string USP_UI_GET_ODS_ACTION_SUGGESTIONS = "[dbo].[usp_ui_get_wf_action_suggestions]";
        public const string USP_UI_GET_ODS_ASSIGNEE_LIST = "[dbo].[usp_ui_get_wf_assignee_list_by_req_id]";
        public const string USP_UI_GET_ODS_ASSIGNEE = "[dbo].[usp_ui_get_wf_assignee_by_req_id]";
        public const string USP_UI_ADD_ODS_WORKFLOW_ACTION = "[dbo].[usp_ui_add_wf_action]";
        public const string USP_UI_GET_ODS_DATA = "[dbo].[usp_ui_get_wf_data_by_req_id]";
        public const string USP_UI_GET_WF_ALERT_HISTORICAL_DATA_ALL_USERS = "[dbo].[usp_ui_get_wf_alert_historical_data_all_user]";
        public const string USP_UI_GET_WF_ALERT_HISTORICAL_DATA = "[dbo].[usp_ui_get_wf_alert_historical_data_PE]";
        public const string USP_UI_GET_WORKFLOW_CONFIGURATIONS = "[dbo].[usp_ui_get_workflow_configurations]";
        public const string USP_UI_UPDATE_WF_ODS_SUBMIT_STATUS = "[dbo].[usp_ui_update_wf_ods_submitting_status]";
        public const string USP_UI_UPDATE_WORKFLOW_CONFIGURATIONS = "[dbo].[usp_ui_update_workflow_configurations]";
        public const string USP_ADM_WORKFLOW_GET_PM_DELEGATIONINFO = "[dbo].[usp_adm_workflow_get_PM_delegationinfo]";
        public const string USP_ADM_WORKFLOW_UPDATE_PM_DELEGATIONINFO = "[dbo].[usp_adm_workflow_update_PM_delegationinfo]";
        public const string USP_ADM_GET_PM_DELEGATION_INFO_BY_EMPLOYEE_ID = "[dbo].[usp_adm_workflow_get_pm_delegation_info_by_employee_id]";
        public const string USP_UI_ODS_CHECK_SEND_EMAIL = "[dbo].[usp_ods_check_send_email]";
        public const string USP_UI_ODS_CHECK_AUTO_CLOSURE_BY_REQ_ID = "[workflow].[usp_ods_check_auto_closure_by_req_id]";
        public const string USP_ODS_PEODSVALIDATEASSIGNEEBYREQUESTID = "[workflow].[usp_ods_PEODSValidateAssigneeByRequestId]";
        public const string USP_DIRECT_ALERT_ASSIGNMENT = "[workflow].[usp_direct_alert_assignment]";
        public const string USP_UI_GET_WF_CUMULATIVE_LOST_OPPORTUNITY_TREND_DATA_BY_REQUEST_ID = "[dbo].[usp_ui_get_wf_cumulative_lost_opportunity_trend_data_by_request_id]";
        public const string USP_UI_GET_TERMINATED_INSTANCES_LOG_RESPONSE = "[dbo].[usp_ui_get_terminated_instances_log]";
        public const string USP_ODS_ADD_TERMINATED_INSTANCE_LOG = "[dbo].[usp_ods_add_eeods_terminated_instance_log]";
        public const string USP_UI_GET_WF_HANDLING_REASONS = "[dbo].[usp_ui_get_wf_handling_reasons]";
        public const string USP_UI_GET_WF_DELEGATION_MAIL = "[dbo].[usp_ui_get_wf_delegation_mail]";

        //Virtual Engg
        public const string USP_UI_GET_VE_DATA_BY_MODELID = "[dbo].[usp_ve_get_data]";
        public const string USP_UI_GET_VE_MODEL_BY_CASEID = "[dbo].[usp_ve_get_model_by_case_id]";
        public const string USP_UI_GET_VE_MODEL_BY_MODELID_LIST = "[dbo].[usp_ve_get_model_by_model_id_list]";

        //Infra job status
        public const string USP_ADD_TRN_INFRA_MONITORING = "[dbo].[usp_add_trn_infra_monitoring]";
        public const string USP_ADD_PI_DATA_INFRA_MONITORING = "[dbo].[usp_add_pi_data_infra_monitoring]";
        public const string USP_GET_MST_INFRA_MONITORING = "[dbo].[usp_get_mst_infra_monitoring]";
        public const string USP_GET_INFRA_MONITORING_CONNECTIVITY = "[dbo].[get_infra_monitoring_connectivity]";
        public const string USP_GET_INFRA_MONITORING_CASEWISE = "[dbo].[get_infra_monitoring_casewise]";
        public const string USP_GET_INFRA_MONITORING_CASEWISE_TREND = "[dbo].[get_infra_monitoring_casewise_trend]";
        public const string USP_GET_PI_DATA_INFRA_MONITORING_LAG_TREND = "[dbo].[get_pi_data_infra_monitoring_lag_trend]";        
        public const string USP_UPDATE_MST_INFRA_MONITORING = "[dbo].[usp_update_mst_infra_monitoring]";

        //ECM
        public const string USP_UI_ADD_TRN_ATTACHMENTS = "[dbo].[usp_ui_add_trn_attachments]";
        public const string USP_UI_GET_TRN_ATTACHMENTS = "[dbo].[usp_ui_get_trn_attachments]";
        public const string USP_GET_ECM_NODEID_BY_CASEID = "[dbo].[usp_get_ecm_nodeId_by_caseId]";
        
        //Optimizer
        public const string USP_UI_EO_GET_OPTIMIZER_CONSTRAINTS = "[dbo].[usp_ui_eo_get_optimizer_Constraints]";
        public const string USP_UI_EO_GET_OPTIMIZER_VARIABLES = "[dbo].[usp_ui_eo_get_optimizer_variables]";
        public const string USP_UI_EO_GET_OPTIMIZER_PARAMETER = "[dbo].[usp_ui_eo_get_optimizer_parameter]";
        public const string USP_UI_EO_GET_OPTIMIZER_DERIVED_EQUATIONS = "[dbo].[usp_ui_eo_get_optimizer_derived_equations]";
        public const string USP_UI_EO_GET_OPTIMIZER_OBJECTIVE_FUNCTION = "[dbo].[usp_ui_eo_get_optimizer_objective_function]";
        #endregion

    }

}
