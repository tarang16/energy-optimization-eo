﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Common
{
    [ExcludeFromCodeCoverage]
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]

   public class DynamicMaxLengthAttribute : ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            if (value == null) return true;
            var stringValue = value.ToString();
            return stringValue!.Length <= ValidationSettings.maxTextLength;
        }

        public override string FormatErrorMessage(string name)
        {
            return $"The field {name} must be a string with a maximum length of {ValidationSettings.maxTextLength}.";
        }
    }
}
