﻿using Microsoft.Extensions.Hosting;
using System;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Common
{
    /// <summary>
    /// Used to hold constant values that can be used anywhere in the project
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class Constants
    {
        //Regular Expression
        public const string NUMERIC_TEXT_REGULAR_EXPRESSION = @"^[0-9]+$";
        public const int role1 = 1;
        public const int role2 = 2;
        public const string ENGLISH_ARABIC_TEXT_REGULAR_EXPRESSION = @"^[A-Za-z\u0621-\u064A 0-9]+$";
        public const string ENGLISH_ARABIC_DESCRIPTION_REGULAR_EXPRESSION = "^[A-Za-z\u0621-\u064A 0-9 ؟&()-`.,\"' ]*$";

        public const string ARABIC_TEXT_ONLY_REGULAR_EXPRESSION = "^[\u0621-\u064A ؟&()-`.,\"'  \r\n]+$";
        public const string ENGLISH_TEXT_ONLY_REGULAR_EXPRESSION = "^[A-Za-z0-9 ؟&()-`.,\"'  \r\n]+$";

        public const string ARABIC_TEXT_REGULAR_EXPRESSION = @"^[\u0621-\u064A 0-9]+$";
        public const string ARABIC_DESCRIPTION_REGULAR_EXPRESSION = "^[\u0621-\u064A 0-9 ؟&()-`.,\"' ]*$";

        public const string ENGLISH_TEXT_REGULAR_EXPRESSION = @"^[A-Za-z0-9 ]+$";
        public const string ENGLISH_DESCRIPTION_REGULAR_EXPRESSION = "^[A-Za-z0-9 ؟&()-`.,\"' ]*$";

        public const string RESOURCE_ARABIC_TEXT_REGULAR_EXPRESSION = @"^[\u0621-\u064A 0-9 ()]+$";
        public const string RESOURCE_ENGLISH_TEXT_REGULAR_EXPRESSION = @"^[A-Za-z0-9 ()]+$";

        public const string EMAIL_REGULAR_EXPRESSION = @"^([0-9a-zA-Z]([\+\-_\.][0-9a-zA-Z]+)*)+@(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]*\.)+[a-zA-Z]{2,17})$";

        public const string ARABIC_TEXT_REGULAR_EXPRESSION_USRMGMT_FNAR = @"^[\u0621-\u064A 0-9]+[\u0621-\u064A 0-9 \-\,\.]*$";
        public const string ENGLISH_TEXT_REGULAR_EXPRESSION_USRMGMT_FN = @"^[A-Za-z0-9 ]+[A-Za-z0-9 \-\,\.]*$";


        public const string AlphaNumeric_regex = @"^[a-zA-Z0-9 _,-]*$";
        public const string ENGLISH_TEXT_WITH_EXTRA_REGULAR_EXPRESSION = @"^[A-Za-z0-9 _,-\\\+\(\)&°.]*$";
        public const string ENGLISH_TEXT_WITH_LIMITED_REGULAR_EXPRESSION = @"^[%?\*A-Za-z0-9 :_,'+=#\(\)\n\[\]&°.\{\}/<>-]*$";


        public const string NOREPLY_EMAILID = @"noreply-plantefficiency@sabic.com";
        public const string USER_ACCESS_SUBJECT_LINE= "Plant Efficiency ({0}) - User Access Level Change Notification";
        public const string DefaultScenario = "test";
        
        public static string UserAccessSubject(string text)
        {
            return string.Format(USER_ACCESS_SUBJECT_LINE, text.ToUpper());
        }
    }
}
