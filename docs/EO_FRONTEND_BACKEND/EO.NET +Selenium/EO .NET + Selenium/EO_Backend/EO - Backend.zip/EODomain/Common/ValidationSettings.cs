﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Common
{
    [ExcludeFromCodeCoverage]
    public static class ValidationSettings
    {
        public static int maxTextLength { get; set; }
    }
}
