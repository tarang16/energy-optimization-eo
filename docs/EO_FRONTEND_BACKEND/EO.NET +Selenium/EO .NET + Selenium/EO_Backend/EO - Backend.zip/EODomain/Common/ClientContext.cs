﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;

namespace EODomain.Common
{
    [ExcludeFromCodeCoverage]
    public class ClientContext
    {
        [FromHeader(Name = "Sec-Ch-Ua")]
        public string? BrowserName { get; set; }

        [FromHeader(Name = "User-Agent")]
        public string? UserAgent { get; set; }

        [FromHeader(Name = "Accept-Language")]
        public string? Languages { get; set; }

        [FromServices]
        public IHttpContextAccessor? HttpContextAccessor { get; set; }
        public string? RemoteIp => HttpContextAccessor?.HttpContext?.Connection?.RemoteIpAddress?.ToString();
        public string? IpAddress => HttpContextAccessor?.HttpContext?.Connection?.RemoteIpAddress?.ToString();
        public string? LocalIp => HttpContextAccessor?.HttpContext?.Connection?.LocalIpAddress?.ToString();
        public string? UrlRequested => HttpContextAccessor?.HttpContext?.Request?.ToString();

    }

}
