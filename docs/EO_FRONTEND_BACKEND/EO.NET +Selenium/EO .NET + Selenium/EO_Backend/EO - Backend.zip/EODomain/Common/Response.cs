﻿namespace EODomain.Common
{
   /// <summary>
   /// Base Response
   /// </summary>
   /// <typeparam name="T"></typeparam>
    public class Response<T>
    {
        public Response()
        {
        }

        /// <summary>
        /// Commpleted
        /// </summary>
        /// <param name="resultdata"></param>
        public Response(T resultdata)
        {
            statuscode = 200;
            errormsg = "";
            data = resultdata;
        }

        /// <summary>
        /// Failed Request
        /// </summary>
        /// <param name="status"></param>
        /// <param name="erMsg"></param>
        /// <param name="resultdata"></param>
        public Response(int status, string erMsg,T resultdata)
        {
            statuscode = status;
            errormsg = erMsg;
            data = resultdata;
        }

        public T? data { get; set; }
        public string? errormsg { get; set; }
        public int statuscode { get; set; }
    }

    public class PaginatedResponse<T>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="resultdata"></param>
        /// <param name="pageNumber"></param>
        /// <param name="pageSize"></param>
        /// <param name="pageCount"></param>
        public PaginatedResponse(T resultdata, int pgNumber, int pgSize, int? pgCount)
        {
            statuscode = 200;
            errormsg = "";
            data = resultdata;
            pageNumber = pgNumber;
            pageSize = pgSize;
            pageCount = pgCount;
        }

        public T? data { get; set; }
        public string? errormsg { get; set; }
        public int statuscode { get; set; }
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
        public int? pageCount { get; set; }
    }


    public class TokenResponse<T>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="resultdata"></param>
        /// <param name="token"></param>
        public TokenResponse(T resultdata, string? newToken)
        {
            statuscode = 200;
            errormsg = "";
            data = resultdata;
            token = newToken;
        }

        public T? data { get; set; }
        public string? errormsg { get; set; }
        public int statuscode { get; set; }
        public string? token { get; set; }
    }
}
