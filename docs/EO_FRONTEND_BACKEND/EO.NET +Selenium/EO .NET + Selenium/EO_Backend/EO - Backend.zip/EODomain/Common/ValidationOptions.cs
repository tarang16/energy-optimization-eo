﻿using System.Diagnostics.CodeAnalysis;

namespace EODomain.Common
{
    [ExcludeFromCodeCoverage]
    public class ValidationOptions
    {
        public int maxTextLength { get; set; }
    }
}
