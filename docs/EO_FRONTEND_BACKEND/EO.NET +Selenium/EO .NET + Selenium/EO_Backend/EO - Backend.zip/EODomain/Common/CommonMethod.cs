﻿using Newtonsoft.Json;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Http;
using EODomain.Models.ValidationModels;
using System.ComponentModel;
using System.Data;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Diagnostics;
using EODomain.Models.ECM;
using Newtonsoft.Json.Linq;
using System.Diagnostics.CodeAnalysis;
using EODomain.Models.Enums;
using System.Globalization;

namespace EODomain.Common
{
    [ExcludeFromCodeCoverage]
    public static class CommonMethod
    {
        /// <summary>
        /// To get username.
        /// </summary>
        /// <param name="claims"></param>
        /// <returns></returns>
        public static string GetUserName(IEnumerable<Claim> claims)
        {
            string user = "";
            user = claims.Where(item => item.Type.Contains("nameidentifier"))
                         .Select(item => item.Value).FirstOrDefault()!;
            return user;
        }


        /// <summary>
        /// To fetch employeeID from claims
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static int GetEmployeeIdFromClaim(HttpContext context)
        {
            var claims = context.User.Identity as ClaimsIdentity;
            Claim? claimUID = claims!.Claims.FirstOrDefault(claim => claim.Type == "uid");
            int createdBy = Convert.ToInt32(claimUID!.Value);
            return createdBy;
        }

        /// <summary>
        /// To get output size.
        /// </summary>
        /// <param name="result"></param>
        /// <returns></returns>
        public static double GetOutputSize(object result)
        {
            var serializedResult = JsonConvert.SerializeObject(result);
            long byteCount = Encoding.UTF8.GetByteCount(serializedResult);

            //this is to Convert bytes to mb 
            double sizeInMB = (double)byteCount / (1024 * 1024);
            return sizeInMB;
        }


        /// <summary>
        /// To check if given start time is earlier than the given eTime.
        /// start time must be an earlier time than the eTime.
        /// </summary>
        /// <param name="sTime"></param>
        /// <param name="eTime"></param>
        /// <returns></returns>
        public static bool IsValidTimeInput(string sTime, string eTime)
        {
            try
            {
                if (sTime == "" && eTime == "")
                {
                    return true;
                }
                if ((sTime != null && eTime != null) && (DateTime.Parse(sTime,CultureInfo.InvariantCulture) > DateTime.Parse(eTime, CultureInfo.InvariantCulture)))
                {
                    return false;
                }
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }


        /// <summary>
        /// To check if the caseIDs in caseIDList are of type INT.
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public static bool IsValidIDType(string caseIDList)
        {
            var caseIDs = caseIDList.Split(",");
            foreach (var caseID in caseIDs)
            {
                bool parseResult = Int32.TryParse(caseID, out _);
                if (!parseResult)
                {
                    return false;
                }
            }
            return true;
        }


        public static bool IsValidSource(IsValidSourceInput request)
        {
            if (request.tokenIp != request.requestIp)
            {
                return false;
            }
            return true;
        }


        public static DataTable ConvertMultipleToDataTable<T>(List<T> list)
        {
            var dataTableMultiple = new DataTable();
            var propertyDescriptorCollectionMultiple = TypeDescriptor.GetProperties(typeof(T));
            for (int i = 0; i < propertyDescriptorCollectionMultiple.Count; i++)
            {
                var propertyDescriptorMultiple = propertyDescriptorCollectionMultiple[i];
                var type = propertyDescriptorMultiple.PropertyType;

                if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                    type = Nullable.GetUnderlyingType(type)!;

                dataTableMultiple.Columns.Add(propertyDescriptorMultiple.Name, type);
            }
            var valuesMultiple = new object[propertyDescriptorCollectionMultiple.Count];
            foreach (T iListItem in list)
            {
                for (int i = 0; i < valuesMultiple.Length; i++)
                {
                    valuesMultiple[i] = propertyDescriptorCollectionMultiple[i].GetValue(iListItem)!;
                }
                dataTableMultiple.Rows.Add(valuesMultiple);
            }
            return dataTableMultiple;
        }

        public static DataTable ConvertSingleToDataTable<T>(T entity)
        {
            var dataTableSingle = new DataTable();
            var propertyDescriptorCollectionSingle = TypeDescriptor.GetProperties(typeof(T));
            for (int i = 0; i < propertyDescriptorCollectionSingle.Count; i++)
            {
                var propertyDescriptorSingle = propertyDescriptorCollectionSingle[i];
                var typeSingle = propertyDescriptorSingle.PropertyType;

                if (typeSingle.IsGenericType && typeSingle.GetGenericTypeDefinition() == typeof(Nullable<>))
                    typeSingle = Nullable.GetUnderlyingType(typeSingle)!;

                dataTableSingle.Columns.Add(propertyDescriptorSingle.Name, typeSingle);
            }
            var valuesSingle = new object[propertyDescriptorCollectionSingle.Count];

            for (int i = 0; i < valuesSingle.Length; i++)
            {
                valuesSingle[i] = propertyDescriptorCollectionSingle[i].GetValue(entity)!;
            }
            dataTableSingle.Rows.Add(valuesSingle);

            return dataTableSingle;
        }


        /// <summary>
        /// To extract sessionID from HttpContext
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static string? GetSessionIDFromContext(HttpContext context)
        {
            var claims = context.User.Identity as ClaimsIdentity;
            Claim? jti = claims!.Claims.FirstOrDefault(claim => claim.Type == "jti");
            string? sessionID = jti == null ? "" : jti.Value.ToString();
            return sessionID;
        }


        /// <summary>
        /// To fetch request body from context
        /// </summary>
        /// <param name="request"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static async Task<string> GetRawBodyAsync(HttpRequest request, Encoding? encoding = null)
        {
            request.Body.Position = 0;
            using var reader = new StreamReader(request.Body, encoding ?? Encoding.UTF8);
            string body = await reader.ReadToEndAsync().ConfigureAwait(false);
            request.Body.Position = 0;

            return body;
        }


        public static string GetDownloadsPath()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
            }
            else
            {
                throw new PlatformNotSupportedException("Operating system not supported");
            }
        }

        /// <summary>
        /// To encode username and password to base64.
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public static String EnCoder(string username, string password)
        {
            string encoded = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1")
                            .GetBytes(username + ":" + password));
            return encoded;
        }

        /// <summary>
        /// To generate a datatable without duplicate rows
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public static DataTable? GetUniqueDataTable(DataTable? dataTable)
        {
            var uniqueRows = dataTable!.AsEnumerable().Distinct(DataRowComparer.Default);
            return uniqueRows != null && uniqueRows.Any() ? uniqueRows.CopyToDataTable() : dataTable;
        }

        /// <summary>
        /// Get name of the current executing method
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.NoInlining)]
        public static string GetCurrentMethod()
        {
            var st = new StackTrace();
            var sf = st.GetFrame(1);
            return sf!.GetMethod()!.Name;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="idArray"></param>
        /// <param name="User"></param>
        /// <returns></returns>
        public static bool ProcessAuthRequest(string[] idArray, ClaimsIdentity user, bool skipAdmin, string claimType)
        {
            var roles = user.Claims
                .Where(c => c.Type == ClaimTypes.Role)
                .Select(c => c.Value)
                .ToList();

            // Admin check
            if (roles.Contains(Roles.admin.ToString()) && !skipAdmin)
            {
                return true;
            }

            // Otherwise: all ids must exist as claims with the given type
            return idArray
                .Where(id => !string.IsNullOrEmpty(id))
                .All(id => user.Claims.Any(c => c.Type == claimType && c.Value == id));
        }


       
        /// <summary>
        /// Generic method to extract propeties from json into a modeled collection
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public static List<T> GetDetailsFromJson<T>(string jsonResponse, string jsonPhrase) where T : new()
        {
            List<T> resultModel = new List<T>();
            var json = JObject.Parse(jsonResponse);
            var results = json[jsonPhrase];

            foreach (var result in results!)
            {

                var properties = result?["data"]?["properties"];

                // Create a new instance of T
                T model = new T();

                // Manually map the properties from model to T using reflection
                var ecmFileInfo = new EcmFileInfo
                {
                    Id = properties?["id"]?.ToString(),
                    file_name = properties?["name"]?.ToString(),
                    file_type = properties?["mime_type"]?.ToString(),
                    file_size = properties?["size_formatted"]?.ToString()
                };

                // Copy matching properties from a model to T using reflection
                foreach (var prop in typeof(T).GetProperties())
                {
                    var ecmProp = typeof(EcmFileInfo).GetProperty(prop.Name);
                    if (ecmProp != null && prop.CanWrite)
                    {
                        var value = ecmProp.GetValue(ecmFileInfo);
                        prop.SetValue(model, value);
                    }
                }
                resultModel.Add(model);
            }
            return resultModel;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static bool IsWorkflowActionAllowed(HttpContext context, int? affiliateId)
        {
            var roles = context.User.Claims.Where(c => c.Type == ClaimTypes.Role).Select(c => c.Value).ToList();
            if (roles.Contains("admin"))
            {
                return true;
            }
            var workflowClaims = context.User.Claims.Where(item => item.Type == "workflowClaims").ToList();
            foreach (var claim in workflowClaims)
            {
                if (claim.Value == affiliateId.ToString())
                {
                    return true;
                }
            }
            return false;
        }
    }
}
