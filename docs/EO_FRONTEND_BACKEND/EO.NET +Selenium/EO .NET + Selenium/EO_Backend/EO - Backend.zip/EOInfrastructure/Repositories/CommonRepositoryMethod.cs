﻿using Dapper;
using Microsoft.Extensions.Configuration;
using EODomain.Common;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;

namespace EOInfrastructure.Repositories
{

    [ExcludeFromCodeCoverage]
    public class CommonRepositoryMethod<T> where T:class
    {
        public T? _result { get; set; }
        public string? _query { get; set; }
        public int? _totalrecords { get; set; }
        public DateTime? _timeOnly { get; set; }
        public double? _size { get; set; }
        public string? _createdDate { get; set; }
        public string? _url { get; set; }
        public string? _errorMessage { get; set; }


        public CommonRepositoryMethod(T? result, string? Query, int? totalrecords, string? timeOnly, string? URL, string? ErrorMessage)
        {
            _result = result;
            _query = Query;
            _totalrecords = totalrecords;
            _timeOnly = timeOnly != null ? Convert.ToDateTime(timeOnly) : null;
            _size = result != null ? CommonMethod.GetOutputSize(result) : null;
            _createdDate = System.DateTime.Now.ToString();
            _url = URL;
            _errorMessage = ErrorMessage;
        }

        public async Task AddQueryTracker()
        {

            var environmentName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production";

            var configuration = new ConfigurationBuilder()
                                    .SetBasePath(Directory.GetCurrentDirectory())
                                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                                    .AddJsonFile($"appsettings.{environmentName}.json", optional: true)
                                    .Build();


            using (var connection = new SqlConnection(configuration.GetConnectionString("EODashboardConnection")))
            {
                string? hostName = Environment.GetEnvironmentVariable("COMPUTERNAME") ?? Environment.GetEnvironmentVariable("HOSTNAME");

               await connection.OpenAsync();
                await connection.QueryAsync(SPConstant.ADM_ADD_QUERY_TRACKER,
                    new
                    {
                        query = _query,
                        totalRecords = _totalrecords,
                        totalTime = _timeOnly,
                        size = _size,
                        actionUrl = _url,
                        webServer = hostName,
                        errorMessage = _errorMessage
                    },
                    commandType: System.Data.CommandType.StoredProcedure);

            }

        }
    }
}