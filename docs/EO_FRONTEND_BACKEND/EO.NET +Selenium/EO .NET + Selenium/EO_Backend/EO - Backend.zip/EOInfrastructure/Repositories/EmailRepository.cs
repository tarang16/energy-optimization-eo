﻿using Dapper;
using EODomain.Common;
using EODomain.Models;
using System.Diagnostics;
using EODomain.Models.Email;
using Microsoft.Data.SqlClient;
using EODomain.Models.Account;
using EODomain.Models.Workflow;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Configuration;
using EOApplication.Contracts.Repositories;
using EODomain.Models.Favorites;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class EmailRepository : CentralRepository, IEmailRepository
    {
        private readonly string URL;
        private readonly EmailSettingsEntity _emailSettingsEntity;
        private readonly string environmentName;

        public EmailRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, IOptions<EmailSettingsEntity> emailSettingsEntity) : base(configuration, httpContextAccessor, "EODashboardConnection")
        {
            URL = httpContextAccessor.HttpContext! == null ? null! : $"{httpContextAccessor!.HttpContext!.Request.Path}";
            _emailSettingsEntity = emailSettingsEntity.Value;
            environmentName = configuration.GetSection("Environment").Value!;
        }
        public async Task<SendEmailNotificationInput> GetEmailRepository(string urlRequested)
        {
            return await ExecuteQueryAsync<SendEmailNotificationInput>
                (SPConstant.ADM_GET_EMAIL_BY_PROJECT_CODE,
                new
                {
                    projectCode = _emailSettingsEntity.ProjectCode
                }, urlRequested);
            
        }

        public async Task<UpdateEmailListResponse> AddEmailListAsync(UpdateEmailListRequest request)
        {
            return await ExecuteQueryAsync<UpdateEmailListResponse>
                (SPConstant.ADM_ADD_EMAIL_LIST_BY_EMAIL_ID,
                new
                {
                    id = request.id,
                    fromEmail = request.fromEmail,
                    toEmail = request.toEmail,
                    ccEmail = request.ccEmail
                });
        }

        public async Task<SendEmailNotificationInput> GetEmailRepositoryAsync(GetEmailByIDRequest request)
        {            
            return await ExecuteQueryAsync<SendEmailNotificationInput>
                (SPConstant.ADM_GET_EMAIL_BY_PROJECT_CODE,
                new
                {
                    projectCode = request.projectCode
                }, URL);
        }

        public async Task<List<SendEmailNotificationInput>> GetAllEmailRepositoryAsync()
        {
            return await ExecuteQueryListAsync<SendEmailNotificationInput>
                (SPConstant.ADM_GET_ALL_EMAILS,new{});
        }
        public async Task<dynamic> GetSlownessDataReport(string UrlRequested)
        {
            return await ExecuteQueryListAsync<dynamic>
                (SPConstant.ADM_GET_ADM_SLOWNESS_DATA,new{}, UrlRequested);            
        }

        public async Task<dynamic> GetFailureDataReport(string urlRequested)
        {
            return await ExecuteQueryListAsync<Track>
                (SPConstant.ADM_GET_ADM_FAILURE_DATA,
                new{ }, urlRequested);
        }

        public async Task<UpdateEmailListResponse> AddEmailAsync(SendEmailNotificationInput request,string urlRequested)
        {
            return await ExecuteQueryAsync<UpdateEmailListResponse>
                (SPConstant.ADM_ADD_Add_EMAIL,
                new 
                {
                    Id = request.Id,
                    EmailSubject = request.EmailSubject,
                    EmailBody = request.EmailBody,
                    ProjectCode = request.ProjectCode,
                    CreatedBy = request.CreatedBy,
                    UpdatedBy = request.UpdatedBy,
                    LastTriggeredTime = request.LastTriggeredTime,
                    minuteFrequency = request.MinuteFrequency
                }, urlRequested);
        }

        public async Task<List<GetWorkflowReportForMailResponse>> GetWorkflowReportForMail(string urlRequested)
        {
            return await ExecuteQueryListAsync<GetWorkflowReportForMailResponse>
                (SPConstant.USP_UI_GET_WF_REPORT_MAIL,
                new{}, urlRequested);
        }

        public async Task<List<GetWorkflowMailIdsForReportMailResponse>> GetWorkflowMailIdsForReportMail(string type, string urlRequested)
        {
            return await ExecuteQueryListAsync<GetWorkflowMailIdsForReportMailResponse>
                (SPConstant.USP_UI_GET_WF_MAILIDS_FOR_REPORT_MAIL,
                new
                {
                    type = type
                }, urlRequested);
        }

        public async Task<List<GetWorkflowReportForMailResponse>> GetWorkflowEscalationReportForMail(string urlRequested)
        {
            return await ExecuteQueryListAsync<GetWorkflowReportForMailResponse>
                (SPConstant.USP_UI_GET_WF_ESCALATION_REPORT_MAIL,new {}, urlRequested);
        }

        public async Task<WorkflowEmailLastTriggeredInfo> GetWorkflowLastTriggeredInfo(string type,string urlRequested)
        {
            return await ExecuteQueryAsync<WorkflowEmailLastTriggeredInfo>
                (SPConstant.USP_UI_GET_WF_LAST_TRIGGERED_INFO,
                new
                {
                    type = type
                }, urlRequested);
        }

        public async Task<int?> UpdateWorkflowLastTriggeredInfo(string type,string urlRequested)
        {
            return await ExecuteQueryAsync<int>
                (SPConstant.USP_UI_Update_WF_LAST_TRIGGERED_INFO,
                new
                {
                    type = type
                }, urlRequested);
        }
                
        public async Task<List<GetUsersByRoleStoredProcedureResponse>> GetUsersByRoleAsync(string userRole)
        {
            return await ExecuteQueryListAsync<GetUsersByRoleStoredProcedureResponse>(SPConstant.ADM_GET_USERS_BY_ROLE,
             new
             {
                 role = userRole
             });
        }
                
        public async Task<GetGlobalSetting> GetGlobalSetting(string activityName)
        {
            return await ExecuteQueryAsync<GetGlobalSetting>(SPConstant.USP_ADM_GET_GLOBAL_SETTING,
             new
             {
                 activityName = activityName
             });
        }

        public async Task<User> GetUserByEmployeeID( int userID)
        {
            return await ExecuteQueryAsync<User>(SPConstant.ADM_GET_UM_USER_BY_EMPLOYEE_ID,
             new
             {
                 employeeId = userID
             });
        }

        public async Task<List<GetUserIDByUserClaimID>> GetEmployeeIDByUserClaimID(string userClaimID)
        {
            return await ExecuteQueryListAsync<GetUserIDByUserClaimID>(SPConstant.USP_ADM_GET_USERID_BY_USERCLAIMID,
             new
             {
                 ID = userClaimID
             });
        }

        public async Task<List<GetUsersByRoleStoredProcedureResponse>> GetUserDetailsAsync(string employeeIDList)
        {
            return await ExecuteQueryListAsync<GetUsersByRoleStoredProcedureResponse>(SPConstant.ADM_GET_USER_BY_EMPLOYEE_ID_LIST,
             new
             {
                 employeeIDList = employeeIDList
             });
        }

        public string GetEnvironmentName()
        {
            return environmentName;
        }

        public async Task<List<GetEmailHtmlBodyForUserAccessChangeEmailData>> GetEmailHtmlBodyForUserAccessChangeEmail(string projectCode)
        {
            return await ExecuteQueryListAsync<GetEmailHtmlBodyForUserAccessChangeEmailData>
                (SPConstant.GET_HTML_DATA_FOR_EMAIL_BY_PROJECT_CODE,
                         new
                         {
                             projectCode = projectCode
                         });
        }

        public async Task<GetWorkflowProcessInstanceErrorsMail> GetWorkFlowProcessInstanceErrorsMailAsync()
        {

            return await ExecuteQueryAsync<GetWorkflowProcessInstanceErrorsMail>
                (SPConstant.USP_UI_GET_WF_PROCESS_INSTANCE_ERRORS_MAIL,
                new {});
        }
    }
}
