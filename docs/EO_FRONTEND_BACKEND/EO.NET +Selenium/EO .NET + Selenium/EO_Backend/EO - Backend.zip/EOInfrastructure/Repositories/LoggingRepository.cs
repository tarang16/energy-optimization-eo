﻿using Dapper;
using Microsoft.Extensions.Configuration;
using EOApplication.Contracts.Repositories;
using EODomain.Models.Enums;
using EODomain.Common;
using EODomain.Models.LogTables;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using static Dapper.SqlMapper;
using EODomain.Models.Account;
using EODomain.Models.Favorites;
using Microsoft.AspNetCore.Http;
using System;
using Microsoft.AspNetCore.Routing;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class LoggingRepository : CentralRepository, ILoggingRepository
    {
        public LoggingRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, DetermineConnectionStringName(httpContextAccessor))
        {
        }
        private static string DetermineConnectionStringName(IHttpContextAccessor httpContextAccessor)
        {
            string ConName = string.Empty;
            if (httpContextAccessor.HttpContext != null)
            {
                var routeData = httpContextAccessor.HttpContext!.GetRouteData();
                var controllerName = routeData.Values["controller"]?.ToString();

                // Check if the request is from 'EnergyManagementController'
                if (controllerName != null && controllerName.Contains("EnergyManagement", StringComparison.OrdinalIgnoreCase))
                {
                    ConName = "EnergyMgmtWebDashConString"; // Return the name of the connection string for Energy Management
                }
                else
                {
                    ConName = "EODashboardConnection"; // Return the name of the default connection string
                }

            }
            return ConName;
        }

        /// <summary>
        /// usp_add_performance_log is used for the logging entry to check the performance of the SP
        /// </summary>
        /// <param name="logAPIPerformanceLogs"></param>
        public async Task<bool> AddAPIPerformanceLog(LogApiPerformanceLogs logAPIPerformanceLogs)
        {

            var result = await ExecuteQueryListAsync<bool>
                (SPConstant.ADM_ADD_APIPERFORMANCELOG,
                new
                {
                    CreatedBy = logAPIPerformanceLogs.Createdby,
                    EndPointName = logAPIPerformanceLogs.EndPointName,
                    ElapsedTime = logAPIPerformanceLogs.ElapsedTime,
                    CustomMessage = logAPIPerformanceLogs.customMessage,
                    roleID = logAPIPerformanceLogs.RoleID,
                    sessionID = logAPIPerformanceLogs.SessionID,
                    layerID = logAPIPerformanceLogs.LayerID,
                    httpMethod = logAPIPerformanceLogs.HttpMethod,
                    statusCode = logAPIPerformanceLogs.StatusCode,
                    requestBody = logAPIPerformanceLogs.RequestBody,
                    requestTimeStamp = logAPIPerformanceLogs.RequestTimeStamp,
                    responseBody = logAPIPerformanceLogs.ResponseBody,
                    responseTimeStamp = logAPIPerformanceLogs.ResponseTimeStamp,
                    layerName = logAPIPerformanceLogs.LayerName
                }, logAPIPerformanceLogs.EndPointName!, 30, false);

            if (result.Count > 0) return true;
            else return false;
        }


        /// <summary>
        /// To log user activity
        /// </summary>
        /// <param name="activityTracker"></param>
        /// <returns></returns>
        public async Task<bool> AddActivityLogAsync(LogActivityTracker activityTracker)
        {
            var result = await ExecuteQueryListAsync<bool>
                (SPConstant.ADM_ADD_ACTIVITY_TRACKER_DATA,
                new
                {
                    roleID = activityTracker.RoleID,
                    userID = activityTracker.UserID,
                    ipAddress = activityTracker.IpAddress,
                    clientID = activityTracker.ClientID,
                    browserName = activityTracker.BrowserName,
                    sessionID = activityTracker.SessionID,
                    sessionStartTimeStamp = activityTracker.SessionStartTimestamp,
                    sessionEndTimeStamp = activityTracker.SessionEndTimestamp,
                    applicationID = activityTracker.ApplicationID,
                    screenID = activityTracker.ScreenID,
                    functionalityID = activityTracker.FunctionalityID,
                    userActionID = activityTracker.UserActionID,
                    isOnline = activityTracker.IsOnline,
                    createdBy = activityTracker.CreatedBy,
                    createdOn = activityTracker.CreatedOn,
                    updatedBy = activityTracker.UpdatedBy,
                    updatedOn = activityTracker.UpdatedOn,
                    userAgent = activityTracker.UserAgent,
                    browserVersion = activityTracker.BrowserVersion,
                    browserLangauge = activityTracker.BrowserLanguage,
                });

            if (result.Count > 0) return true;
            else return false;
        }


        /// <summary>
        /// To log performance of components.
        /// </summary>
        /// <param name="performanceLogs"></param>
        /// <param name="userID"></param>
        /// <param name="sessionID"></param>
        /// <returns></returns>
        public async Task<bool> AddPerformanceLogsAsync(LogPerformanceLogs performanceLogs)
        {
            return await ExecuteQueryAsync<bool>
                (SPConstant.ADM_ADD_PERFORMANCE_LOG_DATA,
                new
                {
                    sessionID = performanceLogs.SessionID,
                    roleID = performanceLogs.RoleID,
                    componentName = performanceLogs.componentName,
                    actionName = performanceLogs.actionName,
                    startTime = performanceLogs.startTime,
                    endTime = performanceLogs.endTime,
                    duration = performanceLogs.Duration,
                    createdBy = performanceLogs.CreatedBY,
                    createdOn = performanceLogs.CreatedOn,
                    updatedBy = performanceLogs.UpdatedBY,
                    updatedOn = performanceLogs.UpdatedOn,
                    isActive = performanceLogs.isActive,
                });
        }


        /// <summary>
        /// To insert login activity data in ADM_UserLogin table
        /// </summary>
        /// <param name="loginActivity"></param>
        /// <returns></returns>
        public async Task<System.Guid> AddLoginLogAsync(AdmUserLoginInsert loginActivity)
        {
            var result = await ExecuteQueryListAsync<System.Guid>
                (SPConstant.ADM_ADD_USER_LOGIN,
                new
                {
                    userID = loginActivity.UserID,
                    ipAddress = loginActivity.IpAddress,
                    serverIp = loginActivity.ServerIp,
                    userAgent = loginActivity.UserAgent,
                    browserName = loginActivity.BrowserName,
                    browserVersion = loginActivity.BrowserVersion,
                    browserLanguage = loginActivity.BrowserLanguage,
                    createdBy = loginActivity.CreatedBy,
                    updatedBy = loginActivity.UpdatedBy,
                });
            return result.FirstOrDefault();
        }


        /// <summary>
        /// To insert session data in ADM_UserSession table
        /// </summary>
        /// <param name="sessionActivtity"></param>
        /// <returns></returns>
        public async Task<System.Guid> AddSessionLogAsync(AdmUserSessionInsert sessionActivtity)
        {
            var result = await ExecuteQueryListAsync<System.Guid>
                (SPConstant.ADM_ADD_USER_SESSION,
                new
                {
                    sessionGuid = sessionActivtity.SessionGUID,
                    loginGuid = sessionActivtity.LoginGUID,
                    isOnline = sessionActivtity.IsOnline,
                    createdBy = sessionActivtity.CreatedBy,
                    updatedBy = sessionActivtity.UpdatedBy
                });

            return result.FirstOrDefault();
        }


        /// <summary>
        /// To log Activity of components.
        /// </summary>
        /// <param name="activityTrackerRequest"></param>
        /// <returns></returns>
        public async Task<bool> AddUserActivityTrackerAsync(ActivityTracker activityTrackerRequest)
        {
            var result = await ExecuteQueryListAsync<bool>
                (SPConstant.ADM_ADD_USER_ACTIVITY_DATA,
                new
                {
                    ApplicationName = activityTrackerRequest.ApplicationName,
                    ScreenName = activityTrackerRequest.ScreenName,
                    FunctionalityName = activityTrackerRequest.FunctionalityName,
                    UserActionName = activityTrackerRequest.UserActionName,
                    sessionID = activityTrackerRequest.SessionID,
                    IsOnline = activityTrackerRequest.IsOnline,
                    CreatedBy = activityTrackerRequest.CreatedBy,
                    UpdatedBy = activityTrackerRequest.UpdatedBy,
                    UpdatedOn = activityTrackerRequest.UpdatedOn,
                    AffiliateID = activityTrackerRequest.AffiliateID,
                    CaseID = activityTrackerRequest.CaseID
                });

            if (result.Count > 0) return true;
            else return false;
        }

        /// <summary>
        /// To log performance of components.
        /// </summary>
        /// <param name="LogErrorLogs"></param>
        /// <returns></returns>
        public async Task<bool> AddErrorLogsAsync(LogErrorLogs logErrorLogs)
        {
            TimeSpan duration;

            if (string.IsNullOrEmpty(logErrorLogs.Duration) ||
                string.Equals(logErrorLogs.Duration, "string", StringComparison.OrdinalIgnoreCase))
            {
                logErrorLogs.Duration = "00:00:00.000";
            }

            duration = TimeSpan.Parse(logErrorLogs.Duration);

            await ExecuteQueryListAsync<bool>
                (SPConstant.ADM_ADD_ERROR_LOG_DATA,
                new
                {
                    EmployeeId = logErrorLogs.EmployeeId,
                    ApplicationName = logErrorLogs.ApplicationName,
                    HostName = logErrorLogs.HostName,
                    LayerName = logErrorLogs.LayerName,
                    ScreenName = logErrorLogs.ScreenName,
                    ModuleName = logErrorLogs.ModuleName,
                    API = logErrorLogs.API,
                    StoredProcedure = logErrorLogs.StoredProcedure,
                    Functionality = logErrorLogs.Functionality,
                    ErrorNumber = logErrorLogs.ErrorNumber,
                    ErrorState = logErrorLogs.ErrorState,
                    ErrorSeverity = logErrorLogs.ErrorSeverity,
                    StackTraceId = logErrorLogs.StackTraceId,
                    StackTrace = logErrorLogs.StackTrace,
                    ErrorMessage = logErrorLogs.ErrorMessage,
                    SessionId = logErrorLogs.SessionId,
                    RequestBody = logErrorLogs.RequestBody,
                    CreatedBy = logErrorLogs.CreatedBy,
                    UpdatedBy = logErrorLogs.UpdatedBy,
                    StatusCode = logErrorLogs.StatusCode,
                    WebServer = logErrorLogs.WebServer,
                    ErrorType = logErrorLogs.ErrorType,
                    Duration = duration,//logErrorLogs.Duration
                }, logErrorLogs.API!);

            return true;
        }


        /// <summary>
        /// To insert token data in ADM_UserToken table
        /// </summary>
        /// <param name="sessionActivtity"></param>
        /// <returns></returns>
        public async Task<System.Guid> AddTokenLogAsync(AdmUserTokenInsert tokenActivity)
        {
            var result = await ExecuteQueryListAsync<System.Guid>
                (SPConstant.ADM_ADD_USER_TOKEN,
                new
                {
                    tokenGuid = tokenActivity.TokenGuid,
                    sessionGuid = tokenActivity.SessionGuid,
                    isActive = tokenActivity.IsActive,
                    createdBy = tokenActivity.CreatedBy,
                    updatedBy = tokenActivity.UpdatedBy
                });
            return result.FirstOrDefault();

        }


        /// <summary>
        ///  is used to get the AuditLogs.
        /// </summary>
        /// <param name="GetAuditLogRequest"></param>
        /// <returns></returns>
        public async Task<List<GetAuditLogResponse>> GetAuditLogAsync(GetAuditLogRequest request)
        {
            return await ExecuteQueryListAsync<GetAuditLogResponse>
                (SPConstant.ADM_GET_AUDIT_LOGS,
                new
                {
                    ActivityTypeID = request.activityTypeId,
                    Target = request.target,
                    TargetValue = request.targetValue
                });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<GetValidAuditLogTypesResponse>> GetValidAuditLogTypesAsync()
        {
            return await ExecuteQueryListAsync<GetValidAuditLogTypesResponse>
                (SPConstant.USP_UI_GET_AUDIT_TYPE, new { });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<bool> PostAuditLogAsync(AddAuditLogRequest request, int createdBy)
        {
            await ExecuteQueryListAsync<bool>
               (SPConstant.USP_ADM_ADD_AUDIT_LOG,
               new
               {
                   createdBy = createdBy,
                   activityName = request.activityName,
                   activityCategory = request.activityCategory,
                   activityDescription = request.activitydescription,
                   targetValue = request.targetValue,
                   target = request.target,
                   initial = request.initial,
                   changes = request.changes,
                   remarks = request.remarks
               });

            return true;
        }

        /// <summary>
        /// To get default value based on TargetValue and Target properties present in GetDefaultValueRequest
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<string> GetDefaultValueAsync(GetDefaultValueRequest request)
        {
            return await ExecuteQueryAsync<string>
                (SPConstant.USP_ADM_GET_DEFAULT_VALUE,
                new
                {
                    TargetValue = request.TargetValue,
                    Target = request.Target
                });
        }
    }
}
