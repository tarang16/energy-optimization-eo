﻿using Dapper;
using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.HistoricalData;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class HistoricalRepository: CentralRepository, IHistoricalRepository
    {
        public HistoricalRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")

        {
        }
        public async Task<dynamic> GetCalenderDataAsync(int? caseID)
        {
            return await ExecuteQueryListAsync<dynamic>
                        (SPConstant.EO_UI_GET_CALENDER_DATA,
                        new
                        {
                            caseId = caseID
                        });
        }

        public async Task<List<GetDataTimeStartEndStoredProcResponse>> GetTrendDataActualOptimumAsync(GetTrendDataActualOptimumRequest request)
        {
            return await ExecuteQueryListAsync<GetDataTimeStartEndStoredProcResponse>
            (SPConstant.EO_UI_GET_ACTUAL_OPTIMUM_TREND,
            new
            {
                caseID = request.caseID,
                sTime = request.sTime,
                eTime = request.eTime,
                tagList = request.tagNameList,
                roundFactor = request.roundFactor
            });
        }

        public async Task<dynamic> GetOpportunityTrendDataAsync(CaseIdListTimeRangeStringRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                    (SPConstant.EO_UI_GET_OPPORTUNITY_TREND,
                    new
                    {
                        case_id_list = request.caseIDList,
                        sTime = request.sTime,
                        eTime = request.eTime,
                    });
        }

        public async Task<dynamic> GetDataModelSkipMonitoringCalendarDataAsync(CaseIdTimeRangeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                    (SPConstant.EO_UI_GET_DATA_MODEL_SKIP_MONITORING,
                    new
                    {
                        caseID = request.caseID,
                        sTime = request.sTime,
                        eTime = request.eTime,
                    });
        }

        public async Task<List<GetDataModelSkipStoredProcedureResponse>> GetDataModelSkipDataAsync(CaseIdTimeRangeDayDiffRequest request)
        {
            return await ExecuteQueryListAsync<GetDataModelSkipStoredProcedureResponse>
                    (SPConstant.EO_UI_GET_DATA_MODEL_SKIP,
                    new
                    {
                        caseID = request.caseID,
                        sTime = request.sTime,
                        eTime = request.eTime,
                        dayDiff = request.dayDiff,
                    });
        }
    }
}
