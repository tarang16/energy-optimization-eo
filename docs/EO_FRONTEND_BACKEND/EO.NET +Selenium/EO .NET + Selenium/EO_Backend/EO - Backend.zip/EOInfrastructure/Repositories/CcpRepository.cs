﻿using Dapper;
using System.Data;
using EODomain.Common;
using System.Text.Json;
using System.Diagnostics;
using EODomain.Models.CCP;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using EOApplication.Contracts.Services;
using Microsoft.Extensions.Configuration;
using EOApplication.Contracts.Repositories;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Net.Mail;
using EODomain.Models.HistoricalData;
using System.Xml.Linq;
using System.Security.Cryptography;
using EODomain.Models.Admin;
using System;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class CcpRepository : CentralRepository, ICcpRepository
    {
        private readonly string eoWebDashConString;
        private readonly string URL;
        private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };
        public CcpRepository(IConfiguration configuration, ILoggingServices loggingServices, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")
        {
            eoWebDashConString = configuration.GetConnectionString("EODashboardConnection")!;
            URL = httpContextAccessor.HttpContext! == null ? null! : $"{httpContextAccessor!.HttpContext!.Request.Path}";
        }

        /// <summary>
        /// To fetch data from ccp table for all the tags in a given caseID.
        /// SP used: [dbo].[usp_get_ccp_data]
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<GetCaseIDRepositoryResponse> GetCcpDataAsync(GetCaseIDRequest request)
        {
             var query = SPConstant.UI_GET_CCPDATA_ORG;
            try
            {
                GetCaseIDRepositoryResponse response = new GetCaseIDRepositoryResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var parameters = new DynamicParameters();
                    parameters.Add("@caseID", request.caseID);
                    parameters.Add("@searchField", request.searchField);
                    parameters.Add("@pageNumber", request.pageNumber);
                    parameters.Add("@pageSize", request.pageSize);
                    var result = await connection.QueryMultipleAsync(
                                              query,
                                              parameters,
                                              commandType: System.Data.CommandType.StoredProcedure);
                    response.pageCount = (await result.ReadAsync<int>()).FirstOrDefault();
                    response.GetCaseIDResponse =(await result.ReadAsync<GetCaseIDResponse>()).ToList();
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(response.GetCaseIDResponse, query,(response.GetCaseIDResponse.Count), elapsed, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();

                   
                    
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// To add ods insights
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<OdsInsightsResponse> AddOdsInsights(AddOdsInsightsRequest request)
        {
            return await ExecuteQueryAsync<OdsInsightsResponse>(SPConstant.USP_UI_ADD_TRN_ODS_SUGGESTION,
                new
                {
                    CauseTagId = request.causeTagID,
                    Description = request.description,
                    Suggestion = request.suggestion,
                    Isactive = request.isactive,
                    CreatedBy = request.createdBy,
                    UpdatedBy = request.udpatedBy,
                    Remarks = request.remarks,
                    Changes = request.changes,
                    Formula = request.formula
                });
        }


        /// <summary>
        /// To reset ODS insights
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<OdsInsightsResponse> ResetOdsInsights(ResetOdsInsightsRequest request)
        {
            return await ExecuteQueryAsync<OdsInsightsResponse>(SPConstant.USP_UI_DELETE_TRN_ODS_SUGGESTION,
                new
                {
                    caseID = request.caseID,
                    updatedBy = request.updatedBy
                });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseID"></param>
        /// <param name="nameShort"></param>
        /// <param name="iteration"></param>
        /// <returns></returns>
        public async Task<int> UpdateCCP(UpdateCcpRequest request)
        {
            return await ExecuteQueryAsync<int>(SPConstant.USP_CCP_UPDATE_ALL_DATA,
                new
                {
                    caseID = request.caseID,
                    tagName = request.tagName,
                    defaultswitch = request.defaultSwitch,
                    defaultValue = request.defaultValue,
                    tagMin = request.tagMin,
                    tagMax = request.tagMax,
                    tagOutOfBoundSwitch = request.tagOutOfBoundSwitch,
                    tagStuckSwitch = request.tagStuckSwitch,
                    modelID = request.modelID,
                    tagNanSwitch= request.tagNanSwitch
                });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        public async Task<GetTagDataForUpdateResponse> GetTagDataForUpdateAsync(GetTagDataForUpdateRequest request)
        {
            return await ExecuteQueryAsync<GetTagDataForUpdateResponse>(SPConstant.USP_UI_GET_TAG_DATA_FOR_UPDATE,
             new
             {
                 tag_id = request.tagID
             });
        }


        public async Task<List<string>> GetPipelineLocationsAsync(int? caseID)
        {
            return await ExecuteQueryListAsync<string>(SPConstant.USP_UI_GET_PIPELINE_LOCATIONS,
             new
             {
                 caseid = caseID
             });
        }


        // Case Details Related

        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<GetCaseDetailsByCaseIDStoredProcedureResponse>> GetCaseDetailsByCaseIDAsync(int userID)
        {
            return await ExecuteQueryListAsync<GetCaseDetailsByCaseIDStoredProcedureResponse>(SPConstant.USP_UI_GET_CASE_CASEDETAILS_BY_USER,
             new
             {
                 userID = userID
             });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<string> PostUpdateCaseDetailsAsync(UpdateCaseDetailsRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_UPDATE_CASE_CASEDETAILS,
             new
             {
                 caseID = request.caseID,
                 caseName = request.caseName,
                 plantID = request.plantID,
                 processFrequency = request.processFrequency,
                 slot = request.slot,
                 refDocUrl = request.referenceDocUrl,
                 description = request.description
             });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<string> PostDeleteCaseDetailsAsync(DeleteCaseDetailsRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_DELETE_CASE_CASEDETAILS,
             new
             {
                 caseID = request.caseID,
                 Isactive = request.isActive,
             });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<string> PostAddCaseDetailsAsync(InsertCaseDetailsRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_ADD_CASE_CASEDETAILS,
             new
             {
                 active = request.active,
                 plantID = request.plantID,
                 caseName = request.caseName,
                 processFrequency = request.processFrequency,
                 slot = request.slot,
                 description = request.description
             });
        }


        // CCP and PI AF related


        /// <summary>
        /// To update CCP data
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<int> UpsertTagDetailsInCcpTable(UpdateCcpAndPiAttributeValueRequest request)
        {
            return await ExecuteQueryAsync<int>(SPConstant.USP_ADM_UPSERT_CCP_DATA,
                new
                {
                    modelID = request.modelID,
                    tagID = request.tagID,
                    defaultValue = request.defaultValue,
                    tagMin = request.min,
                    tagMax = request.max,
                    defaultswitch = request.defaultSwitch,
                    tagOutOfBoundSwitch = request.tagOutOfBoundSwitch,
                    tagStuckSwitch = request.tagStuckSwitch,
                    //boundAtLimitsSwitch = request.tagBoundAtLimitsSwitch == null ? 0 : request.tagBoundAtLimitsSwitch,
                    tagNanSwitch = request.tagNanSwitch,
                    createdBy = request.createdBy
                });
        }

        /// <summary>
        /// To fetch affected model ids by tag id for the api
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<dynamic> GetAffectedModelIdsByTagId(GetAffectedModelIdsByTagIdRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_GET_CCP_AFFECTED_MODEL_IDS_BY_TAG_ID,
             new
             {
                 tagId = request.tagId,
                 modelId = request.modelId
             });
        }

        /// <summary>
        /// To fetch case configuration portal info for the api
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public async Task<dynamic> GetCaseConfigurationPortalInfoJsonToDynamic()
        {
            var jsonResult = await ExecuteQueryListAsync<string>(SPConstant.USP_ADM_CCP_INFO,
              new
              {
              });
            var finalJsonResult = string.Join("", jsonResult);
            var result = JsonSerializer.Deserialize<dynamic>(finalJsonResult, _jsonOptions);

            return result!;
        }

        /// <summary>
        /// To fetch case configuration portal info for the api
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public async Task<dynamic> GetCaseConfigurationPortalInfo()
        {
            var result = await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_GET_CCP_INFO,
              new
              {
              });

            return result;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<dynamic> GetTagsDataForValidationAsync(GetTagsDataByCaseIDRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_TAGS_DATA_FOR_VALIDATION,
              new
              {
                  caseid = request.caseId
              });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<GetTagsDataByCaseIDPageCountResponse> GetEOTagsDataByCaseIDAsync(GetTagsDataByCaseIDRequest request)
        {


            var query = SPConstant.USP_UI_EO_GET_TAGS_DATA_BY_CASEID;
            try
            {
                GetTagsDataByCaseIDPageCountResponse response = new GetTagsDataByCaseIDPageCountResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var parameters = new DynamicParameters();
                    parameters.Add("@caseId", request.caseId);
                    parameters.Add("@searchField", request.searchField);
                    parameters.Add("@pageNumber", request.pageNumber);
                    parameters.Add("@pageSize", request.pageSize);
                    var result = await connection.QueryMultipleAsync(
                                              query,
                                              parameters,
                                              commandType: System.Data.CommandType.StoredProcedure);
                    response.pageCount = (await result.ReadAsync<int>()).FirstOrDefault();
                    response.GetTagsDataByCaseIDPageResponse = (await result.ReadAsync<GetTagsDataByCaseIDPageResponse>()).ToList();
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(response.GetTagsDataByCaseIDPageResponse, query, response.GetTagsDataByCaseIDPageResponse.Count, elapsed, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();

                   
                    
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        


        public async Task<string> UpdateTagAsync(UpdateTagRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_UPDATE_TAG,
                new
                {
                    tagid =request.tagID,
                    tagname =request.tagName,
                    tagType =request.tagType,
                    inferredexpression =request.inferredExpression,
                    piname =request.piName,
                    dataType  =request.dataType,
                    uidisplayName =request.uiDisplayName,
                    description =request.description,
                    modelId =request.modelId,
                    uomid =request.uomID,
                    flagma =request.flagMA,
                    flagmafilter =request.flagMAFilter,
                    flagdataavailablecheck =request.flagDataAvailableCheck,
                    flagoutput =request.flagOutput,
                    flagoutputrunalways =request.flagOutputRunAlways,
                    polarityexpression =request.polarityExpression,
                    designexpression =request.designExpression,
                    blockId = request.blockId
                });
        }

        public async Task<string> AddTagAsync(AddTagRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_ADD_TAG,
                new
                {
                    tagname =request.tagName,
                    tagType =request.tagType,
                    inferredexpression =request.inferredExpression,
                    piname =request.piName,
                    dataType  =request.dataType,
                    uidisplayName =request.uiDisplayName,
                    description =request.description,
                    modelId =request.modelID,
                    uomid =request.uomID,
                });
        }

        public async Task<List<dynamic>> GetBlocksAsync()
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_BLOCKS,
             new
             {
             });
        }

        public async Task<dynamic> GetModelNamesByCaseIdDataAsync(GetModelNamesByCaseIdDataRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                (SPConstant.USP_UI_EO_GET_MODEL_NAMES_BY_CASE_ID,
                new
                {
                    caseID = request.caseID,
                });
        }

        public async Task<string> DeleteTagDataAsync(DeleteTagDataRequest request)
        {
            return await ExecuteQueryAsync<string>
                (SPConstant.USP_UI_EO_DELETE_TAG,
                new
                {
                    tagID = request.tagID,
                });
        }

        /// <summary>
        /// To fetch pipeline macros by caseId.
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<dynamic> GetPipelineMacrosByCaseIdAsync(GetPipelineMacrosByCaseIdRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_GET_PIPELINE_MACROS_BY_CASE_ID,
             new
             {
                 caseId = request.caseID
             });
        }

        /// <summary>
        /// To fetch mst pipeline macros.
        /// </summary>
        /// SP used: [dbo].[usp_ui_get_mst_pipeline_macros]
        /// <returns></returns>
        public async Task<dynamic> GetMstPipelineMacrosAsync()
        {
            var result = await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_GET_MST_PIPELINE_MACROS,
              new
              {
              });

            return result;
        }

        /// <summary>
        /// To update pipeline macros
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<int> UpdatePipelineMacrosAsync(UpdatePipelineMacrosRequest request)
        {
            return await ExecuteQueryAsync<int>(SPConstant.USP_UI_UPDATE_PIPELINE_MACROS,
                new
                {
                    pipelineMacroId = request.pipelineMacroID,
                    Value = request.value,
                    mstPipelineMacroId = request.mstPipelineMacroID

                });
        }

        /// <summary>
        /// To get switch configurations
        /// SP used: [dbo].[usp_ui_get_switch_configurations]
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public async Task<dynamic> GetSwitchConfigurationsAsync()
        {
            var result = await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_GET_SWITCH_CONFIGURATIONS,
              new
              {
              });

            return result;
        }

        public async Task<dynamic> GetTrnOdsSuggestionByCaseIdAsync(GetTrnOdsByCaseIDRequest request)
        {
            var result = await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_GET_TRN_ODS_SUGGESTION_BY_CASE_ID,
              new
              {
                  caseID = request.caseID,
                  defaultValue = request.defaultValue
              });

            return result;
        }

        /// <summary>
        /// To add ods trn ods suggestion
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<OdsInsightsResponse> AddTrnOdsSuggestionAsync(AddOdsInsightsRequest request)
        {
            return await ExecuteQueryAsync<OdsInsightsResponse>(SPConstant.USP_UI_ADD_TRN_ODS_SUGGESTION,
                new
                {
                    causeTagID = request.causeTagID,
                    description = request.description,
                    suggestion = request.suggestion,
                    isactive = request.isactive,
                    createdBy = request.createdBy,
                    updatedBy = request.udpatedBy,
                    remarks = request.remarks,
                    changes = request.changes,
                    formula = request.formula,
                    thresholdValue=request.thresholdValue,
                    odsID=request.odsID,

                });
        }

        /// <summary>
        /// To fetch tag name and value for iterations APIs
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<GetTagDataForValidationStoredProcedureResponse>> GetTagDataForValidationAsync(int caseID)
        {
            return await ExecuteQueryListAsync<GetTagDataForValidationStoredProcedureResponse>(SPConstant.ADM_GET_TAG_DATA_FOR_VALIDATION,
                new
                {
                    case_id = caseID
                });
        }
    }
}

