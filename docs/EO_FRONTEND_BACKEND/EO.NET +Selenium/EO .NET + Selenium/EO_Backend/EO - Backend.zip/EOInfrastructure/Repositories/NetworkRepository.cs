﻿using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Network;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;


namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class NetworkRepository : CentralRepository, INetworkRepository
    {
        public NetworkRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")
        {
        }

        public async Task<dynamic> GetMstNetworkPagesAsync(GetMstNetworkPagesRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                (SPConstant.GET_MST_NETWORK_PAGES,
                new
                {
                    caseId=request.caseId
                });
        }

        public async Task<dynamic> GetTrnNetworkPagesAsync(GetTrnNetworkPagesRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                    (SPConstant.GET_TRN_NETWORK_PAGES,
                    new
                    {
                        caseId = request.caseId,
                        pageId = request.pageId
                    });
        }


        public async Task<dynamic> PostMstNetworkPagesAsync(PostMstNetworkPagesRequest request)
        {
            return await ExecuteQueryAsync<dynamic>
                        (SPConstant.GET_ADD_MST_NETWORK_PAGES,
                        new
                        {
                            caseid = request.caseid,
                            pagename = request.pagename,
                            createdby = request.createdby
                        });
        }

        public async Task<dynamic> PostTrnNetworkPagesAsync(PostTrnNetworkPagesRequest request)
        {
            return await ExecuteQueryAsync<dynamic>
                        (SPConstant.GET_ADD_TRN_NETWORK_PAGES,
                        new
                        {
                            pageId = request.pageId,
                            nodeJson = request.nodeJson,
                            edgeJson = request.edgeJson,
                            createdBy = request.createdBy,
                            modifiedBy = request.modifiedBy,
                            ModifiedOn = request.ModifiedOn,
                        });
        }

        public async Task<dynamic> GetAllTagsByCaseIDAsync(CaseIdInputRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                        (SPConstant.GET_ALL_TAGS_BY_CASE_ID,
                        new
                        {
                            caseID = request.caseID,
                        });
        }

        public async Task<dynamic> GetAllTagDataByCaseIDAsync(CaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                        (SPConstant.GET_ALL_TAGS_DATA_BY_CASE_ID,
                        new
                        {
                            caseID = request.caseID,
                            time = request.time
                        });
        }
    }
}
