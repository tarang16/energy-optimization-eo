﻿using Dapper;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using EOApplication.Contracts.Repositories;
using EOApplication.Contracts.Services;
using EODomain.Common;
using EODomain.Models;
using EODomain.Models.AIHub;
using EODomain.Models.InfraJobServices;
using EODomain.Models.RequestModels;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using EOInfrastructure.Repositories;

namespace PEEOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class HealthInfraRepository : CentralRepository, IHealthInfraRepository
    {
        private readonly AIHubSettings _aiHubSettings;
        private readonly PISettings _piSettings;
        private readonly string eoWebDashConString;
        private readonly string aiHubBaseUrl;
        private readonly string piWebApiBaseURL;
     

        public HealthInfraRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, IOptions<AIHubSettings> aiHubSettings, IOptions<PISettings> piSettings) :
            base(configuration, httpContextAccessor, "EODashboardConnection")
        {
            _piSettings = piSettings.Value;
            _aiHubSettings = aiHubSettings.Value;
            eoWebDashConString = configuration.GetConnectionString("EODashboardConnection")!;
            aiHubBaseUrl = configuration.GetSection("ConnectionStrings:RapidMinerAIHubBaseURL").Value!;
            piWebApiBaseURL = configuration.GetSection("ConnectionStrings:PiWebApiBaseURL").Value!;
            
        }

        /// <summary>
        /// To fetch PI tag values for the caseIDs in caseIDList.
        /// SP used: [dbo].[usp_ui_get_available_pi_time_tag]
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<List<GetAllAvailablePITimeTagResponse>> GetAllAvailablePITimeTag()
        {
            List<GetAllAvailablePITimeTagResponse> getPIStatusByCase;

            using (var connection = new SqlConnection(eoWebDashConString))
            {
                await connection.OpenAsync();
                var result = await connection.QueryAsync<GetAllAvailablePITimeTagResponse>(SPConstant.UI_GET_GetAllAvailablePITimeTag, new { }, commandType: System.Data.CommandType.StoredProcedure);
                getPIStatusByCase = result.ToList();
            }
            return getPIStatusByCase;

        }

        public async Task<int?> LogInfraStatusAsync(DataTable infraStatus, int createdBy, string urlRequested)
        {
            string query = SPConstant.USP_ADD_TRN_INFRA_MONITORING;
            try
            {
                int? insertedUsers;
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var parameters = new DynamicParameters();
                    parameters.Add("@CreatedBy", createdBy);
                    parameters.Add("@Infra_Monitoring", infraStatus.AsTableValuedParameter("Infra_Monitoring"));

                    var result = await connection.QueryAsync<int?>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    insertedUsers = result.FirstOrDefault();
                    
                    var res = new List<object> { insertedUsers! };
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(res, query, res.Count, elapsed, urlRequested, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return insertedUsers!;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, urlRequested, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                
                throw;
            }
        }

        public async Task<int?> LogPiDataInfraAsync(DataTable piData, int createdBy, string urlRequested)
        {
            string query = SPConstant.USP_ADD_PI_DATA_INFRA_MONITORING;
            try
            {
                int? insertedUsers;
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var parameters = new DynamicParameters();
                    parameters.Add("@CreatedBy", createdBy);
                    parameters.Add("@Pi_Data_Infra_Monitoring", piData.AsTableValuedParameter("Pi_Data_Infra_Monitoring"));

                    var result = await connection.QueryAsync<int?>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    insertedUsers = result.FirstOrDefault();
                   
                    var res = new List<object> { insertedUsers! };
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(res, query, res.Count, elapsed, urlRequested, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return insertedUsers!;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, urlRequested, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
               
                throw;
            }
        }

        public async Task<GetInfraStatusFrequencyResponse> GetInfraStatusFrequencyResponse(string service)
        {
            GetInfraStatusFrequencyResponse response;

            using (var connection = new SqlConnection(eoWebDashConString))
            {
                await connection.OpenAsync();
                var result = await connection.QueryFirstAsync<GetInfraStatusFrequencyResponse>(SPConstant.USP_GET_MST_INFRA_MONITORING, new { ServiceType = service }, commandType: System.Data.CommandType.StoredProcedure);
                response = result;
            }
            return response;

        }

        public async Task<List<GetInfraMonitoringResponse>> GetInfraMonitoringConnectivityAsync(GetInfraMonitoringRequest request)
        {
            return await ExecuteQueryListAsync<GetInfraMonitoringResponse>(SPConstant.USP_GET_INFRA_MONITORING_CONNECTIVITY.ToString(),
                new
                {
                    ServiceType = request.serviceType,
                    stime = request.stime,
                    etime = request.etime
                });
        }

        public async Task<List<GetPIDataInfraMonitoringLagTrendResponse>> GetPIDataInfraMonitoringLagTrendAsync(GetPIDataInfraMonitoringLagTrendRequest request)
        {
            return await ExecuteQueryListAsync<GetPIDataInfraMonitoringLagTrendResponse>(SPConstant.USP_GET_PI_DATA_INFRA_MONITORING_LAG_TREND.ToString(),
                new
                {
                    caseIDList = request.caseIDList,
                    stime = request.stime,
                    etime = request.etime
                });
        }

        public async Task<List<dynamic>> GetInfraMonitoringCaseWiseAsync(CaseIdListInputRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_GET_INFRA_MONITORING_CASEWISE.ToString(),
                new
                {
                    caseIDList = request.caseIDList
                });
        }

        public async Task<GetInfraMonitoringCaseWiseTrendResponse> GetInfraMonitoringCaseWiseTrendAsync(GetInfraMonitoringCaseWiseRequest request)
        {
            return await ExecuteQueryAsync<GetInfraMonitoringCaseWiseTrendResponse>(SPConstant.USP_GET_INFRA_MONITORING_CASEWISE_TREND.ToString(),
                new
                {
                    caseID = request.caseIDList
                });
        }

        public async Task<int?> UpdateMasterInfraMonitoring(string serviceUrl, string serviceType, string urlRequested)
        {
            int? result;
            string Query = SPConstant.USP_UPDATE_MST_INFRA_MONITORING.ToString();
            try
            {
                using (var connection = new SqlConnection(eoWebDashConString))
                {

                    var stopwatchEight = Stopwatch.StartNew();
                    var resultEighttwo = await Task.Run(() => connection.QueryAsync<int>(Query, new { serviceURL = serviceUrl, serviceType = serviceType }, commandType: System.Data.CommandType.StoredProcedure));
                    result = resultEighttwo.FirstOrDefault();
                    var res = new List<object> { result! };
                    string elapsed = stopwatchEight.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethodEighttwo = new CommonRepositoryMethod<IEnumerable<object>>(res, Query, res.Count, elapsed, urlRequested, null);
                    await _commonRepositoryMethodEighttwo.AddQueryTracker();
                    result = resultEighttwo.SingleOrDefault()!;
                }
                return result;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethodEight = new CommonRepositoryMethod<IEnumerable<object>>(null, Query, null, null, urlRequested, ex.Message);
                await _commonRepositoryMethodEight.AddQueryTracker();
                throw;
            }
        }

        /// <summary>
        /// To fetch webID from PI for the input tag.
        /// </summary>
        /// <param name="tag"></param>
        /// <returns></returns>
        public async Task<string> GetWebIDForStatusByCaseID(string tag)
        {
            string? username = _piSettings.UserName;
            string? password = _piSettings.Password;
            string encoded = CommonMethod.EnCoder(username!, password!);
            var Taglist = tag.Split(',');
            StringBuilder web = new StringBuilder("");
            foreach (var Tag in Taglist)
            {
                string pointsPathTagURL = piWebApiBaseURL + "points?path=\\\\PI-DA.sabic.com\\" + Tag;
                var piWebIDResponse = await GetPIPointDataAsync(pointsPathTagURL, encoded);
                if (piWebIDResponse != null && piWebIDResponse == ResponseConstants.NOTAUTHENTICATED.ToString())
                {
                    return ResponseConstants.UNABLE_TO_CONNECT_TO_PI;
                }
                if (piWebIDResponse != null && piWebIDResponse == ResponseConstants.SERVERERROR.ToString())
                {
                    return ResponseConstants.PI_SERVICE_IS_DOWN;
                }
                var data = JsonConvert.DeserializeObject<dynamic>(piWebIDResponse!);
                if (piWebIDResponse != null && piWebIDResponse == "")
                {
                    return ResponseConstants.PI_WEB_ID_NOT_FOUND;
                }
                if (piWebIDResponse!.ToLower().Contains("webid", StringComparison.OrdinalIgnoreCase))
                {
                    string resultID = data!.WebId;
                    web.Append("webid=" + resultID + "&");
                }
            }
            string webId = web.ToString();
            if (!string.IsNullOrEmpty(webId))
                webId = webId.Remove(webId.Length - 1);
            return webId;
        }

        public async Task<GetValuesForStatusByCaseID> GetValuesForStatusByCaseID(string WebIDURLString)
        {
            string? username = _piSettings.UserName;
            string? password = _piSettings.Password;
            string encoded = CommonMethod.EnCoder(username!, password!);
            GetValuesForStatusByCaseID? _getValuesForStatusByCaseID;
            string apiResponse = await GetPIServer(WebIDURLString, encoded);
            _getValuesForStatusByCaseID = JsonConvert.DeserializeObject<GetValuesForStatusByCaseID>(apiResponse);
            return _getValuesForStatusByCaseID!;
        }

        private static async Task<string> GetPIServer(string URL, string encoded)
        {
            try
            {
                var apiResponseOne = "";
                using (var httpClient = new HttpClient())
                {
                    httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", encoded);
                    var responseOne = await httpClient.GetAsync(URL);
                    if (responseOne != null && ((int)responseOne.StatusCode == 401))
                    {
                        return ResponseConstants.NOTAUTHENTICATED.ToString();
                    }
                    if (responseOne != null && ((int)responseOne.StatusCode > 401 || !responseOne.IsSuccessStatusCode))
                    {
                        return ResponseConstants.SERVERERROR.ToString();
                    }

                    apiResponseOne = await responseOne!.Content.ReadAsStringAsync();
                }
                return apiResponseOne;
            }
            catch (TaskCanceledException)
            {
                return "";
            }
        }

        public static async Task<string> GetPIPointDataAsync(string URL, string encoded)
        {
            string apiResponse = await GetPIServer(URL, encoded);
            return apiResponse;
        }

        public async Task<TokenResponse> GetAIHubTokenAsync(int? timeOut)
        {
            HttpClient client = new HttpClient();
            if (timeOut != null)
            {
                client.Timeout = TimeSpan.FromSeconds((double)timeOut);
            }

            client.BaseAddress = new Uri(aiHubBaseUrl);
            string _clientId = _aiHubSettings.ClientId!;
            string _grantType = _aiHubSettings.GrantType!;
            string _refreshToken = _aiHubSettings.RefreshToken!;
            string _clientSecret = _aiHubSettings.ClientSecret!;


            try
            {
                var content = new Dictionary<string, string>
                {
                    {"client_id", _clientId},
                    {"grant_type", _grantType },
                    {"refresh_token", _refreshToken},
                    {"client_secret", _clientSecret}

                };

                var responseOne = await client.PostAsync("/auth/realms/master/protocol/openid-connect/token", new FormUrlEncodedContent(content));

                if (responseOne.IsSuccessStatusCode)
                {
                    var result = await responseOne.Content.ReadAsStringAsync();
                    TokenResponse? tokenResponseOne = System.Text.Json.JsonSerializer.Deserialize<TokenResponse>(result);
                    return tokenResponseOne!;
                }
                else
                {
                    return null!;
                }
            }
            catch (TaskCanceledException)
            {

                return null!;
            }
        }

        public async Task<GetHealthCheckQueryResponse> GetHealthCheckAsync(string token)
        {

            HttpClient clientOne = new HttpClient();
            clientOne.BaseAddress = new Uri(aiHubBaseUrl);

            clientOne.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            var responseOne = await clientOne.GetAsync("/api/v1/healthcheck");
            if (responseOne.IsSuccessStatusCode)
            {
                var resultOne = await responseOne.Content.ReadAsStringAsync();
                GetHealthCheckQueryResponse? apiResponseOne = System.Text.Json.JsonSerializer.Deserialize<GetHealthCheckQueryResponse>(resultOne);
                return apiResponseOne!;
            }
            return null!;

        }

        public async Task<GetJobAgentsStateByQueueNameQueryResponse> GetJobAgentsStateByQueueNameAsync(string queueName, string token)
        {

            HttpClient clientTwo = new HttpClient();
            clientTwo.BaseAddress = new Uri(aiHubBaseUrl);

            clientTwo.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var responseTwo = await clientTwo.GetAsync(string.Format("/api/v1/queues/{0}/", queueName));
            if (responseTwo.IsSuccessStatusCode)
            {
                var resultTwo = await responseTwo.Content.ReadAsStringAsync();
                GetJobAgentsStateByQueueNameQueryResponse? apiResponseTwo = System.Text.Json.JsonSerializer.Deserialize<GetJobAgentsStateByQueueNameQueryResponse>(resultTwo);
                return apiResponseTwo!;
            }
            return null!;

        }

        public async Task<PiConnectionResponse> GetPiConnectionResponse()
        {
            string? username = _piSettings.UserName;
            string? password = _piSettings.Password;
            string encoded = CommonMethod.EnCoder(username!, password!);
            string pointsPathTagURL = piWebApiBaseURL + "points?path=\\\\PI-DA.sabic.com\\" + "AR.AR3.DCS.FC3201.PV";
            PiConnectionResponse piConnectionResponse = new PiConnectionResponse();
            var piWebIDResponse = await GetPIPointDataAsync(pointsPathTagURL, encoded);

            if (piWebIDResponse != null && piWebIDResponse == ResponseConstants.NOTAUTHENTICATED.ToString())
            {
                piConnectionResponse.piStatus = "0";
                piConnectionResponse.piResponse = ResponseConstants.UNABLE_TO_CONNECT_TO_PI;
                piConnectionResponse.piConnResponseCode = int.Parse(piWebIDResponse);
            }
            else if (piWebIDResponse != null && piWebIDResponse == ResponseConstants.SERVERERROR.ToString())
            {
                piConnectionResponse.piStatus = "0";
                piConnectionResponse.piResponse = ResponseConstants.SERVERERROR.ToString();
                piConnectionResponse.piConnResponseCode = int.Parse(piWebIDResponse);
            }

            else
            {
                piConnectionResponse.piStatus = "1";
                piConnectionResponse.piResponse = "You are authenticated";
                piConnectionResponse.piConnResponseCode = (int)HttpStatusCode.OK;
            }
            return piConnectionResponse;
        }

    }
}
