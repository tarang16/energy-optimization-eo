﻿using Dapper;
using System.Data;
using EODomain.Common;
using System.Text.Json;
using System.Diagnostics;
using EODomain.Models.CCP;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics.CodeAnalysis;
using EOApplication.Contracts.Services;
using Microsoft.Extensions.Configuration;
using EOApplication.Contracts.Repositories;
using Microsoft.AspNetCore.Http.HttpResults;
using System.Net.Mail;
using EODomain.Models.HistoricalData;
using System.Xml.Linq;
using EODomain.Models.CcpOptimizer;
using EODomain.Models.Requests;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class CcpOptimizerRepository : CentralRepository, ICcpOptimizerRepository
    {
        public CcpOptimizerRepository(IConfiguration configuration, ILoggingServices loggingServices, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")
        {
        }


        /// <summary>
        /// To fetch data from ccp table for all the tags in a given caseID.
        /// SP used: [dbo].[usp_get_ccp_data]
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<dynamic>> GetOptimizerConstraintsAsync(int caseID)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_OPTIMIZER_CONSTRAINTS,
                new
                {
                    caseID = caseID
                });

        }

        /// <summary>
        /// To fetch data from ccp table for all the tags in a given caseID.
        /// SP used: [dbo].[usp_get_ccp_data]
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<dynamic>> GetOptimizerVariablesDataByCaseIdAsync(int caseID)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_OPTIMIZER_VARIABLES,
                new
                {
                    caseID = caseID
                });

        }

        /// <summary>
        /// To fetch data from ccp table for all the tags in a given caseID.
        /// SP used: [dbo].[usp_get_ccp_data]
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<dynamic>> GetOptimizerParameterByCaseIdAsync(int caseID)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_OPTIMIZER_PARAMETER,
                new
                {
                    caseID = caseID
                });

        }

        /// <summary>
        /// To fetch data from ccp table for all the tags in a given caseID.
        /// SP used: [dbo].[usp_get_ccp_data]
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<dynamic>> GetOptimizerDerivedEquationsAsync(int caseID)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_OPTIMIZER_DERIVED_EQUATIONS,
                new
                {
                    caseID = caseID
                });

        }

        /// <summary>
        /// To fetch data from ccp table for all the tags in a given caseID.
        /// SP used: [dbo].[usp_get_ccp_data]
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<dynamic>> GetOptimizerObjectiveFunctionAsync(int caseID)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_OPTIMIZER_OBJECTIVE_FUNCTION,
                new
                {
                    caseID = caseID
                });

        }

        /// <summary>
        /// To optimizer variable by case Id
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<dynamic> GetOptimizerVariablesDatabyCaseIDAsync(int caseID)
        {
            var result = await ExecuteQueryAsync<dynamic>(SPConstant.USP_UI_GET_OPTIMIZER_VARIABLES, new { caseId = caseID });
            return result;
        }
        public async Task<dynamic> GetOptimizerParametersbyCaseIDAsync(int caseID)
        {
            var result = await ExecuteQueryAsync<dynamic>(SPConstant.USP_UI_GET_OPTIMIZER_PRAMETERS, new { caseId = caseID });
            return result;
        }

        public async Task<dynamic> AddOptimizerObjectiveAsync(AddOptimizerObjectiveRequest request)
        {
            return await ExecuteQueryAsync<dynamic>(SPConstant.USP_UI_EO_ADD_OPTIMIZER_OBJECTIVE_FUNCTION,
                new
                {
                    ObjectiveId = request.objectiveId,
                    ModelTagId = request.modelTagId,
                    Direction = request.direction,
                    CreatedBy = request.createdBy,
                    ModifiedBy = request.modifiedBy,
                    FormulaExpression=request.formulaExpression
                });
        }

        public async Task<dynamic> AddOptimizerDerivedEquationAsync(AddOptimizerDerivedEquationRequest request)
        {
            return await ExecuteQueryAsync<dynamic>(SPConstant.USP_UI_EO_ADD_OPTIMIZER_DERIVED_EQUATION,
                new
                {
                    DerivedEquationId = request.derivedEquationId,
                    ModelTagId = request.modelTagId,
                    Formula = request.formula
                });
        }

        public async Task<dynamic> AddOptimizerVariableAsync(AddOptimizerVariableRequest request)
        {
            return await ExecuteQueryAsync<dynamic>(SPConstant.USP_UI_EO_ADD_OPTIMIZER_VARIABLE,
                new
                {
                    VariableId = request.variableId,
                    ModelTagId = request.modelTagId,
                    LowerBound = request.lowerBound,
                    UpperBound = request.upperBound,
                    FlagInteger = request.flagInteger,
                    LowerBoundSwitch = request.lowerBoundSwitch,
                    UpperBoundSwitch = request.upperBoundSwitch,
                    InitialValueSwitch = request.initialValueSwitch,
                    LowerBoundExpression = request.lowerBoundExpression,
                    UpperBoundExpression = request.upperBoundExpression,
                });
        }

        public async Task<dynamic> AddOptimizerConstraintAsync(AddOptimizerConstraintRequest request)
        {
            return await ExecuteQueryAsync<dynamic>(SPConstant.USP_UI_EO_ADD_OPTIMIZER_CONSTRAINT,
                new
                {
                    ConstraintId = request.constraintId,
                    ModelId = request.modelId,
                    ConstraintCategoryId = request.constraintCategoryId,
                    System = request.system,
                    Expression = request.expression,
                });
        }

        public async Task<dynamic> UpdateOptimizerParameterAsync(AddOptimizerParameterRequest request)
        {
            return await ExecuteQueryAsync<dynamic>(SPConstant.USP_UI_EO_UPDATE_OPTIMIZER_PARAMETER,
                new
                {
                    ModelTagId = request.modelTagId,
                    Flagparameter = request.flagParameter
                });
        }

        public async Task<string> PostDeleteOptimizerDerivedEquationAsync(OptimizerDerivedEquationIdRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_DELETE_OPTIMIZER_DERIVED_EQUATIONS,
             new
             {
                 Id = request.derivedEquationId,
             });
        }

        public async Task<string> PostDeleteOptimizerVariableAsync(OptimizerVariableIdRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_DELETE_OPTIMIZER_VARIABLE,
             new
             {
                 Id = request.variableId,
             });
        }

        public async Task<string> PostDeleteOptimizerConstraintAsync(OptimizerConstraintIdRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_DELETE_OPTIMIZER_CONSTRAINT,
             new
             {
                 Id = request.constraintId,
             });
        }

        public async Task<string> PostDeleteOptimizerParameterAsync(OptimizerParameterIdRequest request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_DELETE_OPTIMIZER_PARAMETER,
             new
             {
                 Id = request.modelTagId,
             });
        }

        public async Task<List<dynamic>> GetOptimizerConstraintCategoryAsync()
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_OPTIMIZER_CONSTRAINTS_CATEGORY,
             new
             {
             });
        }

        public async Task<string> UpdateEquipmentAvailabilityAsync(UpdEquipAvaliabilityRequestData request)
        {
           
            var equipmentData = request.equipmentData;  // Assuming request is of type UpdEquipAvaliabilityRequestData
            var dataTable = UpdateEquipmentAvailabilityDataTable.ConvertToDataTable(equipmentData!);

           
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_UPDATE_EQUIPMENTAVAILIABILITY,
             new
             {
                 EquipmentAvailabilityUpdate = dataTable,                 
                 CreatedBy=request.createdBy
             });
        }

        public async Task<List<dynamic>> GetConfigEquipmentAvailabilityAsync(int caseId)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_EO_GET_EQUIPMENTAVAILIABILITY,
             new
             {
                 caseId= caseId,
             });
        }

        public async Task<string> UpdateOptimizationPriceInputAsync(UpdateOptimizationPriceInput request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_UI_EO_UPDATE_OPTIMIZATION_PRICE_INPUT,
             new
             {

                 caseId = request.caseId,
                 modelTagId = request.modelTagId,
                 currentValue=request.currentValue

             });
        }

        public async Task<dynamic> GetSeuDetailsDataAsync(int CaseID)
        {
            return await ExecuteQueryListAsync<dynamic>
            (SPConstant.USP_UI_EO_GET_SEU_DETAILS,
            new
            {
                caseId = CaseID,
            });
        }

        public async Task<dynamic> GetSubModelDataAsync(int CaseID)
        {
            return await ExecuteQueryListAsync<dynamic>
            (SPConstant.USP_UI_EO_GET_SUB_MODEL,
            new
            {
                caseId = CaseID,
            });
        }

        public async Task<dynamic> UpdateSeuDetailsDataAsync(UpdateSeuDetailsRequest request)
        {
            return await ExecuteQueryAsync<dynamic>
            (SPConstant.USP_UI_EO_UPDATE_SEU_DETAILS,
            new
            {
                caseId = request.caseID,
                seuId = request.seuID,
                seuName = request.seuName,
                baselineDutyExpression = request.baselineDutyExpression,
                actualDutyExpression = request.actualDutyExpression,
                targetDutyExpression = request.targetDutyExpression,
                seuCategory = request.seuCategory,
                seuDisplayName = request.seuDisplayName,
                baselineDutyExpressionGjph=request.baselineDutyExpressionGjph,
                actualDutyExpressionGjph = request.actualDutyExpressionGjph,
                targetDutyExpressionGjph = request.targetDutyExpressionGjph,
            });
        }

        public async Task<dynamic?> UpdateSubModelDataAsync(UpdateSubModelRequest request)
        {
            return await ExecuteQueryAsync<dynamic>
                        (SPConstant.USP_UI_EO_UPDATE_SUB_MODEL,
                        new
                        {
                            caseId = request.caseID,
                            subModelId = request.subModelID,
                            subModelName = request.subModelName,
                            subModelType = request.subModelType,
                            order = request.order,
                            responseOutput = request.responseOutput,
                            subModelExpression = request.subModelExpression,
                        });
        }

        /// <summary>
        /// to get the data for sub model parameter
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<GetSubModelParameterSqlResponse>> GetSubModelParameterAsync(GetCaseIDRequest request)
        {
            return await ExecuteQueryListAsync<GetSubModelParameterSqlResponse>
                        (SPConstant.USP_UI_EO_GET_SUB_MODEL_PARAMETER,
                        new
                        {
                            caseId = request.caseID
                        });
        }

        /// <summary>
        /// to update the value of sub model parameter 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<dynamic?> UpdateSubModelParameterAsync(UpdateSubModelParameterRequest request)
        {
            return await ExecuteQueryAsync<dynamic>
                        (SPConstant.USP_UI_EO_UPDATE_SUB_MODEL_PARAMETER,
                        new
                        {
                            sub_model_parameter_id = request.subModelParameterId,
                            value = request.value
                        });
        }
    }
}

