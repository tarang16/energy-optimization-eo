﻿using Dapper;
using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Account;
using EODomain.Models.Account.Workflow;
using EODomain.Models.Enums;
using EODomain.Models.LogTables;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Configuration;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Routing;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class AccountRepository : CentralRepository, IAccountRepository
    {
        private readonly string? eoWebDashConString;
        private readonly string URL;

        public AccountRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
             base(configuration, httpContextAccessor, "EODashboardConnection")  
        {

            
            eoWebDashConString = configuration.GetConnectionString("EODashboardConnection")!;
            
            URL = httpContextAccessor.HttpContext! == null ? null! : $"{httpContextAccessor!.HttpContext!.Request.Path}";
        }
       

        /// <summary>
        /// To get user details using loginID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public async Task<User> GetUserbyLoginIdAsync(string ID,string UrlRequested)
        {

            return await ExecuteQueryAsync<User>(
                SPConstant.ADM_GET_USER_BY_DOMAIN_LOGIN_ID,
                new
                {
                    domainLoginId = ID
                }, UrlRequested);
        }

        
        /// <summary>
        /// To get user details using employeeID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public async Task<User> GetUserbyEmployeeIdAsync(int ID)
        {
            return await ExecuteQueryAsync<User>(
                SPConstant.ADM_GET_USER_BY_EMPLOYEE_ID,
                new
                {
                    employeeId = ID
                });
        }


        /// <summary>
        /// To delete role assigned to a user
        /// SP used: [dbo].[usp_ui_deleteuserrole]
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<DeleteRoletoUserStoredProcedureResponse>> DeleteRoletoUserAsync(DeleteRoleForUserRequest request )
        {
            return await ExecuteQueryListAsync<DeleteRoletoUserStoredProcedureResponse>(
                SPConstant.ADM_DELETEUSERROLE,
                new
                {
                    userID = request.userID,
                    role = request.role,
                    updatedByUserID = request.updatedByUserID
                });
            
        }


        public async Task<List<DeleteRoletoUserStoredProcedureResponse>> DeleteUerRoleClaimsByUserID(DeleteUerRoleClaimsByUserID request)
        {
            return await ExecuteQueryListAsync<DeleteRoletoUserStoredProcedureResponse>(
                SPConstant.ADM_DELETEUSERROLEANDCLAIMS,
                new
                {
                    userID = request.userID,                    
                    updatedByUserID = request.updatedByUserID
                });

        }


        /// <summary>
        /// To assign role to a user 
        /// SP used: [dbo].[usp_adm_add_user_role] 
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="role"></param>
        /// <param name="createdBy"></param>
        /// <returns></returns>
        public async Task<bool> AddRolestoUserAsync(int userID, string role, int createdBy)
        {
            return await ExecuteQueryAsync<bool>(
                SPConstant.ADM_ADD_ROLEBYUSERID,
                new
                {
                    userId = userID,
                    role = role,
                    createdByUserID = createdBy
                });
            
        }


        /// <summary>
        /// To search a user using their email/name/userID
        /// </summary>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public async Task<List<GetUsersDetailsWithCountryTimeZone>> GetUserByIDNameEmailAsync(string keyword)
        {
            return await ExecuteQueryListAsync<GetUsersDetailsWithCountryTimeZone>(
                    SPConstant.ADM_SEARCH_USER_BY_KEYWORD,
                    new
                    {
                        keyword = keyword
                    });
        }


        /// <summary>
        /// To assign role to users
        /// SP used: [dbo].[usp_adm_add_role_to_users]
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<PostAddRoleToUsersStoredProcedureResponse>> PostAddRoleToUsersRequestAsync(PostAddRoleToUsersRequest request)
        {
            return await ExecuteQueryListAsync<PostAddRoleToUsersStoredProcedureResponse>(
                SPConstant.UI_POST_ADDROLETOUSERS,
                new
                {
                    userIDList = request.userIDList,
                    role = request.role,
                    createdByUserID = request.createdByUserID
                });
            
        }


        /// <summary>
        /// To get userIDs for users with given role
        /// SP used: [dbo].[usp_adm_get_role_details]
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        public async Task<List<GetRoleDetailsStoredProcedureResponse>> GetRoleDetailsAsync(string role)
        {
            return await ExecuteQueryListAsync<GetRoleDetailsStoredProcedureResponse>(
                SPConstant.UI_GET_ROLEDETAILS,
                new
                {
                    role = role
                });
            
        }


        /// <summary>
        /// To get user details for a list of employeeIDs
        /// </summary>
        /// <param name="employeeIDList"></param>
        /// <returns></returns>
        public async Task<List<GetUsersByRoleStoredProcedureResponse>> GetUserDetailsAsync(string employeeIDList)
        {
            return await ExecuteQueryListAsync<GetUsersByRoleStoredProcedureResponse>(
                SPConstant.ADM_GET_USER_BY_EMPLOYEE_ID_LIST,
            new
            {
                employeeIdList = employeeIDList
            });
            
        }


        /// <summary>
        /// To get user roles 
        /// SP used [usp_adm_get_role_by_user_id] 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public async Task<string> GetRolesbyUserIdAsync(int userID,HttpContext context)
        {
            return await ExecuteQueryAsync<string>(
                SPConstant.ADM_GET_ROLESBYUSERID,
                new
                {
                    userId = userID
                });
            
        }


        /// <summary>
        /// To get user roles 
        /// SP used [usp_adm_get_role_by_user_id] 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public async Task<GetRolesRoleIdByUserIdStoredProcResponse> GetRolesRoleIDByUserIdAsync(int userID, HttpContext context)
        {
            return await ExecuteQueryAsync<GetRolesRoleIdByUserIdStoredProcResponse>(
                SPConstant.ADM_GET_ROLEROLEIDSBYUSERID,
                new
                {
                    userId = userID
                });
            
        }


        /// <summary>
        /// To get valid user count from database
        /// </summary>
        /// <param name="employeeIDList"></param>
        /// <returns></returns>
        public async Task<int> GetUserCountFromEmployeeListAsync(string employeeIDList)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.ADM_GET_USER_COUNT_BY_EMPLOYEE_ID_LIST,
                    new
                    {
                        employeeIdList = employeeIDList
                    }
                );
            
        }


        /// <summary>
        /// To get valid caseID count
        /// SP used: [dbo].[usp_ui_get_valid_case_ids]
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<int> GetCaseIDCountFromCaseIDListAsync(string caseIDList)
        {
            return await ExecuteQueryAsync<int>(
                SPConstant.UI_GET_VALIDCASEIDSCOUNT,
                new
                {
                    caseIDList = caseIDList
                });
            
        }


        /// <summary>
        /// To get valid user roles
        /// SP used: [dbo].[usp_ui_get_valid_role]
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        public async Task<string> GetValidRoleAsync(string role)
        {
            return await ExecuteQueryAsync<string>(
                SPConstant.UI_GET_VALIDROLE,
                new
                {
                    role = role
                });
            
        }


        /// <summary>
        /// To get user CCP claims 
        /// SP used: [dbo].[usp_adm_get_claims_by_user_id] 
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public async Task<List<ClaimDto>> GetClaimsbyUserIdAsync(int ID,string urlRequested) 
        {
            return await ExecuteQueryListAsync<ClaimDto>(
                SPConstant.ADM_GET_CLAIMSBYUSERID,
                new
                {
                    userId = ID
                });
            
        }

        
        /// <summary>
        /// To fetch latest login and session data for a user.
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<GetLatestLoginSessionByUserStoredProcedureResponse> GetLatestLoginSessionByUserAsync(int userId,string urlRequested)
        {
            return await ExecuteQueryAsync<GetLatestLoginSessionByUserStoredProcedureResponse>(
                SPConstant.ADM_GET_LATEST_LOGIN_SESSION_BY_USER,
                new
                {
                    userId = userId
                });

            
        }


        /// <summary>
        /// To logout and end sessions of a user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task LogoutAndEndSessionByUserIdAsync(int userId)
        {
            string logoutQuery = SPConstant.ADM_LOGOUT_AND_END_SESSION_BY_USER;
            try
            {
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopWatch = Stopwatch.StartNew();

                    await connection.ExecuteAsync(logoutQuery, new { userId = userId }, commandType: System.Data.CommandType.StoredProcedure);

                    var result = new List<object> { userId };
                    string elapsedTime = stopWatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(result, logoutQuery, result.Count, elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, logoutQuery, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// To end all previous sessions of the user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task EndUserSessionAsync(int userId)
        {
            string logoutQuery = SPConstant.ADM_END_ALL_PREVIOUS_SESSIONS_BY_USER;
            try
            {
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();

                    await connection.ExecuteAsync(logoutQuery, new { userId = userId}, commandType: System.Data.CommandType.StoredProcedure);

                    var result = new List<object> { userId };
                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(result, logoutQuery, result.Count, elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, logoutQuery, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// To add user to ADM_CUSTOM_USER_DETAILS
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<int> AddUserToCustomUserTableAsync(AddUserToCustomUserTableRequest request)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.ADM_ADD_USER_IN_CUSTOM_USER_TABLE,
                    new
                    {
                        employeeID = request.employeeID,
                        employeeName = request.employeeName,
                        firstName = request.firstName,
                        lastName = request.lastName,
                        domainLoginID = request.domainLoginID,
                        affiliateCode = request.affiliateCode,
                        affiliateName = request.affiliateName,
                        email = request.email,
                        country = request.country,
                        region = request.region
                    }
                );

            
        }


        /// <summary>
        /// To fetch latest login and session data for by sessionGuid.
        /// </summary>
        /// <param name="sessionGuid"></param>
        /// <returns></returns>
        public async Task<GetLatestLoginSessionByUserStoredProcedureResponse> GetLatestLoginSessionBySessionAsync(string? sessionGuid,string urlRequested)
        {
            return await ExecuteQueryAsync<GetLatestLoginSessionByUserStoredProcedureResponse>(
                SPConstant.ADM_GET_LATEST_LOGIN_SESSION_BY_SESSION,
                new
                {
                    sessionGuid = sessionGuid
                });
        }


        /// <summary>
        /// To deactivate all previous tokens for a user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task DeactivateUserTokensAsync(int userId)
        {
            string logoutQuery = SPConstant.ADM_DEACTIVATE_ALL_TOKENS_BY_USER;
            try
            {
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    await connection.ExecuteAsync(logoutQuery, new { userId = userId }, commandType: System.Data.CommandType.StoredProcedure);
                    var Result = new List<object> { userId };
                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(Result, logoutQuery, Result.Count, elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, logoutQuery, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// To fetch latest login and session data for by sessionGuid.
        /// </summary>
        /// <param name="sessionGuid"></param>
        /// <returns></returns>
        public async Task<GetLatestTokenDataBySessionStoredProcedureResponse> GetTokenSessionLoginDataByTokenAsync(string? tokenGuid,string urlRequested)
        {
            return await ExecuteQueryAsync<GetLatestTokenDataBySessionStoredProcedureResponse>(
                    SPConstant.ADM_GET_LATEST_TOKEN,
                    new
                    {
                        tokenGuid = tokenGuid
                    });
        }


        /// <summary>
        /// To fetch users for a role
        /// </summary>
        /// <param name="role"></param>
        /// <returns></returns>
        public async Task<List<GetUsersByRoleStoredProcedureResponse>> GetUsersByRoleAsync(string role)
        {
            return await ExecuteQueryListAsync<GetUsersByRoleStoredProcedureResponse>(
                    SPConstant.ADM_GET_USERS_BY_ROLE,
                    new
                    {
                        role = role
                    });
        }

        /// <summary>
        /// Deletes claims for a user
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentException"></exception>
        public async Task<bool> DeleteClaimFromUserAsync(string deleteIdList, int deleteBy)
        {
            return await ExecuteQueryAsync<bool>
                (
                    SPConstant.ADM_DELETE_CLAIMBYUSERID,
                    new
                    {
                        claimIDList = deleteIdList,
                        updatedByUserID = deleteBy
                    }
                );
            
            
        }

        /// <summary>
        /// To add multiple users to a claim
        /// </summary>
        /// <param name="userClaims"></param>
        /// <param name="createdBy"></param>
        /// <returns></returns>
        public async Task<int?> AddClaimsToUsersAsync(DataTable userClaims, int createdBy)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.ADM_ADD_CLAIMS_TO_USERS,
                    new
                    {
                        createdBy = createdBy,
                        userClaimTable = userClaims.AsTableValuedParameter("UserClaimTable")
                    }
                );
            
        }


        /// <summary>
        /// To fetch valid claims
        /// </summary>
        /// <returns></returns>
        public async Task<List<string>> GetValidClaimTypes(string urlRequested)
        {
            return await ExecuteQueryListAsync<string>(
                    SPConstant.ADM_GET_VALID_CLAIMS,
                    new
                    {
                    }, urlRequested);
        }


        /// <summary>
        /// To fetch valid claims
        /// </summary>
        /// <returns></returns>
        public async Task<GetDataForAuthenticationByUserIdStoredProcedureResponse> GetDataForAuthenticationByUserIdAsync(int userID)
        {
           
            string query = SPConstant.USP_ADM_GET_DATA_FOR_AUTHENTICATION;
            try
            {
                GetDataForAuthenticationByUserIdStoredProcedureResponse response = new GetDataForAuthenticationByUserIdStoredProcedureResponse();
                using (var connectionThree = new SqlConnection(eoWebDashConString))
                {
                   await connectionThree.OpenAsync();
                    var stopwatchThree = Stopwatch.StartNew();

                    var resultThree = await connectionThree.QueryMultipleAsync(query, new { userID = userID }, commandType: System.Data.CommandType.StoredProcedure);
                    response.userRole =(await resultThree.ReadAsync<GetRolesRoleIdByUserIdStoredProcResponse>()).FirstOrDefault();
                    response.sessionData = (await resultThree.ReadAsync<GetLatestLoginSessionByUserStoredProcedureResponse>()).FirstOrDefault();
                    response.claims = (await resultThree.ReadAsync<ClaimDto>()).ToList();
                   
                    response.workflowData = (await resultThree.ReadAsync<GetWorkflowUserRoleByUserId>()).ToList();
                    string elapsed = stopwatchThree.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var queryRes = new List<object> { 1, 2, 3, 4 };
                    var _commonRepositoryMethodThree = new CommonRepositoryMethod<IEnumerable<object>>(queryRes!, query, queryRes.Count, elapsed, URL, null);
                    await _commonRepositoryMethodThree.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethodThree = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethodThree.AddQueryTracker();
                throw;
            }

        }


        /// <summary>
        /// To get validation data used when user is granted a role in the dashboard
        /// </summary>
        /// <param name="request"></param>
        public async Task<GetValidationDataForAddRoleToUsersStoredProcedureResponse> GetValidationDataForAddRoleToUsersAsync(PostAddRoleToUsersRequest request)
        {
           
            string query = SPConstant.USP_ADM_GET_VALIDATION_DATA_FOR_ROLE_ADDITION;
            try
            {
                GetValidationDataForAddRoleToUsersStoredProcedureResponse response = new GetValidationDataForAddRoleToUsersStoredProcedureResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();

                    var result = await connection.QueryMultipleAsync(query, new { role = request.role, userIDList = request.userIDList, createdByUserID = request.createdByUserID.ToString() }, commandType: System.Data.CommandType.StoredProcedure);
                    response.validRole =(await result.ReadAsync<string>()).FirstOrDefault();
                    response.createdByCount =(await result.ReadAsync<int>()).FirstOrDefault();
                    response.usersCount =(await result.ReadAsync<int>()).FirstOrDefault();
                    response.users =(await result.ReadAsync<GetUsersByRoleStoredProcedureResponse>()).ToList();
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var queryRes = new List<object> { 1, 2, 3, 4 };
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(queryRes!, query, queryRes.Count, elapsed, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }

        }


        /// <summary>
        /// To fetch data for authentication in custom auth middleware
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="tokenGuid"></param>
        /// <returns></returns>
        public async Task<GetTokenAuthorizationDataStoredProcedureResponse> GetTokenAuthorizationDataAsync(int userID, string? tokenGuid, HttpContext context)
        {
            string query = SPConstant.USP_ADM_GET_TOKEN_AUTHORIZATION_DATA;
            try
            {
                GetTokenAuthorizationDataStoredProcedureResponse response = new GetTokenAuthorizationDataStoredProcedureResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                   await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryMultipleAsync(query, new { userID = userID, tokenGuid = tokenGuid }, commandType: System.Data.CommandType.StoredProcedure);
                    response.tokenInfo = (await result.ReadAsync<GetTokenRelatedData>()).FirstOrDefault();
                    response.userRole = (await result.ReadAsync<GetRolesRoleIdByUserIdStoredProcResponse>()).FirstOrDefault();

                    response.allClaims =(await result.ReadAsync<ClaimDto>()).ToList();

                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var queryResult = new List<object> { 1, 2, 3, 4 };
                    var urlRequested = context.Request.Path;
                    var _commonRepositoryMethodOne = new CommonRepositoryMethod<IEnumerable<object>>(queryResult!, query, queryResult.Count, elapsed, urlRequested, null);
                    await _commonRepositoryMethodOne.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var urlRequested = context.Request.Path;
                var _commonRepositoryMethodOne = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, urlRequested, ex.Message);
                await _commonRepositoryMethodOne.AddQueryTracker();
                throw;
            }

        }

        public async Task<dynamic> GetUserAccessDataAsync(string employeeID)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_USER_ACCESS_BY_EMPLOYEE_ID,
                new
                {
                    employeeID = employeeID
                });
        }

        public async Task<dynamic> GetUserFeatureAccessDataAsync(string employeeID)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_USER_FEATURE_ACCESS_BY_EMPLOYEE_ID,
                new
                {
                    employeeID = employeeID
                });
        }

        public async Task<dynamic> GetUserDetailsWithAffiliateClaimAsync(AffiliateIdListClaimTypeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_UM_ROLE_BY_AFFILIATE_ID,
                new
                {
                    affiliateIDList = request.affiliateIDList,
                    claimType = request.claimType,
                });
        }


        /// <summary>
        /// To fetch users with workflow access for the input role, plant, affiliate
        /// </summary>
        /// <param name="role"></param>
        /// <param name="plantID"></param>
        /// <returns></returns>
        public async Task<List<GetWorkFlowUsersByRolePlantAffiliateStoredProcedureResponse>> GetWorkflowUsersByRoleAffiliatePlant(string? role, int? affiliateId)
        {
            return await ExecuteQueryListAsync<GetWorkFlowUsersByRolePlantAffiliateStoredProcedureResponse>(
                SPConstant.ADM_GET_WORKFLOW_USERS_BY_ROLE,
                new
                {
                    role = role,
                    affiliateId = affiliateId
                });
            
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="userIDList"></param>
        /// <param name="role"></param>
        /// <param name="plantID"></param>
        /// <param name="createdBy"></param>
        /// <returns></returns>
        public async Task<List<int>> AddWorkflowUsersAsync(string? userIdList, string? role, int? affiliateId,string? managerID, string? createdBy)
        {
            return await ExecuteQueryWFListAsync<int>(
                SPConstant.ADM_ADD_WORKFLOW_USER_TO_ROLE,
                new
                {
                    userIDList = userIdList,
                    role = role,
                    affiliate_id = affiliateId,
                    managerID = managerID,
                    createdBy = createdBy
                });
            
        }


        /// <summary>
        /// To fetch valid workflow roles
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<GetRolesRoleIdByUserIdStoredProcResponse>> GetValidWorkflowRoles()
        {
            return await ExecuteQueryListAsync<GetRolesRoleIdByUserIdStoredProcResponse>(
                SPConstant.USP_ADM_GET_VALID_WORKFLOW_ROLES,
                new
                {
                    
                });
            
            
        }


        public async Task<List<GetWorkFlowUserRolesStoredProcedureResponse>> GetWorkflowUserRoles()
        {
            return await ExecuteQueryListAsync<GetWorkFlowUserRolesStoredProcedureResponse>(
                SPConstant.USP_UI_GET_WORKFLOW_ROLES,
                new
                {

                });

            
        }


        /// <summary>
        /// To delete a workflow user's role
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="role"></param>
        /// <param name="plantID"></param>
        /// <param name="updatedBy"></param>
        /// <returns></returns>
        public async Task<DeleteWorkflowUserStoredProcedureResponse> DeleteWorkflowUserAsync(string? userId, string? role, string? updatedBy)
        {
            return await ExecuteQueryWFAsync<DeleteWorkflowUserStoredProcedureResponse>
                (
                    SPConstant.ADM_DELETE_WORKFLOW_USER_BY_ROLE,
                    new
                    {
                        userID = userId,
                        role = role,
                        updatedBy = updatedBy
                    }
                );
            
        }


        public async Task<bool> LogoutUserAsync(int userId)
        {
            using (var connection = new SqlConnection(eoWebDashConString))
            {
                await connection.OpenAsync();
                await connection.QueryAsync(SPConstant.ADM_LOGOUT_AND_END_SESSION_BY_USER, new { userID = userId }, commandType: System.Data.CommandType.StoredProcedure);
                return true;
            }
        }
        public async Task<GetRolesRoleIdByUserIdStoredProcResponse> GetUserRoleByIdAsync(int userID, HttpContext context)
        {
            var query = SPConstant.ADM_GET_ROLESBYUSERID;
            try
            {
                GetRolesRoleIdByUserIdStoredProcResponse userRole;
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();

                    var parameters = new { userID = userID };

                    var result = await connection.QueryAsync<GetRolesRoleIdByUserIdStoredProcResponse>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    userRole = result.FirstOrDefault()!;
                    var urlRequested = context.Request.Path;
                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(result, query, result.Count(), elapsedTime, urlRequested, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return userRole;
            }
            catch (Exception ex)
            {
                var urlRequested = context.Request.Path;
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, urlRequested, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }
    }
}
