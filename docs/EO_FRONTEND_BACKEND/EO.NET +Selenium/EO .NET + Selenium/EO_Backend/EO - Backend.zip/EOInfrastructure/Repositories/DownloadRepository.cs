﻿using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Config;
using EODomain.Models.Download;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class DownloadRepository:CentralRepository, IDownloadRepository
    {
        public DownloadRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
             base(configuration, httpContextAccessor, "EODashboardConnection")
        {
        }

        public async Task<List<GetDownloadTagListResponse>> GetDownloadTagListAsync(GetDownloadTagListRequest request)
        {
            return await ExecuteQueryListAsync<GetDownloadTagListResponse>(
                                    SPConstant.USP_UI_GET_DOWNLOAD_TAG_LIST,
                                    new
                                    {
                                        plantidlist = request.plantIDList
                                    });
        }



        public async Task<dynamic> GetDownloadDataAsync(DownloadDataRequest model)
        {

            return await ExecuteQueryListAsync<dynamic>(
            SPConstant.USP_UI_GET_DOWNLOAD_DATA,
            new
            {
                Tag_names = model.tagNames,
                PlantID_list = model.plantID_list,
                sTime = model.sTime,
                eTime = model.eTime
            });
        }


        public async Task<dynamic> GetCaseWiseDownloadDataAsync(DownloadCaseWiseDataRequest request)
        {
            var data= await ExecuteQueryListAsync<dynamic>(SPConstant.USP_GET_CASE_WISE_DOWNLOAD_DATA,
                             new
                             {
                                 tagIdList = request.tagIdList,
                                 caseId = request.caseId,
                                 sTime = request.sTime,
                                 eTime = request.eTime
                             });

            data = data.Select(row =>
            {
                var dict = (IDictionary<string, object>)row;
                if (dict.TryGetValue("timeStamp", out object? value) && value is DateTime dt)
                {
                    dict["timeStamp"] = dt.ToString("yyyy-MM-dd HH:mm:ss");
                }
                return row;
            }
           ).ToList();
            return data;
        }
    }
}
