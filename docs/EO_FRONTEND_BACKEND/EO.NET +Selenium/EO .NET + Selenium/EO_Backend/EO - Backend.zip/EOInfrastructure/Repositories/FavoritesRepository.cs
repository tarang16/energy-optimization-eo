﻿using Dapper;
using System.Data;
using Newtonsoft.Json;
using EODomain.Common;
using EODomain.Models;
using EODomain.Models.Favorites;
using EOApplication.Contracts.Repositories;
using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Http;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Configuration;
using static System.Runtime.InteropServices.JavaScript.JSType;
using EODomain.Models.Account;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using System.Reflection.Metadata;
using System.Data.Common;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class FavoritesRepository : CentralRepository, IFavoritesRepository
    {
        public FavoritesRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")
        {
        }


        /// <summary>
        /// To fetch favorite pages book marked by a user.
        /// SP used: [dbo].[usp_ui_get_favorite_by_user_id]
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public async Task<List<GetFavoriteByUserIDStoredProcedureResponse>> GetFavoriteByUserIDAsync(int userID)
        {
            return await ExecuteQueryListAsync<GetFavoriteByUserIDStoredProcedureResponse>
                (SPConstant.UI_GET_FAVORITE_BY_USER_ID,
                new
                {
                    userID = userID
                });
        }


        /// <summary>
        /// To bookmark the input URL and title for the user.
        /// SP used: [dbo].[usp_ui_add_favorite_by_user_id]
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<PostAddFavoriteByUserIDStoredProcedureResponse>> PostAddFavoriteByUserIDAsync(PostAddFavoriteByUserIDRequest request)
        {
            return await ExecuteQueryListAsync<PostAddFavoriteByUserIDStoredProcedureResponse>
                (SPConstant.UI_ADD_FAVORITE_BY_USER_ID,
                new
                {
                    userID = request.userID,
                    url = request.url,
                    title = request.title
                });
        }

        
        /// <summary>
        /// To delete a page bookmarked by the user.
        /// SP used: [dbo].[usp_ui_delete_favorite_by_fav_id]
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<PostDeleteFavoriteByFavIDStoredProcedureResponse>> PostDeleteFavoriteByFavIDAsync(PostDeleteFavoriteByFavIDRequest request)
        {
            return await ExecuteQueryListAsync<PostDeleteFavoriteByFavIDStoredProcedureResponse>
                (SPConstant.UI_DELETE_FAVORITE_BY_FAV_ID,
                new
                {
                    ID = request.ID,
                    userID = request.userID
                });            
        }


        /// <summary>
        /// To add a trend plot as favorite for the user.
        /// SP used: [dbo].[usp_ui_add_favorite_trend_by_user_id]
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<FavTrendRequest> PostAddFavoriteTrendByUserIDAsync(int userID, PostFavTrendByUserID requestOne)
        {
            string tagsJson = JsonConvert.SerializeObject(requestOne.TagDetails);
            return await ExecuteQueryAsync<FavTrendRequest>
                (SPConstant.UI_ADD_FAVTREND_BY_CASE_ID,
                new
                {
                    UserID = userID,
                    Url = requestOne.url,
                    STime = requestOne.sTime,
                    ETime = requestOne.eTime,
                    Title = requestOne.title,
                    tagDetails = tagsJson,
                    CaseID = requestOne.caseID,
                    subTitle = requestOne.subTitle,
                    chartType = requestOne.chartType,
                    timeParameter = requestOne.timeParameter,
                    xAxisTagDetail = requestOne.xAxisTagDetail,
                    isMonitoringXY = Convert.ToInt32(requestOne.isMonitoringXY),
                    skipModel = Convert.ToInt32(requestOne.skipModel)
                });
        }

        /// <summary>
        /// To remove a trend plot from favorites for the user.
        /// SP used: [dbo].[usp_ui_delete_favorite_trend_by_case_id]
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<FavTrendRequest> PostDeleteFavoriteTrendByUserIDAsync(int userID, Guid FavID)
        {
            return await ExecuteQueryAsync<FavTrendRequest>
                (SPConstant.UI_DELETE_FAVTREND_BY_CASE_ID,
                new
                {
                    userID = userID,
                    favID = FavID
                });
        }

        /// <summary>
        /// To fetch bookmarked trend plots for a user.
        /// SP used: [dbo].[usp_ui_get_favorite_trend_by_user_id]
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<IEnumerable<dynamic>> GetFavoriteTrendByUserDAsync(int userID, Guid FavID)
        {
           return await ExecuteQueryListAsync<dynamic>
                (SPConstant.UI_GET_FAVTREND_BY_CASE_ID,
                new
                {
                    favID = FavID
                });
            
        }

        /// <summary>
        /// To fetch bookmarked trend plots for a user.
        /// SP used: [dbo].[usp_ui_get_favorite_trend_by_user_id]
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<IEnumerable<dynamic>> GetAllFavoriteTrendByFavIDAsync(int userID)
        {
            return await ExecuteQueryListAsync<dynamic>
                (SPConstant.UI_GET_ALL_FAVTREND_BY_CASE_ID,
                new
                {
                    userID = userID
                });
        }


        /// <summary>
        /// To add/update/delete user preferences
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="preferences"></param>
        /// <returns></returns>
        public async Task<int?> PostUserPreferencesAsync(int userID, string? key, string? parameter, string? data)
        {
            return await ExecuteQueryAsync<int>
                    (SPConstant.USP_UI_ADD_USER_PREFERENCES,
                    new
                    {
                        userID = userID,
                        keys = key,
                        parameter = parameter,
                        data = data
                    });

        }
        
        
        /// <summary>
        /// To fetch user preferences
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public async Task<List<GetUserPreferencesStoredProcedureResponse>> GetUserPreferencesAsync(int userID, string? key, string? parameter)
        {
            return await ExecuteQueryListAsync<GetUserPreferencesStoredProcedureResponse>
                (SPConstant.USP_UI_GET_USER_PREFERENCES_BY_USER_ID,
                new
                {
                    userID = userID,
                    keys = key,
                    parameter = parameter
                });
        }


        /// <summary>
        /// To delete user preferences
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="key"></param>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public async Task<bool> DeleteUserPreferencesAsync(string IDs)
        {
            return await ExecuteQueryAsync<bool>
                (SPConstant.USP_UI_DELETE_USER_PREFERENCES,
                new
                {
                    ids = IDs
                });
        }
    }
}
