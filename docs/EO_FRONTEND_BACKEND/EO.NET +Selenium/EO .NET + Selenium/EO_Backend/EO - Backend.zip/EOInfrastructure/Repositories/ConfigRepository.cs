﻿using Dapper;
using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Config;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class ConfigRepository : CentralRepository, IConfigRepository
    {

        private readonly string eoWebDashConString;

        public ConfigRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")

        {
            eoWebDashConString = configuration.GetConnectionString("EODashboardConnection")!;
        }


        /// <summary>
        /// To fetch data caseID, name and its associated plant, affiliate, sub-region,
        /// country, region etc. Used for navigation in the dashboard.
        /// SP used: [dbo].[usp_ui_get_casehierachy] 
        /// </summary>
        /// <returns></returns>
        public async Task<List<GetCaseHierarchyResponse>> GetCaseHierarchyAsync()
        {
            return await ExecuteQueryListAsync<GetCaseHierarchyResponse>(
                SPConstant.UI_GET_CASEHIERACHY, null!);
        }

        /// <summary>
        /// To fetch data for home page of the dashboard like opportunity numbers,
        /// their split across regions, affiliates, etc.
        /// SP used: [dbo].[usp_ui_get_overviewhome]
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public async Task<List<GetLandingCorporateSPResponse>> GetLandingCorporateAsync(string? caseIDList)
        {
            return await ExecuteQueryListAsync<GetLandingCorporateSPResponse>(
                SPConstant.UI_GET_LANDINGCORPORATE,
                new
                {
                    case_id_list = caseIDList,
                });
        }

        /// <summary>
        /// To fetch data for affiliate homepage like opportunity numbers and 
        /// its split across all the plants and systems.
        /// SP used: [dbo].[usp_ui_get_overviewregion]
        /// </summary>
        /// <param name="region"></param>
        /// <returns></returns>
        public async Task<List<GetLandingCorporateSPResponse>> GetLandingAffiliateAsync(string affiliate, string? plantIDList)
        {
            return await ExecuteQueryListAsync<GetLandingCorporateSPResponse>(
                SPConstant.UI_GET_LANDINGAFFILIATE,
                new
                {
                    affiliate = affiliate,
                    plantIDList = plantIDList,
                });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sessionID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public async Task<bool> LogoutUserAsync(int userId)
        {
            using (var connection = new SqlConnection(eoWebDashConString))
            {
                await connection.OpenAsync();
                await connection.QueryAsync(SPConstant.ADM_LOGOUT_AND_END_SESSION_BY_USER, new { userID = userId }, commandType: System.Data.CommandType.StoredProcedure);
                return true;
            }
        }

        /// <summary>
        /// To fetch data dictionary based on tablename
        /// </summary>
        /// <param name="tablename"></param>
        /// <returns></returns>
        public async Task<List<GetViewDataDictionaryByTableNameResponse>> GetViewDataDictionaryByTableNameAsync(GetViewDataDictionaryByTableNameRequest request)
        {
            return await ExecuteQueryListAsync<GetViewDataDictionaryByTableNameResponse>(
                        SPConstant.USP_UI_GET_VIEW_DATA_DICTIONARY_BY_TABLENAME,
                        new
                        {
                            tablenamelist = request.TableNameList
                        });
        }

        public async Task<List<GetCaseInfoByByCaseIdListResponse>> GetCaseInfoByCaseIdListAsync(CaseIdListRequest request)
        {
            return await ExecuteQueryListAsync<GetCaseInfoByByCaseIdListResponse>(
                        SPConstant.GET_CASE_INFO_BY_CASE_ID_LIST,
                        new
                        {
                            caseIDList = request.caseIdList
                        });
        }

        public async Task<dynamic> GetUomAsync()
        {
            return await ExecuteQueryListAsync<dynamic>(
                        SPConstant.USP_EO_EM_GET_UOM,
                        new
                        {
                           
                        });
        }

        public async Task<List<GetLandingAffiliateSustainabilityCardResponse>> GetLandingAffiliateScoreCardAsync(int affiliateID, string upto)
        {
            return await ExecuteQueryListAsync<GetLandingAffiliateSustainabilityCardResponse>(
                        SPConstant.UI_GET_LANDING_AFFILIATE_SCORECARD,
                        new
                        {
                            affiliateID = affiliateID,
                            upto = upto,
                        });
        }


        public async Task<dynamic> GetScreenNamesByAffiliateIDsAsync(GetUserStatisticsScreensRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                        SPConstant.UI_GET_USER_STATISTICS_SCREEN_NAMES,
                        new
                        {
                            affiliateIDs = request.affiliateIDs,
                            screenName = request.screenName,
                        });
        }

        public async Task<int> GetAffiliateIDByCaseID(int caseID)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.USP_UI_GET_AFFILIATE_ID_BY_CASE_ID,
                    new
                    {
                        caseID = caseID
                    }
                );
        }

        public async Task<int> GetAffiliateIDByDerivedEquationId(int derivedEquationId)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.USP_UI_GET_AFFILIATE_ID_BY_DERIVED_EQUATION_ID,
                    new
                    {
                        derivedEquationId = derivedEquationId
                    }
                );
        }

        public async Task<int> GetAffiliateIDByVariableId(int variableId)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.USP_UI_GET_AFFILIATE_ID_BY_VARIABLE_ID,
                    new
                    {
                        variableId = variableId
                    }
                );
        }

        public async Task<int> GetAffiliateIDByConstraintId(int constraintId)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.USP_UI_GET_AFFILIATE_ID_BY_CONSTRAINT_Id,
                    new
                    {
                        constraintId = constraintId
                    }
                );
        }

        public async Task<int> GetAffiliateIDByModelTagId(int modelTagId)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.USP_UI_GET_AFFILIATE_ID_BY_MODEL_TAG_Id,
                    new
                    {
                        modelTagId = modelTagId
                    }
                );
        }

        public async Task<int> GetAffiliateIDByObjectiveId(int objectiveId)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.USP_UI_GET_AFFILIATE_ID_BY_OBJECTIVE_ID,
                    new
                    {
                        objectiveId = objectiveId
                    }
                );
        }

        public async Task<int> GetAffiliateIDByModelId(int modelId)
        {
            return await ExecuteQueryAsync<int>
                (
                    SPConstant.USP_UI_GET_AFFILIATE_ID_BY_MODEL_Id,
                    new
                    {
                        modelId = modelId
                    }
                );
        }


        public async Task<List<GetWalkthroughDataByPagekeyResponse>> GetWalkthroughDataByPageKey(GetWalkthroughDataByPagekeyRequest request)
        {
            return await ExecuteQueryListAsync<GetWalkthroughDataByPagekeyResponse>(
                SPConstant.USP_UI_GET_WALKTHROUGH_DATA_BY_PAGEKEY,
                new
                {
                    pageKey = request.pageKey,
                });
        }
    }
}
