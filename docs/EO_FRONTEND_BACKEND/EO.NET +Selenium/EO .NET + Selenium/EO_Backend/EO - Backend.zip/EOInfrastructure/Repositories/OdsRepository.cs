﻿using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Ods;
using EODomain.Models.WinAuth;
using EOInfrastructure.Utility;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Microsoft.AspNetCore.Hosting;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class OdsRepository : CentralRepository, IOdsRepository
    {
        
       
        
        public OdsRepository(IConfiguration configuration,IHttpContextAccessor httpContextAccessor) :
            base(configuration,httpContextAccessor, "EODashboardConnection")
        {
           
                
            

        }
        public async Task<List<GetPeOdsDetailsByOdsIdListTimeStoredProcResponse>> GetOdsOveriewByCaseIdTimeAsync(OdsCaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<GetPeOdsDetailsByOdsIdListTimeStoredProcResponse>
                (SPConstant.GET_ODS_OVERVIEW_BY_CASE_ID_TIME,
                new
                {
                    caseId = request.caseID,
                    time = request.time,
                });
        }

        /// <summary>
        /// To fetch effect and business kpi tags for a caseID
        /// SP used: [dbo].[usp_ui_get_ods_kpi_tag_by_case_id]
        /// </summary>
        /// <param name="caseID"></param>
        /// <returns></returns>
        public async Task<List<GetOdsKpiTagByCaseIDStoredProcedureResponse>> GetOdsKpiTagByCaseIDAsync(int caseID)
        {
            return await ExecuteQueryListAsync<GetOdsKpiTagByCaseIDStoredProcedureResponse>(
                        SPConstant.UI_GET_GETODSKPITAGBYCASEID,
                        new
                        {
                            caseID = caseID
                        });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <param name="sTime"></param>
        /// <param name="eTime"></param>
        /// <returns></returns>
        public async Task<List<GetOdsDataByCaseIDListTimeRangeReqIDResponse>> GetOdsDataByCaseIDListTimeRangeReqIDAsync(string caseIDList, string? sTime , string? eTime )
        {
            return await ExecuteQueryListAsync<GetOdsDataByCaseIDListTimeRangeReqIDResponse>(
                        SPConstant.USP_UI_GET_ODS_DATA_BY_CASE_ID_LIST_TIME_RANGE_REQ_ID,
                        new
                        {
                            caseIDList = caseIDList,
                            sTime = sTime,
                            eTime = eTime
                        },
                        commandTime: 200); // setting timeout to 200 seconds for ODS API
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<GetOdsAlertStatisticsByCaseIDListResponse> GetOdsAlertStatisticsByCaseIDList(OdsCaseIdListRequest request)
        {
            return await ExecuteQueryAsync<GetOdsAlertStatisticsByCaseIDListResponse>(
            SPConstant.UI_GET_ODS_ALERT_STATISTICS_BY_CASE_ID_LIST,
            new
            {
                fromDate = request.fromDate,
                caseIDList = request.caseIdList
            });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<List<GetOdsAlertStatisticsForRoleResponse>> GetOdsAlertStatisticsForRole(OdsCaseIdListRequest request)
        {
            return await ExecuteQueryListAsync<GetOdsAlertStatisticsForRoleResponse>(
            SPConstant.UI_GET_ODS_ALERT_STATISTICS_FOR_ROLE,
            new
            {
                fromDate=request.fromDate,
                caseIDList = request.caseIdList,
            });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<List<GetOdsAlertStatisticsPendingAlertsResponse>> GetOdsAlertStatisticsPendingAlerts(OdsCaseIdListRequest request)
        {
            return await ExecuteQueryListAsync<GetOdsAlertStatisticsPendingAlertsResponse>(
            SPConstant.USP_UI_GET_ODS_ALERT_STATISTICS_PENDING_ALERTS,
            new
            {
                fromDate=request.fromDate,
                caseIDList =request.caseIdList ,
            });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<List<GetOdsAlertStatisticsOverdueAlertsResponse>> GetOdsAlertStatisticsOverDueAlerts(OdsCaseIdListRequest request)
        {
            return await ExecuteQueryListAsync<GetOdsAlertStatisticsOverdueAlertsResponse>(
                        SPConstant.USP_UI_GET_ODS_ALERT_STATISTICS_OVERDUE_ALERTS,
                        new
                        {
                            fromDate=request.fromDate,
                            caseIDList = request.caseIdList,
                        });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<List<GetOdsAlertStatisticsInProgressAlertsResponse>> GetOdsAlertStatisticsInProgressAlerts(OdsCaseIdListRequest request)
        {
            return await ExecuteQueryListAsync<GetOdsAlertStatisticsInProgressAlertsResponse>(
                        SPConstant.USP_UI_GET_ODS_ALERT_STATISTICS_INPROGRESS_ALERTS,
                        new
                        {
                            fromDate=request.fromDate,
                            caseIDList = request.caseIdList,
                        });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        public async Task<GetOdsClosedAlertStatisticsByCaseIDListResponse> GetOdsClosedAlertStatisticsByCaseIDList(string caseIDList, DateTime month)
        {
            return await ExecuteQueryAsync<GetOdsClosedAlertStatisticsByCaseIDListResponse>(
                        SPConstant.USP_UI_GET_ODS_ALERT_STATISTICS_UTILIZATION_REPORT,
                        new
                        {
                            caseIDList = caseIDList,
                            Month = month
                        });
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="caseIDList"></param>
        /// <returns></returns>
        public async Task<List<GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsResponse>> GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsAsync(OdsCaseIdListRequest request)
        {
            return await ExecuteQueryListAsync<GetOdsClosedAlertStatisticsStatisticsTargetModifiedAlertsResponse>(
                        SPConstant.USP_UI_GET_ODS_ALERT_STATISTICS_TARGETMODIFIED_ALERTS,
                        new
                        {
                            fromDate=request.fromDate,
                            caseIDList = request.caseIdList,
                        });
        }

        /// <summary>
        /// To fetch alerts associated with a caseID and input status
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<GetOdsAlertStatisticsByCaseIdListAndStateStoredProcedureResponse>> GetOdsAlertStatisticsByCaseIdListAndStateAsync(GetOdsAlertStatisticsByCaseIdListAndStateRequest request)
        {
            return await ExecuteQueryListAsync<GetOdsAlertStatisticsByCaseIdListAndStateStoredProcedureResponse>
                (
                    SPConstant.USP_UI_GET_ODS_ALERT_STATITICS_CLOSED_ALERTS,
                    new
                    {
                        fromDate=request.fromDate,
                        caseIDList = request.caseIDList,
                        Status = request.status
                    }
                );
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<GetOdsTrendDataByRequestIdAndTimeRangeStoredProcedureResponse>> GetOdsTrendDataByRequestIdAndTimeRangeAsync(RequestIdTimeStringRangeRequest request)
        {
            return await ExecuteQueryListAsync<GetOdsTrendDataByRequestIdAndTimeRangeStoredProcedureResponse>
                (
                    SPConstant.USP_UI_GET_ODS_TREND_DATA_BY_REQUEST_ID,
                    new
                    {
                        requestID = request.requestId,
                        sTime = request.sTime,
                        eTime = request.eTime
                    }
                );
        }

        /// <summary>
        /// This repository method is used to get dds alter statistics data from the database.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<dynamic> GetOdsAlertStatisticsDownloadDataAsync(OdsStatisticsDownloadDataRequest model)
        {

            return await ExecuteQueryMultipleReturnDynamicResultAsync(
            SPConstant.USP_UI_GET_ODS_ALERT_STATISTICS_DOWNLOAD_DATA,
            new
            {
                fromDate=model.fromDate,
                caseIDList = model.caseIdList
            });
        }
        public async Task<string> UpdatemutealertslogByCauseIdListAsync(UpdateMuteAlertsLogByCauseId request)
        {
            return await ExecuteQueryWFAsync<string>(
            SPConstant.USP_UI_UPDATE_MUTE_ALERTS_LOGS_BY_CAUSEID,
            new
            {
                CauseIdList = request.CauseIdList,
                updatedBy=request.updatedBy
            });
        }

        public async Task<List<dynamic>> GetmutealertslogAsync(MuteAlertsLogRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
            SPConstant.USP_UI_GET_MUTE_ALERTS_LOGS,
            new
            {
                affiliateId = request.affiliateId,
                active = request.active
            });
        }

        public async Task<List<GetPeOdsIdDetailsByCaseIdTimeStoredProcResponse>> GetPeOdsIdDetailsByCaseIdTimeAsync(OdsCaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<GetPeOdsIdDetailsByCaseIdTimeStoredProcResponse>
                (SPConstant.GET_PE_ODS_ID_Details_BY_CASE_ID_TIME,
                new
                {
                    caseId = request.caseID,
                    timeStamp = request.time,
                });
        }

        public async Task<List<GetPeOdsDetailsByOdsIdListTimeStoredProcResponse>> GetPeOdsDetailsByOdsIdListTimeAsync(OdsDetailsByOdsIdListTimeRequest request)
        {
            return await ExecuteQueryListAsync<GetPeOdsDetailsByOdsIdListTimeStoredProcResponse>
                (SPConstant.GET_PE_ODS_Details_BY_ODS_ID_LIST_TIME,
                new
                {
                    Odsidslist = request.OdsIdList,
                    timeStamp = request.time,
                }, "", 30, true);
        }


        /// <summary>
        /// To update PEODS Alert Details
        /// SP used: [dbo].[usp_ods_update_PEODSAlertDetails]
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<string> UpdatePeOdsAlertDetailsAsync(UpdatePeOdsAlertDetails request)
        {
            return await ExecuteQueryAsync<string>(SPConstant.USP_ODS_UPDATE_PEODSAlertDetails,
                new
                {
                    requestID = request.requestID,
                    modifiedBy = request.modifiedBy,
                    status = request.status,
                    assignedTo = request.assignedTo,
                    stageID = request.stageID,
                    targetDate = request.targetDate,
                    actionID = request.actionID
                });
        }

        public async Task<List<dynamic>> GetOdsAlertStatisticsDownloadDataComments(OdsCaseIdListRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(SPConstant.USP_UI_GET_ODS_ALERT_STATISTICS_DOWNLOAD_DATA_COMMENTS, new
            {
                caseIdList = request.caseIdList,

                fromDate = request.fromDate
            });
        }

    }
}