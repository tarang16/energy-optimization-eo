﻿using Dapper;
using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Admin;
using EODomain.Models.LogTables;
using EODomain.Models.Search;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class AdminRepository : CentralRepository, IAdminRepository
    {
        private readonly string eoWebDashConString;
        private readonly string URL;

        public AdminRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) : base(configuration, httpContextAccessor, "EODashboardConnection")
        {
            eoWebDashConString = configuration.GetConnectionString("EODashboardConnection")!;
            URL = httpContextAccessor.HttpContext! == null ? null! : $"{httpContextAccessor!.HttpContext!.Request.Path}";
        }

        /// <summary>
        /// To fetch data for user activity using sessionID
        /// </summary>
        /// <param name="sessionID"></param>
        public async Task<GetUserActivityStaticDataBySessionIDStoredProcedureResponse> GetUserActivityStaticDataBySessionIDAsync(string sessionID)
        {
            var result = await ExecuteQueryAsync<GetUserActivityStaticDataBySessionIDStoredProcedureResponse>(
                SPConstant.ADM_GET_STATIC_DATA_BY_SESSION_ID,
                new
                {
                    sessionID = sessionID
                });
            return result;
        }

        /// <summary>
        /// To fetch data for user activity using sessionID
        /// </summary>
        /// <param name="sessionID"></param>
        public async Task<GetUserActivityDynamicDataBySessionIDRepositoryResponse> GetUserActivityDynamicDataBySessionIDAsync(string sessionID, int pageNumber, int pageSize)
        {
            var response = new GetUserActivityDynamicDataBySessionIDRepositoryResponse();
            var parameters = new DynamicParameters();
            parameters.Add("@sessionID", sessionID);
            parameters.Add("@pageNumber", pageNumber);
            parameters.Add("@pageSize", pageSize);
            var result = await ExecutePaginatedQueryListAsync<GetUserActivityDynamicDataBySessionIDStoredProcedureResponse, int>(
               SPConstant.ADM_GET_DYNAMIC_DATA_BY_SESSION_ID, parameters);
            response.data = result.result;
            response.pageCount = result.pageCount;
            return response;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="errorID"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public async Task<bool> ModifyErrorStatusByErrorID(int errorID, string? status, string? assignedTo)
        {
              await ExecuteQueryAsync<object>(
                        SPConstant.ADM_MODIFY_STATUS_IN_ERROR_LOGGING,
                        new
                        {
                            status = status,
                            errorID = errorID.ToString(),
                            assignedTo = assignedTo
                        });
            ///Add some ffed back in sp
            return true;
        }


        /// <summary>
        /// To get list of valid error status
        /// </summary>
        /// <returns></returns>
        public async Task<List<string>> GetValidErrorStatusList()
        {
            string query = SPConstant.USP_UI_VALID_ERROR_STATUS;
            try
            {
                List<string> validStatus;
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();

                    var result = await connection.QueryAsync<string>(query, commandType: System.Data.CommandType.StoredProcedure);
                    validStatus = result.ToList();
                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(result, query, result.Count(), elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                    return validStatus;
                }
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }

        /// <summary>
        /// To fetch login data from login tracking data
        /// </summary>
        /// <param name="sessionGuid"></param>
        /// <returns></returns>
        public async Task<GetActivityTrackerLogsRepositoryLayerResponse> GetActivityTrackerLogsAsync(Dictionary<string, object> request, int pageNumber, int pageSize)
        {
            int searchStatus = 0;
            if (request.Count > 0)
            {
                searchStatus = 1;
            }
            var parameters = new DynamicParameters();
            foreach (var item in request)
            {
                parameters.Add($"@{item.Key}", item.Value);
            }
            parameters.Add("@pageSize", pageSize);
            parameters.Add("@pageNumber", pageNumber);
            parameters.Add("@searchStatus", searchStatus);
            parameters.Add("@pageCount", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);
            var result = await ExecuteQueryListAsync<GetActivityTrackerLogsStoredProcedureResponse>(
                         SPConstant.ADM_GET_ACTIVITY_TRACKER_LOGS, parameters);
            GetActivityTrackerLogsRepositoryLayerResponse getActivityLogs = new GetActivityTrackerLogsRepositoryLayerResponse();
            getActivityLogs.data = result.ToList()!;
            getActivityLogs.pageCount = parameters.Get<int>("@pageCount");
            return getActivityLogs;


        }


        /// <summary>
        /// To fetch login data from login tracking data
        /// </summary>
        /// <param name="sessionGuid"></param>
        /// <returns></returns>
        public async Task<GetApiRequestLogsRepositoryLayerResponse> GetApiRequestLogsAsync(Dictionary<string, object> requestData, int pageNumberOne, int pageSizeOne)
        {
            int searchStatus = 0;
            if (requestData.Count > 0)
            {
                searchStatus = 1;
            }
            var parameters = new DynamicParameters();
            foreach (var item in requestData)
            {
                parameters.Add($"@{item.Key}", item.Value);
            }
            parameters.Add("@pageNumber", pageNumberOne);
            parameters.Add("@pageSize", pageSizeOne);
            parameters.Add("@searchStatus", searchStatus);
            parameters.Add("@pageCount", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);
            var result = await ExecuteQueryListAsync<GetApiRequestLogsStoredProcedureResponse>(
            SPConstant.ADM_GET_API_REQUEST_LOGS, parameters);
                GetApiRequestLogsRepositoryLayerResponse getApiRequestLogs = new GetApiRequestLogsRepositoryLayerResponse();
            getApiRequestLogs.data = result.ToList()!;
            getApiRequestLogs.pageCount = parameters.Get<int>("@pageCount");
           
                return getApiRequestLogs;


           
        }


        /// <summary>
        /// To fetch login data from login tracking data
        /// </summary>
        /// <param name="sessionGuid"></param>
        /// <returns></returns>
        public async Task<GetQueryTrackerLogsRepositoryLayerResponse> GetQueryTrackerLogsAsync(Dictionary<string, object> request, int pageNumberTwo, int pageSizeTwo)
        {
            int searchStatus = 0;
            if (request.Count > 0)
            {
                searchStatus = 1;
            }
            var parameters = new DynamicParameters();
            foreach (var item in request)
            {
                parameters.Add($"@{item.Key}", item.Value);
            }
            parameters.Add("@pageNumber", pageNumberTwo);
            parameters.Add("@pageSize", pageSizeTwo);
            parameters.Add("@searchStatus", searchStatus);
            parameters.Add("@pageCount", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);
            var result = await ExecuteQueryListAsync<GetQueryTrackerLogsStoredProcedureResponse>(
            SPConstant.ADM_GET_QUERY_TRACKER_LOGS, parameters);
            GetQueryTrackerLogsRepositoryLayerResponse RequestLogs = new GetQueryTrackerLogsRepositoryLayerResponse();
            RequestLogs.data = result.ToList()!;
            RequestLogs.pageCount = parameters.Get<int>("@pageCount");

            return RequestLogs;

          
        }


        /// <summary>
        /// To fetch login data from login tracking data
        /// </summary>
        /// <param name="sessionGuid"></param>
        /// <returns></returns>
        public async Task<GetPerformanceLogsRepositoryLayerResponse> GetPerformanceLogsAsync(PaginatedSearch paginatedSearch)
        {

            paginatedSearch.query = SPConstant.ADM_GET_PERFORMANCE_LOGS!;
            var result = await ExecuteQueryPaginatedListAsync<GetPerformanceLogsStoredProcedureResponse, int>(paginatedSearch);

            GetPerformanceLogsRepositoryLayerResponse requestLogs = new GetPerformanceLogsRepositoryLayerResponse();
            requestLogs.data = result.result.ToList()!;
            requestLogs.pageCount = result.pageCount;
            return requestLogs;
        }

        /// <summary>
        /// To fetch logs from error logging table
        /// </summary>
        /// <param name="sessionGuid"></param>
        /// <returns></returns>
        public async Task<GetErrorTrackingRepositoryLayerResponse> GetErrorLogsAsync(PaginatedSearch paginatedSearch)
        {
            paginatedSearch.query = SPConstant.ADM_GET_ERROR_TRACKING_LOGS!;
            var result = await ExecuteQueryPaginatedListAsync<GetErrorTrackingStoredProcedureResponse, int>(paginatedSearch);

            GetErrorTrackingRepositoryLayerResponse requestLogs = new GetErrorTrackingRepositoryLayerResponse();
            requestLogs.data = result.result.ToList()!;
            requestLogs.pageCount =result.pageCount;

            return requestLogs;
        }


            /// <summary>
            /// To fetch login data from login tracking data
            /// </summary>
            /// <param name="sessionGuid"></param>
            /// <returns></returns>
            /// 
            public async Task<GetLoginTrackerRepositoryLayerResponse> GetLoginLogsAsync(PaginatedSearch paginatedSearch)
            {
                paginatedSearch.query = SPConstant.ADM_GET_LOGIN_ACTIVITY_LOGS!;
                var result = await ExecuteQueryPaginatedListAsync<GetLoginTrackerStoredProcedureResponse, int>(paginatedSearch);

                GetLoginTrackerRepositoryLayerResponse requestLogs = new GetLoginTrackerRepositoryLayerResponse();
                requestLogs.data = result.result.ToList()!;
                requestLogs.pageCount = result.pageCount;

                return requestLogs;
            }



            /// <summary>
            /// 
            /// </summary>
            /// <param name="request"></param>
            /// <returns></returns>
            public async Task<GetUserStatisticsStoredProcedureResponse> GetUserStatisticsAsync(GetUserStatisticsRequest request)
            {
            var query = SPConstant.USP_UI_GET_USERS_STATISTICS_COUNT;
            try
            {
                GetUserStatisticsStoredProcedureResponse response;
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();

                    var parameters = new
                    {
                        stime = request.sTime,
                        etime = request.eTime,
                        screenIds = request.screenIDs,
                        affiliateIds = request.affiliateIDs,
                    };

                    var result = await connection.QueryAsync<GetUserStatisticsStoredProcedureResponse>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    response = result.ToList()[0];

                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(result, query, result.Count(), elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<GetUserStatisticsLogsPaginatedResponse> GetUserStatisticsLogsAsync(GetUserStatisticsLogsRequest request)
        {
            var query = SPConstant.USP_UI_GET_USER_STATISTICS_LOGS;
            try
            {
                GetUserStatisticsLogsPaginatedResponse response = new GetUserStatisticsLogsPaginatedResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var parameters = new DynamicParameters();
                    parameters.Add("@pageNumber", request.pageNumber);
                    parameters.Add("@pageSize", request.pageSize);
                    parameters.Add("@stime", request.sTime);
                    parameters.Add("@etime", request.eTime);
                    parameters.Add("@affiliateIds", request.affiliateIDs);
                    parameters.Add("@asc_order", request.ascOrder);
                    parameters.Add("@screenids", request.screenIDs);
                    parameters.Add("@pageCount", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);

                    var result = await connection.QueryAsync<GetUserStatisticsLogsStoredProcedureResponse>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    response.data = result.ToList()!;

                    response.pageCount = parameters.Get<int>("@pageCount");
                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(result, query, result.Count(), elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<GetUserAnalyticsLogsPaginatedResponse> GetUserAnalyticsLogsAsync(GetUserAnalyticsLogsRequest request)
        {


            var query = SPConstant.USP_UI_GET_USER_ANALYTICS_LOGS;
            try
            {
                GetUserAnalyticsLogsPaginatedResponse response = new GetUserAnalyticsLogsPaginatedResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var parameters = new DynamicParameters();
                    parameters.Add("@pageNumber", request.pageNumber);
                    parameters.Add("@pageSize", request.pageSize);
                    parameters.Add("@stime", request.sTime);
                    parameters.Add("@etime", request.eTime);
                    parameters.Add("@asc_order", request.ascOrder);
                    parameters.Add("@employeeID", request.employeeID);
                    parameters.Add("@pageCount", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);

                    var result = await connection.QueryAsync<GetUserAnalyticsLogsStoredProcedureResponse>(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    response.data = result.ToList()!;
                    response.pageCount = parameters.Get<int>("@pageCount");
                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(result, query, result.Count(), elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<GetUserStatisticsGraphDataCombinedResponse> GetUserStatisticsGraphDataAsync(GetUserStatisticsGraphDataRequest request)
        {
            var query = SPConstant.USP_UI_GET_USERS_STATISTICS_GRAPH;
            try
            {
                GetUserStatisticsGraphDataCombinedResponse response = new GetUserStatisticsGraphDataCombinedResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();

                    var parameters = new
                    {
                        stime = request.sTime,
                        etime = request.eTime,
                        screenIds = request.screenIDs,
                        affiliateIds = request.affiliateIDs,
                        Daywise = request.dayWise,
                    };

                    var result = await connection.QueryMultipleAsync(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    response.timeWiseData = (await result.ReadAsync<GetUserStatisticsGraphDataStoredProcedureResponse>()).ToList();
                    response.distinctUsersData = (await result.ReadAsync<GetUserStatisticsGraphDataDistinctUsersStoredProcedureResponse>()).ToList();

                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(response.timeWiseData, query, response.timeWiseData.Count, elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<GetUserAnalyticsScreenWiseStoredProcedureResponse> GetUserAnalyticsScreenWiseAsync(GetUserAnalyticsScreenWiseRequest request)
        {
            var query = SPConstant.USP_UI_GET_USER_ANALYTICS_BY_SCREEN_WISE;
            try
            {
                GetUserAnalyticsScreenWiseStoredProcedureResponse response = new GetUserAnalyticsScreenWiseStoredProcedureResponse();
                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();

                    var parameters = new
                    {
                        stime = request.sTime,
                        etime = request.eTime,
                        screenIds = request.screenIDs,
                        employeeID = request.employeeId,
                    };

                    var result = await connection.QueryMultipleAsync(query, parameters, commandType: System.Data.CommandType.StoredProcedure);
                    response.screenWiseAccess = (await result.ReadAsync<ScreenNameWiseAccess>()).ToList()!;
                    response.dayWiseScreenAccess =(await result.ReadAsync<DayWiseScreenAccess>()).ToList()!;

                    string elapsedTime = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(response.screenWiseAccess, query, response.screenWiseAccess.Count, elapsedTime, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return response;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<List<GetUserStatisticsOnlineUsersStoredProcedureResponse>> GetUserStatisticsOnlineUsersAsync(GetUserStatisticsOnlineUsersRequest request)
        {
            var result = await ExecuteQueryListAsync<GetUserStatisticsOnlineUsersStoredProcedureResponse>(
                                SPConstant.USP_UI_GET_USER_STATISTICS_ONLINE_USERS,
                                new
                                {
                                    screenIds = request.screenIDs,
                                    affiliateIds = request.affiliateIDs,
                                });
            return result;
        }
    }
}
