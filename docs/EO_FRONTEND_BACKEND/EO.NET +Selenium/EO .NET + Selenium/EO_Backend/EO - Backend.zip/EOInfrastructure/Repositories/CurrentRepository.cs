﻿using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Current;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Diagnostics;
using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Data.SqlClient;
using Dapper;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class CurrentRepository : CentralRepository, ICurrentRepository
    {
        public readonly string eoWebDashConString;
        public readonly string URL;
        public CurrentRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")

        {
            eoWebDashConString = configuration.GetConnectionString("EODashboardConnection")!;
            URL = $"{httpContextAccessor.HttpContext!.Request.Path}";
        }

        public async Task<dynamic> GetKpiOutputAsync(int caseID, DateTime time)
        {
            return await ExecuteQueryListAsync<dynamic>
            (SPConstant.EO_UI_GET_KPI_OUTPUT,
            new
            {
                caseId = caseID,
                time = time 
            });
        }
        public async Task<dynamic> GetTimeActualDataAsync(int? caseID)
        {
            return await ExecuteQueryAsync<dynamic>
            (SPConstant.EO_UI_GET_TIME_ACTUAL,
            new
            {
                caseId = caseID,
            });
        }

        public async Task<List<GetSystemTopTileDataStoredProcResponse>> GetSystemTopTileDataAsync(int caseID, DateTime time)
        {
            return await ExecuteQueryListAsync<GetSystemTopTileDataStoredProcResponse>
            (SPConstant.EO_UI_GET_SYSTEM_TOP_TILE_OUTPUT,
            new
            {
                caseId = caseID,
                time = time
            });
        }

        public async Task<GetMonitoringDataStoredProcedurePaginatedResponse> GetMonitoringDataAsync(CaseIdDateTimeApiMonitoringRequest request)
        {
            string Query = SPConstant.EO_UI_GET_MONITORING_DATA.ToString();
            try
            {
                GetMonitoringDataStoredProcedurePaginatedResponse getMonitoringDataStoredProcedureResponse = new GetMonitoringDataStoredProcedurePaginatedResponse();

                using (var connection = new SqlConnection(eoWebDashConString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryMultipleAsync(SPConstant.EO_UI_GET_MONITORING_DATA, new { caseID = request.caseID, time = request.time, category = request.category, searchField = request.searchField, pageNumber = request.pageNumber, pageSize = request.pageSize }, commandType: System.Data.CommandType.StoredProcedure);
                    getMonitoringDataStoredProcedureResponse.pageCount = await result.ReadFirstAsync<int>();
                    getMonitoringDataStoredProcedureResponse.GetMonitoringDataStoredProcedureResponse = (await result.ReadAsync<GetMonitoringDataStoredProcedureResponse>()).ToList();
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(getMonitoringDataStoredProcedureResponse.GetMonitoringDataStoredProcedureResponse, Query, getMonitoringDataStoredProcedureResponse.GetMonitoringDataStoredProcedureResponse.Count, elapsed, URL, null);
                    await _commonRepositoryMethod.AddQueryTracker();
                }
                return getMonitoringDataStoredProcedureResponse;
            }
            catch (Exception ex)
            {
                var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, Query, null, null, URL, ex.Message);
                await _commonRepositoryMethod.AddQueryTracker();
                throw;
            }
        }

        public async Task<dynamic> GetTreeDiagramByCaseIDAsync(GetTreeDiagramByCaseIDRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
            (SPConstant.EO_UI_GET_TREE_DIAGRAM,
            new
            {
                caseID = request.caseId,
                timeStamp = request.timeStamp,
                category = request.category
            });
        }

        public async Task<dynamic> GetOverviewTrendDataAsync(int? caseID)
        {
            return await ExecuteQueryListAsync<dynamic>
            (SPConstant.EO_UI_GET_OVERVIEW_TREND_DATA,
            new
            {
                caseId = caseID,
            });
        }

        public async Task<dynamic> GetSeuOutputDataAsync(int caseID, DateTime time)
        {
            return await ExecuteQueryListAsync<dynamic>
                        (SPConstant.USP_UI_GET_SEU_OUTPUT_DATA,
                        new
                        {
                            caseId = caseID,
                            timestamp = time
                        });
        }

        public async Task<dynamic> GetSeecTrendDataAsync(CaseIdTimeRangeGroupByRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                                    (SPConstant.USP_EO_EM_GET_SEEC_TREND,
                                    new
                                    {
                                        caseId = request.caseID,
                                        sDate = request.sDate,
                                        eDate = request.eDate,
                                        groupBy=request.groupBy,
                                    });
        }

        /// <summary>
        /// To fetch enegry distribution
        /// SP used: [dbo].[usp_ui_get_enegry_distribution]
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<dynamic> GetEnegryDistributionAsync(CaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.USP_UI_GET_ENERGY_DISTRIBUTION,
                new
                {
                    caseID = request.caseID,
                    time = request.time
                });
        }

        public async Task<dynamic> GetKevsOutputAsync(CaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.USP_UI_EO_GET_KEVS_OUTPUT,
                new
                {
                    caseID = request.caseID,
                    time = request.time
                });
        }

        public async Task<dynamic> GetMonitoringCategories(GetMonitoringCategoriesRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
            (SPConstant.EO_UI_GET_MONITORING_CATEGORIES,
            new
            {
                caseID = request.caseID,
                
            });
        }

    }
}
