﻿using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.ECM;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class EcmRepository : CentralRepository, IEcmRepository
    {

        public EcmRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) : base(configuration, httpContextAccessor, "EODashboardConnection")
        {
        }

        public async Task<int?> AddEcmUploadInfo(int attachmentID, string attachmentName, int createdBy)
        {
            return await ExecuteQueryAsync<int>(SPConstant.USP_UI_ADD_TRN_ATTACHMENTS,
            new
            {
                AttachmentID = attachmentID,
                AttachmentName = attachmentName,
                CreatedBy = createdBy
            });
        }
        public async Task<GeEcmUploadInfoResponse> GeEcmUploadInfo(int attachmentID)
        {
            return await ExecuteQueryAsync<GeEcmUploadInfoResponse>(SPConstant.USP_UI_GET_TRN_ATTACHMENTS,
            new
            {
                attachmentID = attachmentID
            });
        }
        public async Task<int?> GetEcmNodeIdByCaseId(int caseId)
        {
            return await ExecuteQueryAsync<int?>(SPConstant.USP_GET_ECM_NODEID_BY_CASEID,
            new
            {
                caseId = caseId
            });
        }

        public async Task<List<GetWalkthroughDataByFurnacePagekeyEcmResponse>> GetdataByPageKey(GetWalkthroughDataByFurnaceEcmRequest request)
        {
            return await ExecuteQueryListAsync<GetWalkthroughDataByFurnacePagekeyEcmResponse>(SPConstant.USP_UI_GET_WALKTHROUGH_DATA_BY_PAGEKEY,
            new
            {
                pageKey = request.pageKey
            });
        }
    }
}
