﻿using Dapper;
using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Account;
using EODomain.Models.EnergyManagement;
using EODomain.Models.Requests;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http;
using System.Text.RegularExpressions;


namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class EnergyManagementRepository : CentralRepository, IEnergyManagementRepository
    {
        public EnergyManagementRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
             base(configuration, httpContextAccessor, DetermineConnectionStringName(httpContextAccessor))
        {
        }

        private static string DetermineConnectionStringName(IHttpContextAccessor httpContextAccessor)
        {
            string ConName = string.Empty;
            if (httpContextAccessor.HttpContext != null)
            {
                var routeData = httpContextAccessor.HttpContext!.GetRouteData();
                var controllerName = routeData.Values["controller"]?.ToString();

                // Check if the request is from 'EnergyManagementController'
                if (controllerName != null && controllerName.Contains("EnergyManagement", StringComparison.OrdinalIgnoreCase))
                {
                    ConName = "EnergyMgmtWebDashConString"; // Return the name of the connection string for Energy Management
                }
                else
                {
                    ConName = "EODashboardConnection"; // Return the name of the default connection string
                }

            }
            return ConName;
        }
    

    public async Task<dynamic> GetEnpiDailyTrendAsync(GetEnpiDailyTrendRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                    SPConstant.GET_ENPI_DAILY_TREND,
                    new
                    {
                        sDate = request.sDate!,
                        eDate = request.eDate!,
                        affiliateID = request.affiliateID,
                        plantnameList = request.plantNameList!,
                        equipmentList = request.equipmentList!,
                        equipmentCategoryList = request.equipmentCategoryList!,
                        groupby=request.groupBy
                    });
        }

        public async Task<dynamic> GetEquipmentDesignCapacity(GetEquipmentDesignCapacityRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                     SPConstant.GET_EQUIPMENT_DESIGN_CAPACITY,
                      new
                      {
                          sDate = request.sDate!,
                          eDate = request.eDate!,
                          affiliateID = request.affiliateID!,
                          plantnameList = request.plantNameList!,
                          category = request.category!,
                          equipment = request.equipment!
                      });
        }

        public async Task<dynamic> GetAirWaterSteamValuesAsync(GetAirWaterSteamValuesRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
              SPConstant.GET_AIR_WATER_STEAM_TREND,
              new
              {
                  sDate = request.sDate,
                  eDate = request.eDate,
                  affiliateID = request.affiliateID,
                  plantNameList = request.plantNameList,
              });

        }

        public async Task<dynamic> GetOverallSignificanceEnergyAsync(GetOverallSignificanceEnergyRequest request)
        {

            return await ExecuteQueryListAsync<dynamic>(
              SPConstant.GET_OVERALL_SIGNIFICANCE_ENERGY,
              new
              {
                  sDate = request.sDate,
                  eDate = request.eDate,
                  affiliateID = request.affiliateID,
                  plantNameList = request.plantNameList,
              });



           
            }

        public async Task<dynamic> GetEnergyCostIndexEnergyGapMonthlyIndexAsync(GetEnergyCostIndexEnergyGapMonthlyIndexRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_ENERGY_COST_INDEX_ENERGY_GAP_MONTHLY_INDEX,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList
                });

        }

        public async Task<dynamic> GetCWEnergyCostTrendAsync(GetCWEnergyCostTrendRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_CW_ENERGY_COST_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupby
                });

        }


        public async Task<dynamic> GetCWFlowRateTrendAsync(GetCWFlowRateTrendRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_CW_FLOW_RATE_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }

        public async Task<dynamic> GetSteamTrendAsync(GetSteamTrendRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_STEAM_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });
        }


        public async Task<dynamic> GetAirTrendAsync(GetAirTrendRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_AIR_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });
        }

        /// <summary>
        /// Keep data model
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<GetTopSixTilesResponse> GetTopSixTilesAsync(GetOverallSignificanceEnergyRequest request)
        {
            return await ExecuteQueryAsync<GetTopSixTilesResponse>(
                SPConstant.GET_TOP_SIX_TILE,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                });
        }

        /// <summary>
        /// Keep data model
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<GetTopTileReconciledDataResponse> GetTopTileReconciledDataAsync(GetReconciledEnergyRequest request)
        {
            return await ExecuteQueryAsync<GetTopTileReconciledDataResponse>(
                SPConstant.GET_RECONCILED_DATA,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID
                });
        }


        public async Task<dynamic> GetPlantAffiliatesAsync(GetPlantAffiliatesRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_PLANT_AFFILIATES,
                new
                {
                    affiliateID = request.affiliateID,
                    plantname = request.plantName,
                });

        }


        public async Task<dynamic> GetPlantEnergyEciAirWaterSteamAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_PLANT_ENERGY_ECI_AIR_WATER_STEAM,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }

        // NEW EM APIs 6th Dec 2024
        public async Task<dynamic> GetCwCostPerUnitTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_CW_COST_PER_UNIT_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }


        public async Task<dynamic> GetCwLoadHeatRejectionTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_CW_LOAD_HEAT_REJECTION_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }


        public async Task<dynamic> GetEciTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_ECI_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }


        public async Task<dynamic> GetSpecificEnergyCategoryAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_SPECIFIC_ENERGY_CATEGORY,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }


        public async Task<dynamic> GetSpecificEnergyCategoryEquipmentAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_SPECIFIC_ENERGY_CATEGORY_EQUIPMENT,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }


        public async Task<dynamic> GetSpecificEnergyCategoryEquipmentTrendAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_SPECIFIC_ENERGY_CATEGORY_EQUIPMENT_TREND,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }


        public async Task<dynamic> GetTopTilePlantsDataAsync(GetPlantEnergyEciAirWaterSteamRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                SPConstant.GET_TOP_TILE_PLANTS,
                new
                {
                    sDate = request.sDate,
                    eDate = request.eDate,
                    affiliateID = request.affiliateID,
                    plantNameList = request.plantNameList,
                    groupby = request.groupBy
                });

        }

        public async Task<dynamic> GetEnergyConsumedSpecificEnergyAsync(AffiliatePlantEquipmentAndCategoryTimeRangeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                     SPConstant.GET_ENERGY_CONSUMED_SPECIFIC_ENERGY,
                      new
                      {
                          sDate = request.sDate!,
                          eDate = request.eDate!,
                          affiliateID = request.affiliateID!,
                          plantnameList = request.plantNameList!,
                          equipmentCategory = request.equipmentCategory!,
                          equipment = request.equipment!,
                          groupby = request.groupby!
                      });
        }

        public async Task<dynamic> GetEmEnergyGapAsync(AffiliatePlantTimeRangeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                     SPConstant.GET_EM_ENERGY_GAP,
                      new
                      {
                          sDate = request.sDate!,
                          eDate = request.eDate!,
                          affiliateID = request.affiliateID!,
                          plantnameList = request.plantNameList!,
                          groupby = request.groupby!
                      });
        }

        public async Task<dynamic> GetKevStateUomAsync(string? category)
        {
            return await ExecuteQueryListAsync<dynamic>(
                    SPConstant.GET_EM_KEV_STATE_UOM,
                      new
                      {
                         category = category
                      });
        }

        public async Task<dynamic> GetEquipmentListAsync(AffiliateEquipmentCategoryPlantNameListRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>(
                    SPConstant.GET_EO_EM_GET_EQUIPMENT_LIST,
                      new
                      {
                          affiliateIdList = request.affiliateIdList!,
                          equipmentcategoryList = request.equipmentcategoryList,
                          plantNameList = request.plantNameList
                      });
        }
    }
}
