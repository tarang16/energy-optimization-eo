﻿using Dapper;
using System.Diagnostics;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using EODomain.Models.Search;
using EODomain.Common;

namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public abstract class CentralRepository
    {
        private  string _connectionString;
      
        private readonly string _url;
        private readonly IConfiguration _configuration;

        protected CentralRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor, string connectionStringName)
        {
            _connectionString = configuration.GetConnectionString(connectionStringName)!;
            _configuration = configuration;
            _url = httpContextAccessor.HttpContext! == null ? null! : $"{httpContextAccessor!.HttpContext!.Request.Path}";
        }


        #pragma warning disable CA1822
        protected  static async Task AddQueryTracker<T>(IEnumerable<T> result, string query, int? count, string elapsed, string url, string errorMessage)
        {
            var castedResult = result.Cast<object>();
            var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(castedResult, query, count, elapsed, url, errorMessage);
            await _commonRepositoryMethod.AddQueryTracker();
        }
       #pragma warning restore CA1822
        protected async Task<T> ExecuteQueryAsync<T>(string query, object parameters, string url = "", int commandTime = 30)
        {
            try
            {
                _connectionString = _configuration.GetConnectionString("EODashboardConnection")!;
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryAsync<T>(query, parameters, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (result == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, query, tempList.Count, elapsed, url == "" ? _url : url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(result!, query, result!.Count(), elapsed, url == "" ? _url : url, null!);
                    }

                    // Check if result is null, if yes then send the default of datatype
                    return result != null ? result.FirstOrDefault()! : default(T)!;
                }
            }
            catch (Exception ex)
            {
                await AddQueryTracker<object>(null!, query, null, null!, url == "" ? _url : url, ex.Message);
                throw;
            }
        }

        protected async Task<List<T>> ExecuteQueryListAsync<T>(string query, object parameters, string url = "", int commandTime = 30,bool connectionFlag=false)
        {
            try
            {
                if (connectionFlag)
                { 
                 _connectionString = _configuration.GetConnectionString("PEDataBaseConnection")!;  
                }
                if (_connectionString == null)
                {
                    _connectionString = _configuration.GetConnectionString("EODashboardConnection")!;
                }
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryAsync<T>(query, parameters, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (result == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, query, tempList.Count, elapsed, url == "" ? _url : url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(result!, query, result!.Count(), elapsed, url == "" ? _url : url, null!);
                    }

                    // Check if result is null, if yes then send the default list of datatype
                    return result != null ? result!.ToList() : new List<T>()!;
                }
            }
            catch (Exception ex)
            {
                await AddQueryTracker<object>(null!, query, null, null!, url == "" ? _url : url, ex.Message);
                throw;
            }
        }
        protected async Task<(List<T> result, TO pageCount)> ExecuteQueryPaginatedListAsync<T, TO>(PaginatedSearch paginatedSearch)
        {
            try
            {
                int searchStatus = 0;
                if (paginatedSearch.searchKey!.Count > 0)
                {
                    searchStatus = 1;
                }
                var parameters = new DynamicParameters();
                foreach (var item in paginatedSearch.searchKey!)
                {
                    parameters.Add($"@{item.Key}", item.Value);
                }
                parameters.Add("@pageNumber", paginatedSearch.pageNumber);
                parameters.Add("@pageSize", paginatedSearch.pageSize);
                parameters.Add("@searchStatus", searchStatus);
                parameters.Add("@pageCount", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryAsync<T>(paginatedSearch.query, parameters, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: paginatedSearch.commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (result == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, paginatedSearch.query!, tempList.Count, elapsed, _url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(result!, paginatedSearch.query!, result!.Count(), elapsed, _url, null!);
                    }

                    var pageCount = parameters.Get<TO>("@pageCount");
                    // Check if result is null, if yes then send the default list of datatype


                    var resultList = result != null ? result!.ToList() : new List<T>()!;

                    return (resultList, pageCount);
                }
            }
            catch (Exception ex)
            {
                await AddQueryTracker<object>(null!, paginatedSearch.query!, null, null!, _url, ex.Message);
                throw;
            }
        }

        protected async Task<List<dynamic>> ExecuteQueryMultipleReturnDynamicResultAsync(string query, object parameters, int commandTime = 30)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var multi = await connection.QueryMultipleAsync(query, parameters, commandType: CommandType.StoredProcedure, commandTimeout: commandTime);
                    // Initialize the list to hold each result set
                    var results = new List<dynamic>();

                    // Retrieve the first result set and add it to the list at index 0
                    var resultSet1 = await multi.ReadAsync<dynamic>();
                    results.Add(resultSet1);

                    // Retrieve the second result set and add it to the list at index 1
                    var resultSet2 = await multi.ReadAsync<dynamic>();
                    results.Add(resultSet2);

                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (results == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, query, tempList.Count, elapsed, _url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(results!, query, results!.Count, elapsed, _url, null!);
                    }

                    // Check if result is null, if yes then send the default list of datatype
                    return results != null ? results!.ToList() : new List<dynamic>()!;
                }
            }
            catch (Exception ex)
            {
                await AddQueryTracker<object>(null!, query, null, null!, _url, ex.Message);
                throw;
            }
        }

        protected async Task<IEnumerable<T>> ExecuteQueryWithDynamicParametersAsync<T>(string storedProcedure, DynamicParameters parameters, int commandTime = 30)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var stopwatch = Stopwatch.StartNew();
                try
                {
                    var result = await connection.QueryAsync<T>(storedProcedure, parameters, commandType: CommandType.StoredProcedure, commandTimeout: commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (result == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, storedProcedure, tempList.Count, elapsed, _url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(result!, storedProcedure, result!.Count(), elapsed, _url, null!);
                    }
                    return result != null ? result : default(IEnumerable<T>)!;
                }
                catch (Exception ex)
                {
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, storedProcedure, null, null, _url, ex.Message);
                    await _commonRepositoryMethod.AddQueryTracker();
                    throw;
                }
            }
        }


        protected async Task<(List<T> result, TO pageCount)> ExecutePaginatedQueryListAsync<T, TO>(string query, DynamicParameters parameters, int commandTime = 30)
        {
            try
            {
                parameters.Add("@countPage", dbType: System.Data.DbType.Int32, direction: System.Data.ParameterDirection.Output);
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryMultipleAsync(query, parameters, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    // Check if result is null, if yes then send the default list of datatype
                   
                    var resultList = result != null ? (await result!.ReadAsync<T>()).ToList() : new List<T>()!;
                    var pageCount = parameters.Get<TO>("@countPage");
                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (resultList == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, query, tempList.Count, elapsed, _url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(resultList!, query, resultList.Count, elapsed, _url, null!);
                    }
                    return (resultList!, pageCount!);
                }
            }
            catch (Exception ex)
            {
                await AddQueryTracker<object>(null!, query, null, null!, _url, ex.Message);
                throw;
            }
        }

        protected async Task<List<T>> ExecuteQueryWFListAsync<T>(string query, object parameters, string url = "", int commandTime = 30)
        {
            try
            {
                _connectionString = _configuration.GetConnectionString("EOWorkflowConnection")!.ToString();
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryAsync<T>(query, parameters, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (result == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, query, tempList.Count, elapsed, url == "" ? _url : url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(result!, query, result!.Count(), elapsed, url == "" ? _url : url, null!);
                    }

                    // Check if result is null, if yes then send the default list of datatype
                    return result != null ? result!.ToList() : new List<T>()!;
                }
            }
            catch (Exception ex)
            {
                await AddQueryTracker<object>(null!, query, null, null!, url == "" ? _url : url, ex.Message);
                throw;
            }
        }


        protected async Task<T> ExecuteQueryWFAsync<T>(string query, object parameters, string url = "", int commandTime = 30)
        {
            try
            {
                _connectionString = _configuration.GetConnectionString("EOWorkflowConnection")!.ToString();
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();
                    var stopwatch = Stopwatch.StartNew();
                    var result = await connection.QueryAsync<T>(query, parameters, commandType: System.Data.CommandType.StoredProcedure, commandTimeout: commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (result == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, query, tempList.Count, elapsed, url == "" ? _url : url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(result!, query, result!.Count(), elapsed, url == "" ? _url : url, null!);
                    }

                    // Check if result is null, if yes then send the default of datatype
                    return result != null ? result.FirstOrDefault()! : default(T)!;
                }
            }
            catch (Exception ex)
            {
                await AddQueryTracker<object>(null!, query, null, null!, url == "" ? _url : url, ex.Message);
                throw;
            }
        }

        protected async Task<IEnumerable<T>> ExecuteQueryWFWithDynamicParametersAsync<T>(string storedProcedure, DynamicParameters parameters, int commandTime = 30)
        {
            _connectionString = _configuration.GetConnectionString("EOWorkflowConnection")!.ToString();
            using (var connection = new SqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                var stopwatch = Stopwatch.StartNew();
                try
                {
                    var result = await connection.QueryAsync<T>(storedProcedure, parameters, commandType: CommandType.StoredProcedure, commandTimeout: commandTime);
                    string elapsed = stopwatch.Elapsed.ToString(@"hh\:mm\:ss\.fff");

                    /*
                     Check if the result is null, if yes then send a dummy list
                     to AddQueryTracker method
                    */
                    if (result == null)
                    {
                        var tempList = new List<object> { true };
                        await AddQueryTracker(tempList, storedProcedure, tempList.Count, elapsed, _url, null!);
                    }
                    else
                    {
                        await AddQueryTracker(result!, storedProcedure, result!.Count(), elapsed, _url, null!);
                    }
                    return result != null ? result : default(IEnumerable<T>)!;
                }
                catch (Exception ex)
                {
                    var _commonRepositoryMethod = new CommonRepositoryMethod<IEnumerable<object>>(null, storedProcedure, null, null, _url, ex.Message);
                    await _commonRepositoryMethod.AddQueryTracker();
                    throw;
                }
            }
        }

    }
}
