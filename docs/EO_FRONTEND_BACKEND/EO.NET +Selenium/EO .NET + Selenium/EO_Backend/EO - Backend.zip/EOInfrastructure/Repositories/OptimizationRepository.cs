﻿using Dapper;
using EOApplication.Contracts.Repositories;
using EODomain.Common;
using EODomain.Models.Network;
using EODomain.Models.Optimization;
using EODomain.Models.Requests;
using EOInfrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.Data.SqlClient;
using System.Diagnostics;
using System.Net;
using System.Text;
using System.Text.Json.Nodes;
using System.Diagnostics.CodeAnalysis;
using System.Net.Http.Headers;


namespace EOInfrastructure.Repositories
{
    [ExcludeFromCodeCoverage]
    public class OptimizationRepository : CentralRepository, IOptimizationRepository
    {
        private readonly string eoWebDashConString;
        private readonly string rmWhatIfDemandURL;
        private readonly string rmWhatIfDemandToken;
        private readonly string rmWhatIfOptimizationURL;
        private readonly string rmWhatIfOptimizationToken;

        public OptimizationRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor) :
            base(configuration, httpContextAccessor, "EODashboardConnection")
        {
            eoWebDashConString = configuration.GetConnectionString("EODashboardConnection")!;
            rmWhatIfDemandURL = configuration.GetConnectionString("WhatIfDemandCalculations")!;
            rmWhatIfDemandToken = configuration.GetConnectionString("WhatIfDemandCalculationsToken")!;
            rmWhatIfOptimizationURL = configuration.GetConnectionString("WhatIfOptimization")!;
            rmWhatIfOptimizationToken = configuration.GetConnectionString("WhatIfOptimizationToken")!;
        }

        public async Task<List<GetDemandInputsStoredProcedureResponse>> GetDemandInputsAsync(CaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<GetDemandInputsStoredProcedureResponse>
                (SPConstant.USP_UI_EO_GET_DEMAND_INPUTS,
                new
                {
                    caseId = request.caseID,
                    time = request.time,
                });
        }

        public async Task<dynamic> GetAssetAvailabilityAsync(CaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                (SPConstant.USP_UI_EO_GET_ASSET_AVAILAIBILITY,
                new
                {
                    caseid = request.caseID,
                    time = request.time,
                });
        }

        public async Task<dynamic> GetPlantLoadAsync(CaseIdDateTimeRequest request)
        {
            /*
            This needs to be modified, query tracker and error logging needs to be added.
            Use Central Repository for this.
             */
            string query = SPConstant.USP_UI_EO_GET_PLANT_LOAD;

            GetPlantLoadResponse response = new GetPlantLoadResponse();
            using (var connection = new SqlConnection(eoWebDashConString))
            {
                await connection.OpenAsync();

                var result = await connection.QueryMultipleAsync(query,
                        new
                        {
                            caseId = request.caseID,
                            time = request.time
                        },
                        commandType: System.Data.CommandType.StoredProcedure);
                response.plantData = (await result.ReadAsync<dynamic>()).ToList();
                response.processData = (await result.ReadAsync<dynamic>()).ToList();
            }
            return response;

        }

        public async Task<List<dynamic>> GetOutputMappingAsync(CaseIdDateTimeRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                (SPConstant.USP_UI_EO_GET_OUTPUT_MAPPINTGS,
                new
                {
                    caseid = request.caseID,
                    time = request.time
                });
        }

        public async Task<dynamic> GetOptimizationPriceInputAsync(CaseIdInputRequest request)
        {
            return await ExecuteQueryListAsync<dynamic>
                (SPConstant.USP_GET_OPTIMIZATION_PRICE_INPUT,
                new
                {
                    caseID = request.caseID,
                });
        }


        public async Task<List<GetWhatIfPlantParametersResponse>> GetWhatIfPlantParametersAsync(GetWhatIfPlantParametersRequest request)
        {
            return await ExecuteQueryListAsync<GetWhatIfPlantParametersResponse>
                (SPConstant.USP_UI_EO_GET_WHAT_IF_PLANT_PARAMETERS,
                new
                {
                    caseid = request.caseID,
                    timestamp = request.timeStamp
                });
        }

        public async Task<WhatIfDemandCalculationResponse> WhatIfDemandCalculationAsync(WhatIfDemandCalculationRMRequest request)
        {

            var repoResponse = new WhatIfDemandCalculationResponse();
            try
            {
                string jsonPayload = JsonConvert.SerializeObject(request);


                StringContent content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Post, rmWhatIfDemandURL +request.userID+ "&model_id=" + request.modelID + "&time_stamp=" + request.time+ "&scenario_name=" + request.scenarioName);
                req.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                req.Content = content;
                req.Headers.Authorization = new AuthenticationHeaderValue("apitoken", rmWhatIfDemandToken);

                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(200);

                    HttpResponseMessage response = await client.SendAsync(req);
                    repoResponse.status = response.StatusCode;
                    string responseBody = await response.Content.ReadAsStringAsync();
                    if (response.IsSuccessStatusCode)
                    {
                        repoResponse = JsonConvert.DeserializeObject<WhatIfDemandCalculationResponse>(responseBody);
                        repoResponse!.status = HttpStatusCode.OK;
                    }
                    else
                    {
                        repoResponse.message = JsonConvert.DeserializeObject<BadRequestModel>(responseBody);
                        repoResponse.url = rmWhatIfDemandURL;
                        repoResponse.status = response.StatusCode;
                    }
                    return repoResponse;
                }
            }
            catch (Exception)
            {
                repoResponse!.status = HttpStatusCode.InternalServerError;
                repoResponse.message = new BadRequestModel
                {
                    code = ResponseConstants.SERVERERROR.ToString(),
                    message = ResponseConstants.COULD_NOT_SIMULATE_REQUESTED_DATA
                };
                return repoResponse;
            }
        }


        public async Task<WhatIfOutputResponse> WhatIfOutputAsync(WhatIfOutputRMRequest request)
        {

            var repoResponse = new WhatIfOutputResponse();
            try
            {
                string jsonPayload = JsonConvert.SerializeObject(request);
                StringContent content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");
                HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Post, rmWhatIfOptimizationURL + request.userID + "&model_id=" + request.modelID + "&time_stamp=" + request.time + "&scenario_name=" + request.scenarioName);
                req.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                req.Content = content;
                req.Headers.Authorization = new AuthenticationHeaderValue("apitoken", rmWhatIfOptimizationToken); 

                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(200);
                    HttpResponseMessage response = await client.SendAsync(req);
                    repoResponse.status = response.StatusCode;
                    string responseBody = await response.Content.ReadAsStringAsync();
                    if (response.IsSuccessStatusCode)
                    {
                        if (responseBody != null && responseBody.ToLower().Contains("exception", StringComparison.OrdinalIgnoreCase))
                        {
                            repoResponse.responseException = JsonConvert.DeserializeObject<WhatIfOutputErrorResponse>(responseBody);
                            repoResponse.status = HttpStatusCode.InternalServerError;
                        }
                        else
                        {
                            repoResponse = JsonConvert.DeserializeObject<WhatIfOutputResponse>(responseBody!);
                            repoResponse!.status = HttpStatusCode.OK;
                        }
                    }
                    else
                    {
                        repoResponse.message = JsonConvert.DeserializeObject<BadRequestModel>(responseBody);
                        repoResponse.url = rmWhatIfOptimizationURL;
                        repoResponse.status = response.StatusCode;
                    }
                    return repoResponse;
                }
            }
            catch (Exception)
            {
                repoResponse!.status = HttpStatusCode.InternalServerError;
                repoResponse.message = new BadRequestModel
                {
                    code = ResponseConstants.SERVERERROR.ToString(),
                    message = ResponseConstants.COULD_NOT_SIMULATE_REQUESTED_DATA
                };
                return repoResponse;
            }
        }

    }
}
